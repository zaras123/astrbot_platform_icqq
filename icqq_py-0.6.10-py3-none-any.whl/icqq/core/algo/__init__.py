"""加密算法集合（core/algo/index.js 的移植）。"""
from __future__ import annotations

from .aes import aesDecrypt, aesEncrypt
from .rsa import encryptPKCS1

__all__ = ["aesEncrypt", "aesDecrypt", "encryptPKCS1"]
