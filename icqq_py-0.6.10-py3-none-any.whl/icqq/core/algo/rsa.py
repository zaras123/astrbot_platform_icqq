"""RSA PKCS1 加密（core/algo/rsa.js 的移植）。"""
from __future__ import annotations

import base64

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding


def encryptPKCS1(pemStr: str, encryptKey) -> str:
    publicKey = serialization.load_pem_public_key(pemStr.encode("utf-8"))
    data = encryptKey.encode("utf-8") if isinstance(encryptKey, str) else bytes(encryptKey)
    return base64.b64encode(
        publicKey.encrypt(data, padding.PKCS1v15())
    ).decode("utf-8")
