"""AES-128-CBC（core/algo/aes.js 的移植）。

Node createCipheriv 默认 autoPadding=true（PKCS7），此处显式实现同等行为。
"""
from __future__ import annotations

import base64

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding as _padding


def _pkcs7_pad(data: bytes) -> bytes:
    padder = _padding.PKCS7(128).padder()
    return padder.update(data) + padder.finalize()


def _pkcs7_unpad(data: bytes) -> bytes:
    unpadder = _padding.PKCS7(128).unpadder()
    return unpadder.update(data) + unpadder.finalize()


def aesEncrypt(data: bytes, key: str) -> bytes:
    """编码"""
    k = key.encode("utf-8")
    iv = k[:16]  # JS: key.substring(0, 16)
    cipher = Cipher(algorithms.AES(k[:16]), modes.CBC(iv))
    encryptor = cipher.encryptor()
    return encryptor.update(_pkcs7_pad(data)) + encryptor.finalize()


def aesDecrypt(encryptedData: str, key: str) -> str:
    """解码"""
    k = key.encode("utf-8")
    iv = k[:16]
    encryptedText = base64.b64decode(encryptedData)
    decipher = Cipher(algorithms.AES(k[:16]), modes.CBC(iv)).decryptor()
    return _pkcs7_unpad(decipher.update(encryptedText) + decipher.finalize()).decode("utf-8")
