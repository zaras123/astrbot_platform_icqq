"""登录/心跳包的 TLV 构建器（core/tlv.js 的移植）。"""
from __future__ import annotations

import os
from typing import Callable

from . import tea
from .buffer import pack_u32
from .constants import BUF0, md5
from .device import Platform
from .writer import Writer


def packTlv(c, tag: int, *args) -> bytes:
    """c 为 BaseClient 实例；tag 为 16 进制数字（如 0x106）。"""
    t = Writer()
    map_[tag](c, t, *args)
    data = t.read()
    lbuf = Writer().writeU16(len(data)).read()
    tbuf = Writer().writeU16(tag).read()
    return tbuf + lbuf + data


def createSalt(c, n: str) -> bytes:
    subCmd = int(n.split("_")[1])
    if n in ("810_9",):
        return (
            Writer()
            .writeU32(0)
            .writeBytes(c.device.guid)
            .writeBytes(c.apk.sdkver.encode("utf-8"))
            .writeU32(subCmd)
            .writeU32(0)
            .read()
        )
    return (
        Writer()
        .writeU32(c.uin)
        .writeBytes(c.device.guid)
        .writeBytes(c.apk.sdkver.encode("utf-8"))
        .writeU32(subCmd)
        .read()
    )


def _tlv_0x01(c, w: Writer):
    w.writeU16(1)  # ip ver
    w.writeBytes(os.urandom(4))
    w.writeU32(c.uin)
    w.write32(int(__import__("time").time()) & 0xFFFFFFFF)
    w.writeBytes(c.device.ip_address)  # ip
    w.writeU16(0)


def _tlv_0x08(c, w: Writer):
    w.writeU16(0)
    w.writeU32(2052)  # localId
    w.writeU16(0)


def _tlv_0x16(c, w: Writer):
    watch = c.getApkInfo(Platform.Watch)
    w.writeU32(watch["ssover"])
    w.writeU32(watch["appid"])
    w.writeU32(watch["subid"])
    w.writeBytes(c.device.guid)
    w.writeTlv(watch["id"])
    w.writeTlv(watch["ver"])
    w.writeTlv(watch["sign"])


def _tlv_0x18(c, w: Writer):
    w.writeU16(1)  # ping ver
    w.writeU32(1536)
    w.writeU32(c.apk["appid"])
    w.writeU32(0)  # app client ver
    w.writeU32(c.uin)
    w.writeU16(0)
    w.writeU16(0)


def _tlv_0x1B(c, w: Writer):
    w.writeU32(0)
    w.writeU32(0)
    w.writeU32(3)
    w.writeU32(4)
    w.writeU32(72)
    w.writeU32(2)
    w.writeU32(2)
    w.writeU16(0)


def _tlv_0x1D(c, w: Writer):
    w.writeU8(1)
    w.writeU32(c.apk["bitmap"])
    w.writeU32(0)
    w.writeU8(0)
    w.writeU32(0)


def _tlv_0x1F(c, w: Writer):
    w.writeU8(0)  # isRoot
    w.writeTlv(b"android")  # OS type
    w.writeTlv(b"7.1.2")  # OS version
    w.writeU16(2)  # Network Type
    w.writeTlv(b"China Mobile GSM")  # simOperatorName
    w.writeTlv(BUF0)
    w.writeTlv(b"wifi")  # APN


def _tlv_0x33(c, w: Writer):
    w.writeBytes(c.device.guid)


def _tlv_0x35(c, w: Writer, deviceType):
    w.writeU32(deviceType)


def _tlv_0x100(c, w: Writer, sub_id=None):
    w.writeU16(1)  # db buf ver
    w.writeU32(c.apk["ssover"])  # sso ver
    w.write32(c.apk["appid"])
    w.writeU32(sub_id or c.apk["subid"])
    w.writeU32(0)  # app client ver
    w.writeU32(c.apk["main_sig_map"])


def _tlv_0x104(c, w: Writer):
    w.writeBytes(c.sig.t104)


def _tlv_0x106(c, w: Writer, md5pass: bytes):
    body = (
        Writer()
        .writeU16(4)  # tgtgt ver
        .writeBytes(os.urandom(4))
        .writeU32(c.apk["ssover"])  # sso ver
        .writeU32(c.apk["appid"])
        .writeU32(0)  # app client ver
        .writeU64(c.uin)
        .write32(int(__import__("time").time()) & 0xFFFFFFFF)
        .writeBytes(bytes(4))  # dummy ip
        .writeU8(1)  # save password
        .writeBytes(md5pass)
        .writeBytes(c.sig.tgtgt)
        .writeU32(0)
        .writeU8(1)  # guid available
        .writeBytes(c.device.guid)
        .writeU32(c.apk["subid"])
        .writeU32(1)  # login type password
        .writeTlv(str(c.uin).encode("utf-8"))
        .writeU16(0)
        .read()
    )
    key = md5(md5pass + bytes(4) + pack_u32(c.uin))
    w.writeBytes(tea.encrypt(body, key))


def _tlv_0x107(c, w: Writer):
    w.writeU16(0)  # pic type
    w.writeU8(0)  # captcha type
    w.writeU16(0)  # pic size
    w.writeU8(1)  # ret type


def _tlv_0x108(c, w: Writer):
    w.writeBytes(c.sig.ksid or f"|{c.device.imei}|{c.apk['name']}".encode("utf-8"))


def _tlv_0x109(c, w: Writer):
    w.writeBytes(md5(c.device.imei))


def _tlv_0x10a(c, w: Writer):
    w.writeBytes(c.sig.tgt)


def _tlv_0x112(c, w: Writer):
    w.writeTlv(str(c.uin).encode("utf-8"))


def _tlv_0x116(c, w: Writer):
    w.writeU8(0)
    w.writeU32(c.apk["bitmap"])
    w.writeU32(c.apk["sub_sig_map"])  # sub sigmap
    w.writeU8(1)  # size of app id list
    w.writeU32(1600000226)  # app id list[0]


def _tlv_0x124(c, w: Writer):
    w.writeTlv(c.device.os_type[:16])
    w.writeTlv(c.device.version["release"][:16])
    w.writeU16(2)  # network type
    w.writeTlv(c.device.sim[:16])
    w.writeU16(0)
    w.writeTlv(c.device.apn[:16])


def _tlv_0x128(c, w: Writer):
    w.writeU16(0)
    w.writeU8(0)  # guid new
    w.writeU8(1)  # guid available
    w.writeU8(0)  # guid changed
    w.writeU32(16777216)  # guid flag
    w.writeTlv(c.device.model[:32])
    w.writeTlv(c.device.guid[:16])
    w.writeTlv(c.device.brand[:16])


def _tlv_0x141(c, w: Writer):
    w.writeU16(1)  # ver
    w.writeTlv(c.device.sim)
    w.writeU16(2)  # network type
    w.writeTlv(c.device.apn)


def _tlv_0x142(c, w: Writer):
    w.writeU16(0)
    w.writeTlv(c.apk["id"][:32])


def _tlv_0x143(c, w: Writer):
    w.writeBytes(c.sig.d2)


def _tlv_0x144(c, w: Writer):
    body = (
        Writer()
        .writeU16(5)  # tlv cnt
        .writeBytes(packTlv(c, 0x109))
        .writeBytes(packTlv(c, 0x52D))
        .writeBytes(packTlv(c, 0x124))
        .writeBytes(packTlv(c, 0x128))
        .writeBytes(packTlv(c, 0x16E))
        .read()
    )
    w.writeBytes(tea.encrypt(body, c.sig.tgtgt))


def _tlv_0x145(c, w: Writer):
    w.writeBytes(c.device.guid)


def _tlv_0x147(c, w: Writer):
    w.writeU32(c.apk["appid"])
    w.writeTlv(c.apk["ver"])
    w.writeTlv(c.apk["sign"])


def _tlv_0x154(c, w: Writer):
    w.writeU32(c.sig.seq + 1)


def _tlv_0x16a(c, w: Writer, srm_token=None):
    w.writeBytes(srm_token or c.sig.srm_token)


def _tlv_0x16e(c, w: Writer):
    w.writeBytes(c.device.model)


def _tlv_0x174(c, w: Writer):
    w.writeBytes(c.sig.t174)


def _tlv_0x177(c, w: Writer):
    w.writeU8(0x01)
    w.writeU32(c.apk["buildtime"])
    w.writeTlv(c.apk["sdkver"].encode("utf-8"))


def _tlv_0x17a(c, w: Writer):
    w.writeU32(9)


def _tlv_0x17c(c, w: Writer, code):
    w.writeTlv(code)


def _tlv_0x187(c, w: Writer):
    w.writeBytes(md5(c.device.mac_address))


def _tlv_0x188(c, w: Writer):
    w.writeBytes(md5(c.device.android_id))


def _tlv_0x191(c, w: Writer):
    w.writeU8(0x82)


def _tlv_0x193(c, w: Writer, ticket):
    w.writeBytes(ticket)


def _tlv_0x194(c, w: Writer):
    w.writeBytes(c.device.imsi)


def _tlv_0x197(c, w: Writer):
    w.writeTlv(bytes(1))


def _tlv_0x198(c, w: Writer):
    w.writeTlv(bytes(1))


def _tlv_0x202(c, w: Writer):
    w.writeTlv(c.device.wifi_bssid[:16])
    w.writeTlv(c.device.wifi_ssid[:32])


def _tlv_0x400(c, w: Writer):
    w.writeU16(1)
    w.writeU64(c.uin)
    w.writeBytes(c.device.guid)
    w.writeBytes(os.urandom(16))
    w.write32(1)
    w.write32(16)
    w.write32(int(__import__("time").time()) & 0xFFFFFFFF)
    w.writeBytes(BUF0)


def _tlv_0x401(c, w: Writer):
    w.writeBytes(os.urandom(16))


def _tlv_0x511(c, w: Writer):
    domains = [
        "aq.qq.com",
        "connect.qq.com",
        "docs.qq.com",
        "game.qq.com",
        "gamecenter.qq.com",
        "haoma.qq.com",
        "id.qq.com",
        "kg.qq.com",
        "mail.qq.com",
        "mma.qq.com",
        "office.qq.com",
        "openmobile.qq.com",
        "qqweb.qq.com",
        "qun.qq.com",
        "qzone.qq.com",
        "ti.qq.com",
        "v.qq.com",
        "vip.qq.com",
        "y.qq.com",
    ]
    w.writeU16(len(domains))
    for v in domains:
        w.writeU8(0x01)
        w.writeTlv(v.encode("utf-8"))


def _tlv_0x516(c, w: Writer):
    w.writeU32(0)


def _tlv_0x521(c, w: Writer, type_):
    w.writeU32(type_)  # product type
    w.writeU16(0)  # const


def _tlv_0x525(c, w: Writer):
    w.writeU16(1)  # tlv cnt
    w.writeU16(0x536)  # tag
    w.writeTlv(bytes([0x2, 0x1, 0x0]))  # zero


def _tlv_0x523(c, w: Writer):
    w.writeTlv(bytes([0x1, 0x0]))


def _tlv_0x52d(c, w: Writer):
    from . import pb

    d = c.device
    buf = pb.encode({
        1: d.bootloader,
        2: d.proc_version,
        3: d.version["codename"],
        4: d.version["incremental"],
        5: d.fingerprint,
        6: d.boot_id,
        7: d.android_id,
        8: d.baseband,
        9: d.version["incremental"],
    })
    w.writeBytes(buf)


def _tlv_0x542(c, w: Writer):
    w.writeBytes(bytes([0x4A, 0x02, 0x60, 0x01]))


def _tlv_0x544(c, w: Writer, v, subCmd, signData=BUF0):
    import time as _time

    if v == -1:
        w.writeBytes(signData)
        return
    # 延迟导入避免 internal 包初始化时的循环依赖
    from ..internal.enctyption import sign

    salt = Writer()
    if v == 2:
        salt.writeU32(0)
        salt.writeTlv(c.device.guid)
        salt.writeTlv(c.apk["sdkver"].encode("utf-8"))
        salt.writeU32(subCmd)
        salt.writeU32(0)
    else:
        salt.writeU64(c.uin)
        salt.writeTlv(c.device.guid)
        salt.writeTlv(c.apk["sdkver"].encode("utf-8"))
        salt.writeU32(subCmd)
    w.writeBytes(sign(int(_time.time() * 1000), salt.read()))


def _tlv_0x545(c, w: Writer, qImei=None):
    data = qImei or c.device.imei
    if isinstance(data, str):
        data = data.encode("utf-8")
    w.writeBytes(data)


def _tlv_0x547(c, w: Writer):
    w.writeBytes(c.sig.t547)


def _tlv_0x548(c, w: Writer):
    import hashlib

    # copy from https://github.com/Icalingua-plus-plus/oicq-icalingua-plus-plus/blob/master/lib/wtlogin/tlv.js
    src = bytearray(os.urandom(128))
    while src[0] == 0 or src[0] == 255:
        src[0] = os.urandom(1)[0]
    src = bytes(src)
    srcNum = int(src.hex(), 16)
    cnt = 10000
    dstNum = srcNum + cnt
    dst = bytes.fromhex(format(dstNum, "x").rjust(256, "0"))
    tgt = hashlib.sha256(dst).digest()
    writer = (
        Writer()
        .writeU8(1)  # version
        .writeU8(2)  # typ
        .writeU8(1)  # hashType
        .writeU8(2)  # ok
        .writeU16(10)  # maxIndex
        .writeBytes(bytes([0, 0]))  # reserveBytes
        .writeTlv(src)
        .writeTlv(tgt)
    )
    cpy = writer.read()
    t546 = Writer().writeBytes(cpy).writeTlv(cpy).read()
    t548 = c.calcPoW(t546)
    w.writeBytes(t548)


def _tlv_0x553(c, w: Writer):
    w.writeBytes(c.sig.t553)


map_ = {
    0x01: _tlv_0x01,
    0x08: _tlv_0x08,
    0x16: _tlv_0x16,
    0x18: _tlv_0x18,
    0x1B: _tlv_0x1B,
    0x1D: _tlv_0x1D,
    0x1F: _tlv_0x1F,
    0x33: _tlv_0x33,
    0x35: _tlv_0x35,
    0x100: _tlv_0x100,
    0x104: _tlv_0x104,
    0x106: _tlv_0x106,
    0x107: _tlv_0x107,
    0x108: _tlv_0x108,
    0x109: _tlv_0x109,
    0x10A: _tlv_0x10a,
    0x112: _tlv_0x112,
    0x116: _tlv_0x116,
    0x124: _tlv_0x124,
    0x128: _tlv_0x128,
    0x141: _tlv_0x141,
    0x142: _tlv_0x142,
    0x143: _tlv_0x143,
    0x144: _tlv_0x144,
    0x145: _tlv_0x145,
    0x147: _tlv_0x147,
    0x154: _tlv_0x154,
    0x16A: _tlv_0x16a,
    0x16E: _tlv_0x16e,
    0x174: _tlv_0x174,
    0x177: _tlv_0x177,
    0x17A: _tlv_0x17a,
    0x17C: _tlv_0x17c,
    0x187: _tlv_0x187,
    0x188: _tlv_0x188,
    0x191: _tlv_0x191,
    0x193: _tlv_0x193,
    0x194: _tlv_0x194,
    0x197: _tlv_0x197,
    0x198: _tlv_0x198,
    0x202: _tlv_0x202,
    0x400: _tlv_0x400,
    0x401: _tlv_0x401,
    0x511: _tlv_0x511,
    0x516: _tlv_0x516,
    0x521: _tlv_0x521,
    0x523: _tlv_0x523,
    0x525: _tlv_0x525,
    0x52D: _tlv_0x52d,
    0x542: _tlv_0x542,
    0x544: _tlv_0x544,
    0x545: _tlv_0x545,
    0x547: _tlv_0x547,
    0x548: _tlv_0x548,
    0x553: _tlv_0x553,
}


def getPacker(c) -> Callable[..., bytes]:
    """返回绑定到客户端 c 的 packTlv 函数。"""
    return lambda tag, *args: packTlv(c, tag, *args)
