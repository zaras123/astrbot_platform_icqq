"""log4js 风格日志器（对应 icqq 使用 log4js.getLogger("[icqq]")）。

提供 mark 级别；level 属性可运行时调整（"fatal" < "mark" < "error" < "warn"
< "info" < "debug" < "trace"，与 icqq 的 VerboseLevel 顺序一致）。
"""
from __future__ import annotations

import logging
import sys

MARK = logging.INFO + 5
logging.addLevelName(MARK, "MARK")

_LEVELS = {
    "fatal": logging.CRITICAL,
    "error": logging.ERROR,
    "warn": logging.WARNING,
    "info": logging.INFO,
    "mark": MARK,
    "debug": logging.DEBUG,
    "trace": logging.DEBUG - 5,
}

_ORDER = ["fatal", "mark", "error", "warn", "info", "debug", "trace"]


class Logger:
    """log4js 风格的轻封装。"""

    def __init__(self, name: str):
        self._log = logging.getLogger(name)
        if not self._log.handlers and not logging.getLogger().handlers:
            # Windows 控制台默认 GBK，统一按 UTF-8 输出避免中文乱码
            try:
                sys.stdout.reconfigure(encoding="utf-8", errors="replace")
                sys.stderr.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(
                logging.Formatter("%(asctime)s.%(msecs)03d [%(name)s] %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S")
            )
            self._log.addHandler(handler)
            self._log.setLevel(logging.INFO)
        self._log.propagate = False
        self.level = "info"

    @property
    def level(self) -> str:
        return self._level_name

    @level.setter
    def level(self, value: str) -> None:
        if value not in _LEVELS:
            value = "info"
        self._level_name = value
        self._log.setLevel(_LEVELS[value])

    def _emit(self, level: str, msg, *args) -> None:
        # 低于当前级别的直接丢弃
        if _ORDER.index(level) > _ORDER.index(self._level_name):
            return
        getattr(self._log, "log")(_LEVELS[level], str(msg), *args)

    def trace(self, msg, *args) -> None:
        self._emit("trace", msg, *args)

    def debug(self, msg, *args) -> None:
        self._emit("debug", msg, *args)

    def info(self, msg, *args) -> None:
        self._emit("info", msg, *args)

    def mark(self, msg, *args) -> None:
        self._emit("mark", msg, *args)

    def warn(self, msg, *args) -> None:
        self._emit("warn", msg, *args)

    def error(self, msg, *args) -> None:
        self._emit("error", msg, *args)

    def fatal(self, msg, *args) -> None:
        self._emit("fatal", msg, *args)


_loggers = {}


def get_logger(name: str = "icqq") -> Logger:
    if name not in _loggers:
        _loggers[name] = Logger(name)
    return _loggers[name]
