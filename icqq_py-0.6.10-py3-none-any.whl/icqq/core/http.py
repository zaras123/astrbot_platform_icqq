"""aiohttp 统一 HTTP 封装（替代 axios）。

- http_get / http_post_form: 返回 bytes
- http_get_json / http_post_json / http_post_form_json: 返回 dict（解析 JSON）
- 超时单位为秒（JS 毫秒值除以 1000）
"""
from __future__ import annotations

import asyncio
import atexit
import json
from typing import Any, Dict, Optional

import aiohttp

_session: Optional[aiohttp.ClientSession] = None
_UA = "icqq-py@0.6.10"


def _atexit_cleanup() -> None:
    """解释器退出时尽力关闭共享 session（避免 Unclosed client session 警告）。"""
    global _session
    if _session is not None and not _session.closed:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_session.close())
            else:
                loop.run_until_complete(_session.close())
        except Exception:
            pass


atexit.register(_atexit_cleanup)


def _get_session() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession()
    return _session


async def close_session() -> None:
    global _session
    if _session is not None and not _session.closed:
        await _session.close()
        _session = None


async def http_get(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> bytes:
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _UA)
    async with _get_session().get(url, params=params, headers=headers,
                                  timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        resp.raise_for_status()
        return await resp.read()


async def http_get_json(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> Any:
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _UA)
    async with _get_session().get(url, params=params, headers=headers,
                                  timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        resp.raise_for_status()
        return await resp.json(content_type=None)


async def http_post(
    url: str,
    data: Optional[Any] = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> bytes:
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _UA)
    async with _get_session().post(url, data=data, params=params, headers=headers,
                                   timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        resp.raise_for_status()
        return await resp.read()


async def http_post_form(
    url: str,
    data: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> bytes:
    return await http_post(url, data=data, params=params, headers=headers, timeout=timeout)


async def http_post_json(
    url: str,
    data: Optional[Any] = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> Any:
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _UA)
    headers.setdefault("Content-Type", "application/json")
    body = json.dumps(data) if not isinstance(data, (str, bytes, bytearray)) else data
    async with _get_session().post(url, data=body, params=params, headers=headers,
                                   timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        resp.raise_for_status()
        return await resp.json(content_type=None)


async def http_post_form_json(
    url: str,
    data: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: float = 10.0,
) -> Any:
    """x-www-form-urlencoded POST，响应解析为 JSON。"""
    headers = dict(headers or {})
    headers.setdefault("User-Agent", _UA)
    headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    async with _get_session().post(url, data=data, params=params, headers=headers,
                                   timeout=aiohttp.ClientTimeout(total=timeout)) as resp:
        resp.raise_for_status()
        return await resp.json(content_type=None)
