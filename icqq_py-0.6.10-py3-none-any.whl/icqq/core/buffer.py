"""字节读写工具：协议解析的统一入口（对应 Node Buffer 的大端读写）。

用法：
- Reader: 顺序流式读取（带 pos 游标），对应 JS 里从 Buffer 顺序读的写法
- u8/u16/u32/i32/u64/i64/f32/f64: 静态偏移读取（对应 buf.readUInt32BE(i) 等）
"""
from __future__ import annotations

import struct


def u8(buf: bytes, off: int = 0) -> int:
    return buf[off]


def u16(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">H", buf, off)[0]


def i16(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">h", buf, off)[0]


def u32(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">I", buf, off)[0]


def i32(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">i", buf, off)[0]


def u64(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">Q", buf, off)[0]


def i64(buf: bytes, off: int = 0) -> int:
    return struct.unpack_from(">q", buf, off)[0]


def f32(buf: bytes, off: int = 0) -> float:
    return struct.unpack_from(">f", buf, off)[0]


def f64(buf: bytes, off: int = 0) -> float:
    return struct.unpack_from(">d", buf, off)[0]


def pack_u16(v: int) -> bytes:
    return struct.pack(">H", v)


def pack_u32(v: int) -> bytes:
    return struct.pack(">I", v & 0xFFFFFFFF)


def pack_i32(v: int) -> bytes:
    return struct.pack(">i", v)


def pack_u64(v: int) -> bytes:
    return struct.pack(">Q", v & 0xFFFFFFFFFFFFFFFF)


class Reader:
    """带游标的顺序读取器，方法名与 Node Buffer 读取方法对应。"""

    __slots__ = ("buf", "pos")

    def __init__(self, buf: bytes):
        self.buf = buf
        self.pos = 0

    def remaining(self) -> int:
        return len(self.buf) - self.pos

    def read(self, n: int) -> bytes:
        end = self.pos + n
        data = self.buf[self.pos:end]
        self.pos = end
        return data

    def readUInt8(self) -> int:
        v = self.buf[self.pos]
        self.pos += 1
        return v

    def readInt8(self) -> int:
        v = self.buf[self.pos]
        self.pos += 1
        return v - 256 if v >= 0x80 else v

    def readUInt16BE(self) -> int:
        v = u16(self.buf, self.pos)
        self.pos += 2
        return v

    def readInt16BE(self) -> int:
        v = i16(self.buf, self.pos)
        self.pos += 2
        return v

    def readUInt32BE(self) -> int:
        v = u32(self.buf, self.pos)
        self.pos += 4
        return v

    def readInt32BE(self) -> int:
        v = i32(self.buf, self.pos)
        self.pos += 4
        return v

    def readUInt64BE(self) -> int:
        v = u64(self.buf, self.pos)
        self.pos += 8
        return v

    def readBigInt64BE(self) -> int:
        v = i64(self.buf, self.pos)
        self.pos += 8
        return v

    def readFloatBE(self) -> float:
        v = f32(self.buf, self.pos)
        self.pos += 4
        return v

    def readDoubleBE(self) -> float:
        v = f64(self.buf, self.pos)
        self.pos += 8
        return v

    # ---- protobuf 变长整数 ----

    def read_varint(self) -> int:
        """读一个 protobuf varint（无符号，返回 Python int，可超 64 位）。"""
        result = 0
        shift = 0
        while True:
            b = self.buf[self.pos]
            self.pos += 1
            result |= (b & 0x7F) << shift
            if not (b & 0x80):
                return result
            shift += 7

    def read_zigzag(self) -> int:
        """读 zigzag 编码的有符号 varint。"""
        n = self.read_varint()
        return (n >> 1) ^ -(n & 1)
