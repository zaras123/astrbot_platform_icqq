"""QQ 登录用的 ECDH（core/ecdh.js 的移植）。"""
from __future__ import annotations

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec

from .constants import md5

# prime256v1 (secp256r1) 的 OICQ 固定公钥
OICQ_PUBLIC_KEY = bytes.fromhex(
    "04EBCA94D733E399B2DB96EACDD3F69A8BB0F74224E2B44E3357812211D2E62EF"
    "BC91BB553098E25E33A799ADC7F76FEB208DA7C6522CDB0719A305180CC54A82E"
)


class Ecdh:
    def __init__(self):
        priv = ec.generate_private_key(ec.SECP256R1())
        self._priv = priv
        self.public_key = priv.public_key().public_bytes(
            serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
        )
        peer = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), OICQ_PUBLIC_KEY)
        secret = priv.exchange(ec.ECDH(), peer)
        # JS: computeSecret(OICQ_PUBLIC_KEY).slice(0, 16) 然后 md5
        self.share_key = md5(secret[:16])
