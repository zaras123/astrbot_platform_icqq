"""通用 tag-based protobuf 编解码器（core/protobuf/index.js 的移植）。

icqq 不使用 schema 编译，而是把 protobuf 视为「字段号(tag) → 值」的通用结构：
- Proto: 可当作 dict 使用的消息对象（key 为字段号 int），同时保留原始字节 .encoded
- encode(obj): 按值的类型推断 wire type 编码（与 protobufjs Writer 行为对齐）
- decode(buf): 解析全部字段，bytes 类型的值递归尝试解码并包成 Proto
- decodePb(buf): 调试辅助，把 Proto 转成更易读的 JSON 结构（含 zlib 解压）
"""
from __future__ import annotations

import zlib
from typing import Any, List, Union

from .buffer import Reader


class Proto(dict):
    """protobuf 消息：dict 视图 + 原始字节。"""

    def __init__(self, encoded: bytes, decoded: Union["Proto", None] = None):
        super().__init__()
        self.encoded = encoded
        if decoded is not None:
            self.update(decoded)

    @property
    def length(self) -> int:
        return len(self.encoded)

    def toString(self) -> str:
        return self.encoded.decode("utf-8", errors="replace")

    def toHex(self) -> str:
        return self.encoded.hex()

    def toBase64(self) -> str:
        import base64

        return base64.b64encode(self.encoded).decode()

    def toBuffer(self) -> bytes:
        return self.encoded

    def __str__(self) -> str:
        return self.toString()

    def toJSON(self) -> Any:
        def to_json(pb: Any) -> Any:
            if not isinstance(pb, Proto):
                return pb
            if len(pb) == 0:
                # 只有 encoded、没有解码出字段的情况
                try:
                    return decode(pb.encoded).toJSON()
                except Exception:
                    return pb.encoded.toString()
            result: dict = {}
            for k, v in pb.items():
                if isinstance(v, list):
                    result[k] = [to_json(item) for item in v]
                elif isinstance(v, Proto):
                    result[k] = v.toJSON()
                elif isinstance(v, dict):
                    result[k] = to_json(v)
                elif isinstance(v, (bytes, bytearray)):
                    result[k] = bytes(v).hex()
                else:
                    result[k] = v
            return result

        return to_json(self)


def _varint_encode(value: int) -> bytes:
    value &= 0xFFFFFFFFFFFFFFFF
    out = bytearray()
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def _zigzag_encode(value: int) -> int:
    return (value << 1) ^ (value >> 63)


def _encode(writer: bytearray, tag: int, value: Any) -> None:
    """对应 JS 的 _encode(writer, tag, value)。writer 为 bytearray 累加器。"""
    if value is None:
        return
    if isinstance(value, bool):
        # JS: typeof boolean 不属于任何分支，直接 return（跳过编码）
        return
    wire_type = 2
    if isinstance(value, int):
        wire_type = 0
    elif isinstance(value, float):
        wire_type = 1
    elif isinstance(value, str):
        value = value.encode("utf-8")
    elif isinstance(value, Proto):
        value = value.toBuffer()
    elif isinstance(value, (bytes, bytearray)):
        value = bytes(value)
    elif isinstance(value, (list, dict)):
        value = encode(value)
    else:
        return
    writer += _varint_encode((tag << 3) | wire_type)
    if wire_type == 0:
        if value < 0:
            # JS writer.sint64(value)：对 64 位有符号值做 zigzag
            v = value & 0xFFFFFFFFFFFFFFFF
            if v >= 2 ** 63:
                v -= 2 ** 64
            writer += _varint_encode(_zigzag_encode(v))
        else:
            writer += _varint_encode(value)
    elif wire_type == 1:
        import struct

        writer += struct.pack(">d", value)
    else:  # type 2
        writer += _varint_encode(len(value))
        writer += value


def encode(obj) -> bytes:
    """按字段号编码 dict（值为数组则逐项编码）。"""
    writer = bytearray()
    if isinstance(obj, Proto):
        obj = dict(obj)
    for tag, value in obj.items():
        tag = int(tag)
        if isinstance(value, (list, tuple)):
            for v in value:
                _encode(writer, tag, v)
        else:
            _encode(writer, tag, value)
    return bytes(writer)


def decode(encoded: bytes) -> Union[Proto, None]:
    """通用解码；遇到未知 wire type 时返回 None（与 JS 一致）。"""
    result = Proto(encoded)
    reader = Reader(encoded)
    while reader.remaining() > 0:
        k = reader.read_varint()
        tag = k >> 3
        wire_type = k & 0b111
        value: Any
        decoded: Union[Proto, None] = None
        if wire_type == 0:
            v = reader.read_varint() & 0xFFFFFFFFFFFFFFFF
            # JS long2int 语义：
            # - 值 < 2^32（Long.high == 0）→ 无符号 32 位（low >>> 0）
            # - 否则 BigInt 无限精度二补码 → 结果为有符号 64 位值
            if v < 2 ** 32:
                value = v
            else:
                value = v - 2 ** 64 if v >= 2 ** 63 else v
        elif wire_type == 1:
            value = int.from_bytes(reader.read(8), "big")
        elif wire_type == 2:
            raw = reader.read(reader.read_varint())
            try:
                decoded = decode(raw)
            except Exception:
                decoded = None
            value = Proto(raw, decoded)
        elif wire_type == 5:
            value = int.from_bytes(reader.read(4), "big")
        else:
            return None
        if tag in result:
            existing = result[tag]
            if isinstance(existing, list):
                existing.append(value)
            else:
                result[tag] = [existing, value]
        else:
            result[tag] = value
    return result


def decodePb(buffer_data: bytes) -> dict:
    """调试辅助：把 Proto 递归转成可读 JSON 结构（含 zlib/前缀处理）。"""
    pb = decode(buffer_data)
    json: dict = {}
    if pb is None:
        return json
    data: Union[bytes, None] = None

    def decode2(proto: Any, j: dict) -> None:
        nonlocal data
        for key in list(proto.keys()):
            val = proto[key]
            if isinstance(val, (Proto, list, dict, bytes, bytearray)):
                if isinstance(val, list):
                    j[key] = []
                    for i in range(len(val)):
                        j[key].append({})
                        decode2(val[i], j[key][i])
                else:
                    try:
                        if decode(val.encoded) is None:
                            # JS 原版这里直接访问 data.length，首次 data 为 undefined
                            # 会抛 TypeError 进入 except（先置 data）。若 data 已有值，
                            # 则用的是上一次失败留下的 buffer（原版行为，照搬）。
                            if len(data) > 3:
                                prefix = ""
                                if data[0] == 0x01 or data[0] == 0x00:
                                    prefix = data.hex()[:2]
                                    data = data[1:]
                                data_json: dict = {}
                                data_json["Prefix"] = prefix
                                if data[0] == 0x78 and data[1] == 0x9C:
                                    deflated = zlib.decompress(data)
                                    data_json["txt"] = deflated.decode("utf-8", errors="replace")
                                    data_json["tip"] = "数据被加密过,使用时请把数据加密回去 deflateSync()"
                                    j[key] = data_json
                                    decode2(proto[key], j[key])
                                    continue
                                else:
                                    j[key] = proto[key].encoded.decode("utf-8", errors="replace")
                                    decode2(proto[key], j[key])
                                    continue
                            j[key] = proto[key].encoded.decode("utf-8", errors="replace")
                            decode2(proto[key], j[key])
                            continue
                        j[key] = {}
                        decode2(proto[key], j[key])
                    except Exception:
                        data = proto[key].encoded
                        if len(data) > 3:
                            prefix = ""
                            if data[0] == 0x01 or data[0] == 0x00:
                                prefix = data.hex()[:2]
                                data = data[1:]
                            data_json = {}
                            data_json["Prefix"] = prefix
                            if data[0] == 0x78 and data[1] == 0x9C:
                                deflated = zlib.decompress(data)
                                data_json["txt"] = deflated.decode("utf-8", errors="replace")
                                data_json["tip"] = "数据被加密过,使用时请把数据加密回去 deflateSync()"
                                j[key] = data_json
                                decode2(proto[key], j[key])
                                continue
                            else:
                                j[key] = proto[key].encoded.decode("utf-8", errors="replace")
                                decode2(proto[key], j[key])
                                continue
                        j[key] = proto[key].encoded.decode("utf-8", errors="replace")
                        decode2(proto[key], j[key])
                        continue
            else:
                j[key] = val

    decode2(pb, json)
    return json
