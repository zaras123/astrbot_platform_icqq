"""QQ 的 16 轮 TEA 加解密（core/tea.js 的逐行移植，字节级兼容）。"""
from __future__ import annotations

import struct

BUF7 = bytes(7)

deltas = [
    0x9E3779B9, 0x3C6EF372, 0xDAA66D2B, 0x78DDE6E4,
    0x1715609D, 0xB54CDA56, 0x5384540F, 0xF1BBCDC8,
    0x8FF34781, 0x2E2AC13A, 0xCC623AF3, 0x6A99B4AC,
    0x08D12E65, 0xA708A81E, 0x454021D7, 0xE3779B90,
]

_MASK = 0xFFFFFFFF


def _toUInt32(num: int) -> int:
    return num & _MASK


def _encrypt(x: int, y: int, k0: int, k1: int, k2: int, k3: int):
    for i in range(16):
        aa = ((_toUInt32((y << 4) + k0) ^ _toUInt32(y + deltas[i])) & _MASK) ^ _toUInt32(int(y / 32) + k1)
        aa &= _MASK
        x = _toUInt32(x + aa)
        bb = ((_toUInt32((x << 4) + k2) ^ _toUInt32(x + deltas[i])) & _MASK) ^ _toUInt32(int(x / 32) + k3)
        bb &= _MASK
        y = _toUInt32(y + bb)
    return [x, y]


def encrypt(data: bytes, key: bytes) -> bytes:
    n = (6 - len(data)) & _MASK
    n = n % 8 + 2
    # JS 用 Buffer.allocUnsafe(n)（未初始化内存，填充内容随机）；填充字节解密后
    # 会被丢弃、不影响协议，Python 版固定用零填充（确定性，功能等价）。
    v = bytes([(n - 2) | 0xF8]) + bytes(n) + data + BUF7
    k0 = int.from_bytes(key[0:4], "big")
    k1 = int.from_bytes(key[4:8], "big")
    k2 = int.from_bytes(key[8:12], "big")
    k3 = int.from_bytes(key[12:16], "big")
    r1 = r2 = t1 = t2 = 0
    out = bytearray(len(v))
    for i in range(0, len(v), 8):
        a1 = int.from_bytes(v[i:i + 4], "big")
        a2 = int.from_bytes(v[i + 4:i + 8], "big")
        b1 = a1 ^ r1
        b2 = a2 ^ r2
        x, y = _encrypt(_toUInt32(b1), _toUInt32(b2), k0, k1, k2, k3)
        r1 = x ^ t1
        r2 = y ^ t2
        t1 = b1
        t2 = b2
        out[i:i + 4] = struct.pack(">I", r1)
        out[i + 4:i + 8] = struct.pack(">I", r2)
    return bytes(out)


def _decrypt(x: int, y: int, k0: int, k1: int, k2: int, k3: int):
    for i in range(15, -1, -1):
        aa = ((_toUInt32((x << 4) + k2) ^ _toUInt32(x + deltas[i])) & _MASK) ^ _toUInt32(int(x / 32) + k3)
        y = (y - aa) & _MASK
        bb = ((_toUInt32((y << 4) + k0) ^ _toUInt32(y + deltas[i])) & _MASK) ^ _toUInt32(int(y / 32) + k1)
        x = (x - bb) & _MASK
    return [x, y]


def decrypt(encrypted: bytes, key: bytes) -> bytes:
    if len(encrypted) % 8:
        raise ValueError("length of encrypted data must be a multiple of 8")
    k0 = int.from_bytes(key[0:4], "big")
    k1 = int.from_bytes(key[4:8], "big")
    k2 = int.from_bytes(key[8:12], "big")
    k3 = int.from_bytes(key[12:16], "big")
    r1 = r2 = t1 = t2 = x = y = 0
    out = bytearray(len(encrypted))
    for i in range(0, len(encrypted), 8):
        a1 = int.from_bytes(encrypted[i:i + 4], "big")
        a2 = int.from_bytes(encrypted[i + 4:i + 8], "big")
        b1 = a1 ^ x
        b2 = a2 ^ y
        x, y = _decrypt(_toUInt32(b1), _toUInt32(b2), k0, k1, k2, k3)
        r1 = x ^ t1
        r2 = y ^ t2
        t1 = a1
        t2 = a2
        out[i:i + 4] = struct.pack(">I", r1)
        out[i + 4:i + 8] = struct.pack(">I", r2)
    if bytes(out[len(out) - 7:]) != BUF7:
        raise ValueError("encrypted data is illegal")
    return bytes(out[(out[0] & 0x07) + 3:len(out) - 7])
