"""silk 语音编解码（core/silk.js 的移植）。

JS 版通过 worker_threads + silk-wasm 做编解码，API 形状：
- encode(input, sampleRate) -> {data: silk_bytes, duration: 毫秒}
- decode(input, sampleRate) -> {data: pcm_bytes(s16le), duration: 毫秒}
- getDuration(input, frameMs) -> 毫秒 (int)

Python 版使用可选的 `pysilk`（https://github.com/DCZYewen/Python-Silk-Module）：
未安装时抛 ImportError 并提示安装。

input 参数支持 bytes（PCM s16le / silk）或文件路径字符串。
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Union


def _backend():
    try:
        import pysilk  # type: ignore

        return pysilk
    except ImportError:
        raise ImportError(
            "silk 语音编解码需要 pysilk 库：pip install pysilk "
            "（对应 icqq 的 silk-wasm 依赖）"
        )


def _file(input_: Union[str, bytes]) -> bytes:
    if isinstance(input_, str):
        with open(input_, "rb") as f:
            return f.read()
    return bytes(input_)


def _pcm_duration(pcm: bytes, sample_rate: int) -> int:
    """PCM s16le 的时长（毫秒）。"""
    return int(len(pcm) / 2 / sample_rate * 1000)


async def encode(input_: Union[str, bytes], sampleRate: int = 24000):
    """PCM(s16le) → silk，返回 {data, duration}（与 silk-wasm 一致）。"""
    silk = _backend()
    pcm = _file(input_)
    try:
        data = silk.encode(pcm, sample_rate=sampleRate)
    except TypeError:
        data = silk.encode(pcm, sr=sampleRate)
    return SimpleNamespace(data=bytes(data), duration=_pcm_duration(pcm, sampleRate))


async def decode(input_: Union[str, bytes], sampleRate: int = 24000):
    """silk → PCM(s16le)，返回 {data, duration}。"""
    silk = _backend()
    data = _file(input_)
    try:
        pcm = silk.decode(data, sample_rate=sampleRate)
    except TypeError:
        pcm = silk.decode(data, sr=sampleRate)
    return SimpleNamespace(data=bytes(pcm), duration=_pcm_duration(bytes(pcm), sampleRate))


async def getDuration(input_: Union[str, bytes], frameMs: int = 20) -> int:
    """获取 silk 语音时长（毫秒）。"""
    silk = _backend()
    data = _file(input_)
    if hasattr(silk, "get_duration"):
        try:
            return int(silk.get_duration(data, frame_ms=frameMs))
        except TypeError:
            return int(silk.get_duration(data, frameMs))
    # 无 get_duration 时解码后按 PCM 长度估算（24kHz 单声道 16bit）
    try:
        pcm = silk.decode(data, sample_rate=24000)
    except TypeError:
        pcm = silk.decode(data, sr=24000)
    return _pcm_duration(bytes(pcm), 24000)
