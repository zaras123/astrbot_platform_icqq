"""JCE 包装层（core/jce/index.js 的移植）。"""
from __future__ import annotations

from .jce_lib import *  # noqa: F401,F403
from .jce_lib import decode as _decode
from .jce_lib import encode as _encode
from .jce_lib import encodeNested as _encodeNested


def decodeWrapper(blob: bytes):
    wrapper = _decode(blob)
    m = _decode(wrapper[7])[0]
    nested = m[list(m.keys())[0]]
    if not isinstance(nested, (bytes, bytearray)):
        nested = nested[list(nested.keys())[0]]
    return _decode(nested)[0]


def encodeWrapper(map_, servant: str, func: str, reqid: int = 0) -> bytes:
    return _encode(
        [
            None,
            3, 0,
            0, reqid,
            servant, func,
            _encode([map_]), 0,
            {}, {},
        ]
    )


def encodeStruct(nested) -> bytes:
    return _encode([_encodeNested(nested)])
