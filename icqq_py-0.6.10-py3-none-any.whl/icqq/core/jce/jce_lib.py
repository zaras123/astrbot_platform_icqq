"""JCE（腾讯自研序列化格式）编解码（core/jce/jce.lib.js 的移植）。"""
from __future__ import annotations

import struct
from typing import Any, Union

from ..buffer import Reader

BUF0 = b""

TYPE_INT8 = 0
TYPE_INT16 = 1
TYPE_INT32 = 2
TYPE_INT64 = 3
TYPE_FLOAT = 4
TYPE_DOUBLE = 5
TYPE_STRING1 = 6
TYPE_STRING4 = 7
TYPE_MAP = 8
TYPE_LIST = 9
TYPE_STRUCT_BEGIN = 10
TYPE_STRUCT_END = 11
TYPE_ZERO = 12
TYPE_SIMPLE_LIST = 13
TAG_MAP_K = 0
TAG_MAP_V = 1
TAG_LIST_E = 0
TAG_BYTES = 0
TAG_LENGTH = 0
TAG_STRUCT_END = 0

FLAG_STRUCT_END = object()  # JS: Symbol("FLAG_STRUCT_END")


class JceError(Exception):
    def __init__(self, *args):
        super().__init__(*args)
        self.name = "JceError"


class Struct(dict):
    """解码出的结构体（JS 中为 Object.create(Struct.prototype)）。"""

    pass


# ---------------------------------------------------------------- decode

def _readHead(readable: Reader):
    head = readable.readUInt8()
    type_ = head & 0xF
    tag = (head & 0xF0) >> 4
    if tag == 0xF:
        tag = readable.readUInt8()
    return {"tag": tag, "type": type_}


def _readBody(stream: Reader, type_: int):
    if type_ == TYPE_ZERO:
        return 0
    if type_ == TYPE_INT8:
        return stream.readInt8()
    if type_ == TYPE_INT16:
        return stream.readInt16BE()
    if type_ == TYPE_INT32:
        return stream.readInt32BE()
    if type_ == TYPE_INT64:
        value = stream.readBigInt64BE()
        # JS: 安全范围内转 Number，否则保持 bigint；Python int 原生支持
        return value
    if type_ == TYPE_STRING1:
        length = stream.readUInt8()
        return stream.read(length).decode("utf-8", errors="replace") if length > 0 else ""
    if type_ == TYPE_STRING4:
        length = stream.readUInt32BE()
        return stream.read(length).decode("utf-8", errors="replace") if length > 0 else ""
    if type_ == TYPE_SIMPLE_LIST:
        _readHead(stream)
        length = _readElement(stream)["value"]
        return stream.read(length) if length > 0 else BUF0
    if type_ == TYPE_LIST:
        length = _readElement(stream)["value"]
        lst = []
        while length > 0:
            lst.append(_readElement(stream)["value"])
            length -= 1
        return lst
    if type_ == TYPE_MAP:
        length = _readElement(stream)["value"]
        mp: dict = {}
        while length > 0:
            # 注意：必须两行写，Python 的 `mp[f()] = g()` 会先求值 g()
            k = _readElement(stream)["value"]
            mp[k] = _readElement(stream)["value"]
            length -= 1
        return mp
    if type_ == TYPE_STRUCT_BEGIN:
        return _readStruct(stream)
    if type_ == TYPE_STRUCT_END:
        return FLAG_STRUCT_END
    if type_ == TYPE_FLOAT:
        return stream.readFloatBE()
    if type_ == TYPE_DOUBLE:
        return stream.readDoubleBE()
    raise JceError("unknown jce type: " + str(type_))


def _readStruct(readable: Reader) -> Struct:
    struct_obj = Struct()
    while readable.remaining() > 0:
        element = _readElement(readable)
        if element["value"] is FLAG_STRUCT_END:
            return struct_obj
        struct_obj[element["tag"]] = element["value"]
    return struct_obj


def _readElement(readable: Reader):
    head = _readHead(readable)
    value = _readBody(readable, head["type"])
    return {"tag": head["tag"], "value": value}


# ---------------------------------------------------------------- encode

class Nested:
    """嵌套结构数据必须用此函数创建（encodeNested 返回）。"""

    def __init__(self, data: bytes):
        self.data = data


def _createHead(type_: int, tag: int) -> bytes:
    if tag < 15:
        return bytes([(tag << 4) | type_])
    elif tag < 256:
        return bytes([0xF0 | type_, tag])
    else:
        raise JceError("Tag must be less than 256, received: " + str(tag))


def _createBody(type_: int, value) -> bytes:
    if type_ == TYPE_INT8:
        return bytes([int(value) & 0xFF])
    if type_ == TYPE_INT16:
        return struct.pack(">h", int(value))
    if type_ == TYPE_INT32:
        return struct.pack(">i", int(value))
    if type_ == TYPE_INT64:
        return struct.pack(">q", int(value))
    if type_ == TYPE_FLOAT:
        return struct.pack(">f", value)
    if type_ == TYPE_DOUBLE:
        return struct.pack(">d", value)
    if type_ == TYPE_STRING1:
        if isinstance(value, str):
            value = value.encode("utf-8")
        return bytes([len(value)]) + value
    if type_ == TYPE_STRING4:
        if isinstance(value, str):
            value = value.encode("utf-8")
        return struct.pack(">I", len(value)) + value
    if type_ == TYPE_MAP:
        body = []
        n = 0
        for k in value.keys():
            n += 1
            body.append(_createElement(TAG_MAP_K, k))
            body.append(_createElement(TAG_MAP_V, value[k]))
        body.insert(0, _createElement(TAG_LENGTH, n))
        return b"".join(body)
    if type_ == TYPE_LIST:
        body = [_createElement(TAG_LENGTH, len(value))]
        for i in range(len(value)):
            body.append(_createElement(TAG_LIST_E, value[i]))
        return b"".join(body)
    if type_ == TYPE_ZERO:
        return BUF0
    if type_ == TYPE_SIMPLE_LIST:
        if isinstance(value, str):
            value = value.encode("utf-8")
        return _createHead(0, TAG_BYTES) + _createElement(TAG_LENGTH, len(value)) + bytes(value)
    raise JceError("Type must be 0 ~ 13, received: " + str(type_))


def _createElement(tag: int, value: Any) -> bytes:
    if isinstance(value, Nested):
        begin = _createHead(TYPE_STRUCT_BEGIN, tag)
        end = _createHead(TYPE_STRUCT_END, TAG_STRUCT_END)
        return begin + value.data + end
    if isinstance(value, str):
        value = value.encode("utf-8")
        type_ = TYPE_STRING1 if len(value) <= 0xFF else TYPE_STRING4
    elif isinstance(value, (bytes, bytearray)):
        value = bytes(value)
        type_ = TYPE_SIMPLE_LIST
    elif isinstance(value, (list, tuple)):
        type_ = TYPE_LIST
    elif isinstance(value, dict):
        type_ = TYPE_MAP
    elif isinstance(value, bool):
        raise JceError("Unsupported type: boolean")
    elif isinstance(value, int):
        if value == 0:
            type_ = TYPE_ZERO
        elif -0x80 <= value <= 0x7F:
            type_ = TYPE_INT8
        elif -0x8000 <= value <= 0x7FFF:
            type_ = TYPE_INT16
        elif -0x80000000 <= value <= 0x7FFFFFFF:
            type_ = TYPE_INT32
        elif -0x8000000000000000 <= value <= 0x7FFFFFFFFFFFFFFF:
            type_ = TYPE_INT64
        else:
            raise JceError("Unsupported integer range: " + str(value))
    elif isinstance(value, float):
        type_ = TYPE_DOUBLE  # we don't use float
    else:
        raise JceError("Unsupported type: " + type(value).__name__)
    head = _createHead(type_, tag)
    body = _createBody(type_, value)
    return head + body


# --------------------------------------------------------------------

def decode(encoded: bytes) -> dict:
    readable = Reader(encoded)
    decoded: dict = {}
    while readable.remaining() > 0:
        element = _readElement(readable)
        decoded[element["tag"]] = element["value"]
    return decoded


def encode(obj: Union[list, dict]) -> bytes:
    elements = []
    if isinstance(obj, (list, tuple)):
        for tag in range(len(obj)):
            if obj[tag] is None:
                continue
            elements.append(_createElement(tag, obj[tag]))
    else:
        for tag in obj.keys():
            tag = int(tag)
            if obj[tag] is None:
                continue
            elements.append(_createElement(tag, obj[tag]))
    return b"".join(elements)


def encodeNested(obj) -> Nested:
    """嵌套结构数据必须调用此函数创建"""
    return Nested(encode(obj))
