"""通用常量与工具函数（core/constants.js 的移植）。"""
from __future__ import annotations

import asyncio
import hashlib
import random
import time
import zlib

# 一个0长buf
BUF0 = b""
# 4个0的buf
BUF4 = bytes(4)
# 16个0的buf
BUF16 = bytes(16)


# no operation
def NOOP(*args, **kwargs):
    pass


async def unzip(data: bytes) -> bytes:
    """promisified unzip → asyncio 版 zlib.decompress"""
    return zlib.decompress(data)


async def gzip(data: bytes) -> bytes:
    """promisified gzip"""
    return zlib.compress(data)


async def pipeline(*streams) -> None:
    """stream.pipeline 的 asyncio 等价物：把前面的流逐个写入后面的流。

    icqq 中主要用于文件下载限速/限流，这里以 aiohttp 的流式响应为例：
    第一个参数是 aiohttp 的 content 迭代器或任何 async 可迭代，后续是文件对象。
    """
    if not streams:
        return
    first = streams[0]
    rest = list(streams[1:])
    async for chunk in first:
        for target in rest:
            target.write(chunk)
    for target in rest:
        if hasattr(target, "flush"):
            target.flush()


def md5(data) -> bytes:
    # JS createHash().update(data)：str 自动按 utf-8 编码（Buffer 直接使用）
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.md5(data).digest()


def sha(data) -> bytes:
    """sha1 hash"""
    if isinstance(data, str):
        data = data.encode("utf-8")
    return hashlib.sha1(data).digest()


def randomString(n: int, template: str = "abcdef1234567890") -> str:
    return "".join(random.choice(template) for _ in range(n))


def formatTime(value=None, template: str = "yyyy-MM-dd HH:mm:ss") -> str:
    """JS 版 formatTime 的等价实现（本地时间）。

    注意与 JS 完全一致的两个行为：
    - padStart(len, '') 的填充串为空 → 数值不补零（"8" 而不是 "08"）
    - /(y+)/ 大小写敏感 → 大写 "YYYY" 不会被替换，原样保留
    """
    import datetime

    date = datetime.datetime.now()
    o = {
        "M+": date.month,
        "d+": date.day,
        "H+": date.hour,
        "m+": date.minute,
        "s+": date.second,
        "q+": (date.month + 2) // 3,
        "S": date.microsecond // 1000,
    }
    import re

    m = re.search(r"(y+)", template)
    if m:
        # JS: (date.getFullYear() + "").slice(0, sub.length) —— 从左侧截取
        template = template.replace(m.group(0), str(date.year)[: len(m.group(0))], 1)
    for k, v in o.items():
        # JS: new RegExp("(" + k + ")") —— "+" 是量词，不能 re.escape
        mm = re.search("(" + k + ")", template)
        if mm:
            # JS: padStart(v.length, '') —— 空填充串，不补零
            template = template.replace(mm.group(0), str(v), 1)
    return template


def timestamp() -> int:
    """unix timestamp (second)"""
    return int(time.time())


def int32ip2str(ip) -> str:
    """数字ip转通用ip"""
    if isinstance(ip, str):
        return ip
    ip = ip & 0xFFFFFFFF
    return ".".join(
        str(v)
        for v in (
            ip & 0xFF,
            (ip & 0xFF00) >> 8,
            (ip & 0xFF0000) >> 16,
            (ip & 0xFF000000) >> 24 & 0xFF,
        )
    )


def lock(obj, prop) -> None:
    """隐藏并锁定一个属性。Python 无此机制，作为文档性 no-op 保留接口兼容。"""
    pass


def unlock(obj, prop) -> None:
    """同上，no-op。"""
    pass


def hide(obj, prop) -> None:
    """隐藏一个属性。no-op。"""
    pass


def sleep(ms: float) -> "asyncio.Future":
    """setTimeout 的等价物：await sleep(ms)"""
    return asyncio.sleep(ms / 1000)
