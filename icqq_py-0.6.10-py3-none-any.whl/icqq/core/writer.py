"""大端字节流写入器（core/writer.js 的移植）。链式调用，最后 read() 取字节。"""
from __future__ import annotations

import struct
from typing import List


class Writer:
    def __init__(self):
        self._bufs: List[bytes] = []

    def _append(self, data: bytes) -> None:
        self._bufs.append(data)

    def writeU8(self, v: int) -> "Writer":
        self._append(struct.pack(">B", v & 0xFF))
        return self

    def writeU16(self, v: int) -> "Writer":
        self._append(struct.pack(">H", v & 0xFFFF))
        return self

    def write32(self, v: int) -> "Writer":
        self._append(struct.pack(">i", v & 0xFFFFFFFF))
        return self

    def writeU32(self, v: int) -> "Writer":
        self._append(struct.pack(">I", v & 0xFFFFFFFF))
        return self

    def writeU64(self, v: int) -> "Writer":
        self._append(struct.pack(">Q", v & 0xFFFFFFFFFFFFFFFF))
        return self

    def writeBytes(self, v) -> "Writer":
        if isinstance(v, str):
            v = v.encode("utf-8")
        self._append(bytes(v))
        return self

    def writeWithLength(self, v) -> "Writer":
        return self.writeU32(len(v) + 4).writeBytes(v)

    def writeTlv(self, v) -> "Writer":
        if isinstance(v, str):
            v = v.encode("utf-8")
        return self.writeU16(len(v)).writeBytes(v)

    def read(self) -> bytes:
        return b"".join(self._bufs)

    def __len__(self) -> int:
        return sum(len(b) for b in self._bufs)
