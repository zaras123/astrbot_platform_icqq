"""签名 API 接口（core/sign.js 的移植，用于 tx-sign 类签名服务器）。

所有函数第一参数 self 为 BaseClient 实例（JS 中通过 fn.call(this) 调用）。
"""
from __future__ import annotations

import asyncio
import re
import time
from typing import Any, Dict, List
from urllib.parse import urlparse, urlunparse

from .base_client import VerboseLevel
from .constants import BUF0
from .http import http_get_json, http_post_form_json


async def getT544(self, cmd: str) -> bytes:
    sign = BUF0
    if self.sig.sign_api_addr and self.apk.get("qua"):
        t = time.time() * 1000
        post_params = {
            "ver": self.apk["ver"],
            "uin": self.uin or 0,
            "data": cmd,
            "guid": self.device.guid.hex(),
            "version": self.apk["sdkver"],
        }
        url = _rewrite_url(self.sig.sign_api_addr, "/energy")
        data = await _get(self, url, post_params, True)
        log = f"getT544:{cmd} result({int(time.time() * 1000 - t)}ms):{data}"
        if data.get("code") == 0:
            self.emit("internal.verbose", log, VerboseLevel.Debug)
            if isinstance(data.get("data"), str):
                sign = bytes.fromhex(data["data"])
            elif isinstance((data.get("data") or {}).get("sign"), str):
                sign = bytes.fromhex(data["data"]["sign"])
                if isinstance(data["data"].get("t553"), str):
                    self.sig.t553 = bytes.fromhex(data["data"]["t553"])
        else:
            self.emit("internal.verbose", f"签名api异常：{log}", VerboseLevel.Error)
    return self.generateT544Packet(cmd, sign)


async def getSign(self, cmd: str, seq: int, body: bytes) -> bytes:
    params = BUF0
    if not self.sig.sign_api_addr:
        return params
    qImei36 = self.device.qImei36 or self.device.qImei16
    if self.apk.get("qua"):
        t = time.time() * 1000
        post_params = {
            "ver": self.apk["ver"],
            "qua": self.apk["qua"],
            "uin": self.uin or 0,
            "cmd": cmd,
            "seq": seq,
            "androidId": self.device.android_id,
            "qimei36": qImei36 or self.device.android_id,
            "guid": self.device.guid.hex(),
            "buffer": body.hex(),
        }
        url = _rewrite_url(self.sig.sign_api_addr, "/sign")
        data = await _get(self, url, post_params, True)
        log = f"sign:{cmd} seq:{seq} result({int(time.time() * 1000 - t)}ms):{data}"
        if data.get("code") == 0:
            self.emit("internal.verbose", log, VerboseLevel.Debug)
            d = data.get("data") or {}
            params = self.generateSignPacket(d.get("sign"), d.get("token"), d.get("extra"))
            lst = d.get("ssoPacketList") or d.get("requestCallback") or []
            if len(lst) > 0:
                self.ssoPacketListHandler(lst)
        else:
            self.emit("internal.verbose", f"签名api异常：{log}", VerboseLevel.Error)
    return params


async def requestSignToken(self) -> List[Any]:
    if not self.sig.sign_api_addr:
        return []
    qImei36 = self.device.qImei36 or self.device.qImei16
    if self.apk.get("qua"):
        t = time.time() * 1000
        post_params = {
            "ver": self.apk["ver"],
            "qua": self.apk["qua"],
            "uin": self.uin or 0,
            "androidId": self.device.android_id,
            "qimei36": qImei36 or self.device.android_id,
            "guid": self.device.guid.hex(),
        }
        url = _rewrite_url(self.sig.sign_api_addr, "/request_token")
        data = await _get(self, url, post_params, True)
        self.emit("internal.verbose",
                  f"requestSignToken result({int(time.time() * 1000 - t)}ms): {data}",
                  VerboseLevel.Debug)
        if data.get("code") == 0:
            d = data.get("data") or {}
            ssoPacketList = d.get("ssoPacketList") or d.get("requestCallback") or data.get("data")
            if not ssoPacketList or len(ssoPacketList) < 1:
                return []
            return ssoPacketList
    return []


async def submitSsoPacket(self, cmd: str, callbackId: int, body: bytes) -> List[Any]:
    if not self.sig.sign_api_addr:
        return []
    qImei36 = self.device.qImei36 or self.device.qImei16
    if self.apk.get("qua"):
        t = time.time() * 1000
        post_params = {
            "ver": self.apk["ver"],
            "qua": self.apk["qua"],
            "uin": self.uin or 0,
            "cmd": cmd,
            "callbackId": callbackId,
            "androidId": self.device.android_id,
            "qimei36": qImei36 or self.device.android_id,
            "buffer": body.hex(),
            "guid": self.device.guid.hex(),
        }
        url = _rewrite_url(self.sig.sign_api_addr, "/submit")
        data = await _get(self, url, post_params, True)
        self.emit("internal.verbose",
                  f"submitSsoPacket result({int(time.time() * 1000 - t)}ms): {data}",
                  VerboseLevel.Debug)
        if data.get("code") == 0:
            d = data.get("data") or {}
            ssoPacketList = d.get("ssoPacketList") or d.get("requestCallback") or data.get("data")
            if not ssoPacketList or len(ssoPacketList) < 1:
                return []
            return ssoPacketList
    return []


async def getApiQQVer(self) -> str:
    QQVer = self.config.get("ver", "")
    if not self.sig.sign_api_addr:
        return QQVer
    apks = self.getApkInfoList(self.config["platform"])
    packageName = self.apk["id"]
    url = _rewrite_url(self.sig.sign_api_addr, "/ver")
    data = await _get(self, url)
    if data.get("code") == 0:
        vers = (data.get("data") or {}).get(packageName)
        if vers and len(vers) > 0:
            for ver in vers:
                if any(val["ver"] == ver for val in apks):
                    QQVer = ver
                    break
    return QQVer


async def getCmdWhiteList(self) -> List[str]:
    whiteList: List[str] = []
    if not self.sig.sign_api_addr:
        return whiteList
    url = _rewrite_url(self.sig.sign_api_addr, "/cmd_whitelist")
    data = await _get(self, url, {
        "ver": self.apk["ver"],
        "uin": self.uin or 0,
    })
    if data.get("code") == 0:
        whiteList = (data.get("data") or {}).get("list") or []
    return whiteList


def _rewrite_url(addr: str, suffix: str) -> str:
    """把签名 api 地址的 path 换成指定后缀（suffix 不带前导 /，与 JS 一致）。

    JS 原逻辑：path 以 / 结尾 → 直接追加 suffix；否则把结尾的 /sign 替换为 suffix。
    """
    parsed = urlparse(addr)
    path = parsed.path
    if path.endswith("/"):
        path += suffix
    else:
        path = re.sub(r"/sign$", suffix, path)
    return urlunparse(parsed._replace(path=path))


async def _get(self, url: str, params: Dict[str, Any] = None, post: bool = False) -> Dict[str, Any]:
    headers = {
        "User-Agent": f"icqq@{self.pkg['version']} (Released on {self.pkg['upday']})",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    data: Dict[str, Any] = {"code": -1}
    num = 0
    while data.get("code") == -1 and num < 3:
        if num > 0:
            await asyncio.sleep(2)
        num += 1
        try:
            if post:
                data = await http_post_form_json(url, params, headers=headers, timeout=20.0)
            else:
                data = await http_get_json(url, params, headers=headers, timeout=20.0)
        except Exception as e:
            data = {"code": -1, "msg": str(e)}
    return data
