"""Node.js 事件机制的 asyncio 版本。

- EventEmitter：icqq 的 Network 等组件使用（on/once/off/emit），监听器同步触发，
  返回 coroutine 则 create_task（与 JS Promise 不等待语义一致）。
- Trapper：triptrap 库的等价实现。BaseClient 继承它：
  - trap(matcher, listener)：matcher 为事件名字符串 / 过滤函数 / 任意对象
    （对象用引用相等匹配，如 EVENT_KICKOFF）
  - trip(matcher, *args)：分发；listener 以 trap 所属实例为 this 调用
    （JS listener.apply(this, args)），过滤函数以 (matcher, *args) 调用
"""
from __future__ import annotations

import asyncio
from typing import Any, Callable, Dict, List


class EventEmitter:
    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = {}

    def on(self, name: str, fn: Callable) -> None:
        self._listeners.setdefault(name, []).append(fn)

    def once(self, name: str, fn: Callable) -> None:
        def wrapper(*args: Any, **kwargs: Any):
            self.off(name, wrapper)
            return fn(*args, **kwargs)

        self.on(name, wrapper)

    def off(self, name: str, fn: Callable) -> None:
        listeners = self._listeners.get(name)
        if listeners:
            try:
                listeners.remove(fn)
            except ValueError:
                pass

    def removeAllListeners(self, name: str = "") -> None:
        if name:
            self._listeners.pop(name, None)
        else:
            self._listeners.clear()

    def listeners(self, name: str) -> List[Callable]:
        return list(self._listeners.get(name, []))

    def listenerCount(self, name: str) -> int:
        return len(self._listeners.get(name, []))

    def emit(self, name: str, *args: Any) -> List[Any]:
        """同步触发监听器，返回各监听器的返回值列表。

        coroutine 返回值不会在此处被调度（与 JS 一致，emit 不等待）；
        调用方可根据需要 await 返回的 coroutine。
        """
        results = []
        for fn in self.listeners(name):
            results.append(fn(*args))
        return results


class Trapper:
    """triptrap 的等价实现（BaseClient 的事件系统）。"""

    def __init__(self):
        self._traps: List[List[Any]] = []  # [matcher, listener, once]

    def trap(self, matcher, listener) -> None:
        self._traps.append([matcher, listener, False])

    def trapOnce(self, matcher, listener) -> None:
        self._traps.append([matcher, listener, True])

    def offTrap(self, matcher) -> None:
        self._traps = [t for t in self._traps if t[0] is not matcher]

    def listeners(self, matcher) -> List[Callable]:
        return [t[1] for t in self._traps if t[0] is matcher]

    def listenerCount(self, matcher) -> int:
        return sum(1 for t in self._traps if t[0] is matcher)

    def trip(self, matcher, *args: Any) -> None:
        for trap in list(self._traps):
            m, fn, once = trap
            if isinstance(m, str):
                matched = m == matcher
            elif callable(m):
                matched = bool(m(matcher, *args))
            else:
                matched = m is matcher
            if not matched:
                continue
            if once:
                try:
                    self._traps.remove(trap)
                except ValueError:
                    pass
            result = fn(self, *args)  # JS: listener.apply(this, args)
            if asyncio.iscoroutine(result):
                asyncio.create_task(result)
