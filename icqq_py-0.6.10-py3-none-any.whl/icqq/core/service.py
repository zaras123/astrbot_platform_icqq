"""icqq 官方签名服务（core/service.js 的移植）。"""
from __future__ import annotations

import asyncio

from .constants import BUF0
from .http import http_get_json


async def getT544(self, *cmds: str) -> None:
    """从 icqq 官方 energy 服务获取 t544 签名数据，结果写入 self.sig.t544[cmd]。"""
    if self.apk["display"] == "Android_8.8.88":
        return
    if not self.sig.t544:
        self.sig.t544 = {}
    await asyncio.gather(
        *(_getT544_one(self, cmd) for cmd in cmds)
    )


async def _getT544_one(self, cmd: str) -> None:
    try:
        data = await http_get_json(
            "http://icqq.tencentola.com/txapi/8.9.50/energy",
            params={
                "version": self.apk["sdkver"],
                "uin": self.uin,
                "guid": self.device.guid.hex(),
                "data": cmd,
            },
            timeout=5.0,
        )
    except Exception:
        data = {"code": -1}
    if data.get("code") == 0:
        self.sig.t544[cmd] = bytes.fromhex(data["data"])
