"""TCP 网络层（core/network.js 的移植）：4 字节大端长度分帧的 QQ 长连接。"""
from __future__ import annotations

import asyncio
import socket
from typing import Optional

from .buffer import u32
from .constants import BUF0, NOOP, timestamp
from .emitter import EventEmitter
from .http import http_post
from .jce import decode as jce_decode
from .jce import decodeWrapper, encodeStruct, encodeWrapper
from .tea import decrypt as tea_decrypt
from .tea import encrypt as tea_encrypt

default_host = "msfwifi.3g.qq.com"
default_port = 8080

update_time = 0
searching: Optional[asyncio.Future] = None
host_port = {}


class Network(EventEmitter):
    """@event connect2
    @event packet
    @event lost
    """

    def __init__(self):
        super().__init__()
        self.host = default_host
        self.port = default_port
        self.auto_search = True
        self.connected = False
        self.buf = BUF0
        self._reader: Optional[asyncio.StreamReader] = None
        self._writer: Optional[asyncio.StreamWriter] = None
        self._connecting = False
        self._read_task: Optional[asyncio.Task] = None
        self._closed = False

    async def join(self, cb=NOOP) -> None:
        if self._connecting:
            return
        if self.connected:
            return cb()
        self._connecting = True
        try:
            self._reader, self._writer = await asyncio.open_connection(
                self.host, self.port, family=socket.AF_INET
            )
        except OSError:
            # JS: connect 失败走 error 事件；这里交给上层重试
            self._connecting = False
            raise
        self._connecting = False
        self.connected = True
        self.emit("connect2")
        cb()
        self._read_task = asyncio.create_task(self._read_loop())
        self.resolve()

    @property
    def remoteAddress(self):
        if self._writer is None:
            return ""
        peername = self._writer.get_extra_info("peername")
        return peername[0] if peername else ""

    @property
    def remotePort(self):
        if self._writer is None:
            return 0
        peername = self._writer.get_extra_info("peername")
        return peername[1] if peername else 0

    async def _read_loop(self) -> None:
        global host_port
        try:
            while not self._closed:
                chunk = await self._reader.read(65536)
                if not chunk:
                    break
                self.buf = chunk if len(self.buf) == 0 else self.buf + chunk
                while len(self.buf) > 4:
                    length = u32(self.buf)
                    if len(self.buf) >= length:
                        packet = self.buf[4:length]
                        self.buf = self.buf[length:]
                        # packet 监听器是 async 的，按序等待（保证解析顺序）
                        for r in self.emit("packet", packet):
                            if asyncio.iscoroutine(r):
                                await r
                    else:
                        break
        finally:
            # 对应 JS 的 close 事件处理
            self.buf = BUF0
            self.emit("close")
            if self.connected:
                self.connected = False
                host_port.pop(self.host, None)
                self.resolve()
                self.emit("lost")

    def write(self, data: bytes) -> None:
        """发送原始字节（base-client 通过此方法发包）。"""
        if self._writer is None:
            raise RuntimeError("network not connected")
        self._writer.write(data)

    def close(self) -> None:
        self._closed = True
        if self._writer is not None:
            self._writer.close()
        if self._read_task is not None:
            self._read_task.cancel()

    def resolve(self) -> None:
        global searching
        if not self.auto_search:
            return
        iplist = list(host_port.keys())
        if len(iplist) > 0:
            self.host = iplist[0]
            self.port = host_port[self.host]
        if timestamp() - update_time >= 3600 and searching is None:
            searching = True  # 置位防止并发重复搜索
            asyncio.create_task(self._search())

    async def _search(self) -> None:
        global searching, update_time, host_port
        try:
            m = await fetchServerList()
        except Exception:
            return
        finally:
            searching = None
        lst = list(m.keys())[:3]
        if lst[0] and lst[1]:
            update_time = timestamp()
            host_port = {}
            host_port[lst[0]] = m[lst[0]]
            host_port[lst[1]] = m[lst[1]]


async def fetchServerList() -> dict:
    """从腾讯配置服务器获取 sso 服务器 ip:port 列表（通常只有前两个ip比较稳定）。"""
    key = bytes.fromhex("F0441F5FF42DA58FDCF7949ABA62D411")
    HttpServerListReq = encodeStruct([
        None,
        0, 0, 1, "00000", 100, 537064989, "356235088634151", 0, 0, 0,
        0, 0, 0, 1,
    ])
    body = encodeWrapper({"HttpServerListReq": HttpServerListReq}, "ConfigHttp", "HttpServerListReq")
    body = (len(body) + 4).to_bytes(4, "big") + body
    body = tea_encrypt(body, key)
    data = await http_post(
        "https://configsvr.msf.3g.qq.com/configsvr/serverlist.jsp?mType=getssolist",
        data=body,
        timeout=10.0,
    )
    buf = tea_decrypt(data, key)[4:]
    nested = decodeWrapper(buf)
    m = {}
    for v in nested[2]:
        m[v[1]] = v[2]
    return m
