"""协议客户端基类（core/base-client.js 的移植）：登录流程、发包收包、心跳、签名。

Symbol 私有字段（JS）→ Python 双下划线私有属性：
- [IS_ONLINE] → __is_online    [LOGIN_LOCK] → __login_lock
- [ECDH] → __ecdh              [NET] → __net
- [HANDLERS] → __handlers（seq → 回包回调）
- [FN_NEXT_SEQ]/[FN_SEND]/[FN_SEND_LOGIN] → __next_seq/_send/_send_login
- [HEARTBEAT] → __heartbeat_task
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import time
import traceback
from enum import IntEnum
from typing import Any, Callable, Dict, List, Optional, Union
from urllib.parse import parse_qs, urlparse

from . import pb, tea, tlv
from .buffer import Reader, i32, u32
from .constants import BUF0, BUF4, BUF16, NOOP, int32ip2str, md5, timestamp, unzip
from .device import Device, Platform, getApkInfoList as device_getApkInfoList
from .ecdh import Ecdh
from .emitter import Trapper
from .jce import decode as jce_decode
from .jce import decodeWrapper, encodeStruct, encodeWrapper
from .network import Network
from .writer import Writer

PKG = {
    "name": "icqq",
    "version": "0.6.10",
    "upday": "2024/2/4",
}

# JS Symbol("EVENT_KICKOFF") 的等价物
EVENT_KICKOFF = object()


class VerboseLevel(IntEnum):
    Fatal = 0
    Mark = 1
    Error = 2
    Warn = 3
    Info = 4
    Debug = 5


class ApiRejection(Exception):
    def __init__(self, code, message="unknown"):
        try:
            self.code = int(code)
        except (TypeError, ValueError):
            self.code = code
        self.message = str(message) if message is not None else "unknown"
        super().__init__(f"ApiRejection({self.code}): {self.message}")


class QrcodeResult(IntEnum):
    OtherError = 0
    Timeout = 17
    WaitingForScan = 48
    WaitingForConfirm = 53
    Canceled = 54


class Sig:
    """会话签名信息（JS 中是 base-client 构造器里创建的普通对象）。"""

    def __init__(self, uin: int = 0):
        self.seq = int.from_bytes(os.urandom(4), "big") & 0xFFF
        self.session = os.urandom(4)
        self.randkey = os.urandom(16)
        self.tgtgt = os.urandom(16)
        self.tgt = BUF0
        self.skey = BUF0
        self.a1 = BUF0
        self.d2 = BUF0
        self.d2key = BUF0
        self.old_d2key = BUF16
        self.st_web = BUF0
        self.t104 = BUF0
        self.t174 = BUF0
        self.qrsig = BUF0
        self.t543 = BUF0
        self.t546 = BUF0
        self.t547 = BUF0
        self.t553 = BUF0
        # 大数据上传通道
        self.bigdata = {"ip": "", "port": 0, "sig_session": BUF0, "session_key": BUF0}
        # 心跳包
        hb = Writer().writeU32(uin).write32(0x19E39).read()
        self.hb480 = pb.encode({1: 1152, 2: 9, 4: hb})
        self.sign_api_addr = ""
        self.sign_api_init = False
        # 上次cookie刷新时间
        self.emp_time = 0
        self.time_diff = 0
        self.requestTokenTime = 0
        # token登录重试计数
        self.token_retry_count = 0
        # 上线失败重试计数
        self.register_retry_count = 0
        # service.js 的 t544 缓存
        self.t544: Dict[str, bytes] = {}
        # 运行时动态添加的字段（对应 JS 中后续赋值）
        self.tgt_key = BUF0
        self.st_key = BUF0
        self.sig_key = BUF0
        self.ticket_key = BUF0
        self.device_token = BUF0
        self.srm_token = BUF0
        self.ksid: Optional[bytes] = None
        self.md5Pass = BUF0
        self.dPwd = BUF0
        self.t402 = BUF0
        self.g = BUF0
        self.randomSeed = BUF0


class BaseClient(Trapper):
    def __init__(self, p=Platform.Android, d=None, config: Dict[str, Any] = None):
        super().__init__()
        self.config = config or {}
        self.__is_online = False
        self.__login_lock = False
        self.__ecdh = Ecdh()
        self.__net = Network()
        # 回包的回调函数
        self.__handlers: Dict[int, Callable[[bytes], None]] = {}
        self.__heartbeat_task: Optional[asyncio.Task] = None
        self.sig = Sig()
        self.pkg = PKG
        self.pskey: Dict[str, bytes] = {}
        self.pt4token: Dict[str, bytes] = {}
        # 心跳间隔(秒)
        self.interval = 60
        # token刷新间隔(秒)
        self.emp_interval = 12 * 3600
        # 随心跳一起触发的函数，可以随意设定
        self.heartbeat: Callable = NOOP
        # token登录重试次数
        self.token_retry_num = 2
        # 上线失败重试次数
        self.register_retry_num = 3
        self.login_timer = None
        # 数据统计
        self.statistics = {
            "start_time": timestamp(),
            "lost_times": 0,
            "recv_pkt_cnt": 0,
            "sent_pkt_cnt": 0,
            "lost_pkt_cnt": 0,
            "recv_msg_cnt": 0,
            "sent_msg_cnt": 0,
            "msg_cnt_per_min": 0,
            "remote_ip": "",
            "remote_port": 0,
            "ver": "",
        }
        self.signCmd = [
            "trpc.o3.ecdh_access.EcdhAccess.SsoSecureA2Establish",
            "trpc.o3.ecdh_access.EcdhAccess.SsoSecureA2Access",
            "OidbSvcTrpcTcp.0xf88_1",
            "OidbSvcTrpcTcp.0x1105_1",
            "trpc.o3.report.Report.SsoReport",
            "wtlogin.trans_emp",
            "OidbSvcTrpcTcp.0xf89_1",
            "wtlogin_device.login",
            "OidbSvcTrpcTcp.0xf67_5",
            "OidbSvcTrpcTcp.0xfa5_1",
            "OidbSvcTrpcTcp.0x55f_0",
            "wtlogin.device_lock",
            "qidianservice.207",
            "wtlogin_device.tran_sim_emp",
            "OidbSvc.0x758_0",
            "SQQzoneSvc.addReply",
            "trpc.o3.ecdh_access.EcdhAccess.SsoEstablishShareKey",
            "OidbSvc.0x89a_0",
            "trpc.passwd.manager.PasswdManager.SetPasswd",
            "QQConnectLogin.pre_auth",
            "trpc.qlive.word_svr.WordSvr.NewPublicChat",
            "OidbSvc.0x8a1_0",
            "SQQzoneSvc.publishmood",
            "OidbSvcTrpcTcp.0x101e_2",
            "OidbSvcTrpcTcp.0x101e_1",
            "OidbSvcTrpcTcp.0xf67_1",
            "OidbSvcTrpcTcp.0xf6e_1",
            "OidbSvc.0x8a1_7",
            "OidbSvc.0x758_1",
            "OidbSvc.0x4ff_9",
            "OidbSvc.0x88d_0",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoLike",
            "SQQzoneSvc.addComment",
            "MessageSvc.PbSendMsg",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoComment",
            "SQQzoneSvc.shuoshuo",
            "SQQzoneSvc.like",
            "trpc.o3.ecdh_access.EcdhAccess.SsoSecureAccess",
            "OidbSvc.0x758",
            "QChannelSvr.trpc.qchannel.commwriter.ComWriter.DoComment",
            "QChannelSvr.trpc.qchannel.commwriter.ComWriter.DoReply",
            "wtlogin.qrlogin",
            "OidbSvcTrpcTcp.0xf57_1",
            "OidbSvc.oidb_0x758",
            "OidbSvcTrpcTcp.0xf57_9",
            "wtlogin.exchange_emp",
            "OidbSvc.0x56c_6",
            "QChannelSvr.trpc.qchannel.commwriter.ComWriter.PublishFeed",
            "OidbSvcTrpcTcp.0xf55_1",
            "OidbSvcTrpcTcp.0x6d9_4",
            "trpc.qlive.relationchain_svr.RelationchainSvr.Follow",
            "ProfileService.GroupMngReq",
            "ProfileService.getGroupInfoReq",
            "ConnAuthSvr.get_app_info_emp",
            "OidbSvcTrpcTcp.0x1100_1",
            "FeedCloudSvr.trpc.videocircle.circleprofile.CircleProfile.SetProfile",
            "qidianservice.135",
            "trpc.group_pro.msgproxy.sendmsg",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoPush",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoReply",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoBarrage",
            "QQConnectLogin.get_promote_page",
            "friendlist.addFriend",
            "SQQzoneSvc.forward",
            "OidbSvc.0x4ff_9_IMCore",
            "OidbSvc.0x6d9_4",
            "trpc.springfestival.redpacket.LuckyBag.SsoSubmitGrade",
            "wtlogin.login",
            "OidbSvc.0x89b_1",
            "trpc.qqhb.qqhb_proxy.Handler.sso_handle",
            "qidianservice.290",
            "wtlogin.register",
            "OidbSvc.0x8ba",
            "ConnAuthSvr.sdk_auth_api_emp",
            "OidbSvc.0x9fa",
            "qidianservice.269",
            "OidbSvcTrpcTcp.0xf65_1",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.PublishFeed",
            "OidbSvcTrpcTcp.0xf65_10",
            "ConnAuthSvr.fast_qq_login",
            "trpc.login.ecdh.EcdhService.SsoQRLoginGenQr",
            "friendlist.AddFriendReq",
            "MsgProxy.SendMsg",
            "trpc.login.ecdh.EcdhService.SsoNTLoginPasswordLoginUnusualDevice",
            "trpc.passwd.manager.PasswdManager.VerifyPasswd",
            "trpc.login.ecdh.EcdhService.SsoQRLoginScanQr",
            "QQConnectLogin.get_promote_page_emp",
            "FeedCloudSvr.trpc.feedcloud.commwriter.ComWriter.DoFollow",
            "QQConnectLogin.submit_promote_page",
            "friendlist.ModifyGroupInfoReq",
            "OidbSvcTrpcTcp.0xf57_106",
            "QQConnectLogin.submit_promote_page_emp",
            "OidbSvcTrpcTcp.0x1107_1",
            "QQConnectLogin.pre_auth_emp",
            "ConnAuthSvr.get_app_info",
            "ConnAuthSvr.sdk_auth_api",
            "wtlogin.name2uin",
            "QQConnectLogin.auth",
            "ConnAuthSvr.get_auth_api_list_emp",
            "QQConnectLogin.auth_emp",
            "ConnAuthSvr.get_auth_api_list",
        ]
        self.ssoPacketList: List[Dict[str, Any]] = []
        self.apk = self.getApkInfo(p, config.get("ver"))
        self.device = Device(self.apk, d)

        self.__net.on("error", lambda err: self.emit("internal.verbose", str(err), VerboseLevel.Error))
        self.__net.on("close", lambda: self.__on_net_close())
        self.__net.on("connect2", lambda: self.__on_net_connect())
        self.__net.on("packet", lambda pkt: packet_listener(self, pkt))
        self.__net.on("lost", lambda: lost_listener(self))
        self.on("internal.online", online_listener)
        self.on("internal.sso", sso_listener)
        self.uin = 0
        self.uid = ""

    # ---- 网络事件（JS 里 NET.on(...) 的箭头函数体） ----

    def __on_net_close(self):
        self.statistics["remote_ip"] = ""
        self.statistics["remote_port"] = 0
        if self.__net.remoteAddress:
            self.emit("internal.verbose",
                      f"{self.__net.remoteAddress}:{self.__net.remotePort} closed", VerboseLevel.Mark)

    def __on_net_connect(self):
        self.statistics["remote_ip"] = self.__net.remoteAddress
        self.statistics["remote_port"] = self.__net.remotePort
        self.emit("internal.verbose",
                  f"{self.__net.remoteAddress}:{self.__net.remotePort} connected", VerboseLevel.Mark)
        self.syncTimeDiff()

    # ---- 连接管理 ----

    def setRemoteServer(self, host: str, port: int) -> None:
        """设置连接服务器，不设置则自动搜索"""
        if host and port:
            self.__net.host = host
            self.__net.port = port
            self.__net.auto_search = False
        else:
            self.__net.auto_search = True

    def setSignServer(self, addr: str) -> None:
        # JS 中为 async（内部无 await，require 是同步的），Python 版改为同步函数，
        # 这样构造器里可直接调用；调用处 `await self.setSignServer(...)` 依然合法。
        if not addr:
            return
        self.sig.sign_api_init = False
        if not re.match(r"http(s)?://", addr):
            addr = f"http://{addr}"
        self.sig.sign_api_addr = addr
        parsed = urlparse(addr)
        if parse_qs(parsed.query).get("key"):
            from . import qsign as module
        else:
            from . import sign as module

            self.getCmdWhiteList = lambda: module.getCmdWhiteList(self)
        self.getApiQQVer = lambda: module.getApiQQVer(self)
        self.getT544 = lambda cmd: module.getT544(self, cmd)
        self.getSign = lambda cmd, seq, body: module.getSign(self, cmd, seq, body)
        self.requestSignToken = lambda: module.requestSignToken(self)
        self.submitSsoPacket = lambda cmd, callbackId, body: module.submitSsoPacket(self, cmd, callbackId, body)
        self.sig.sign_api_init = True

    # ---- Trapper 包装（与 JS 一致，BaseClient 用 trap 系列代替 EventEmitter） ----

    def on(self, matcher, listener) -> None:
        return self.trap(matcher, listener)

    def once(self, matcher, listener) -> None:
        return self.trapOnce(matcher, listener)

    def off(self, matcher) -> None:
        return self.offTrap(matcher)

    def emit(self, matcher, *args) -> None:
        return self.trip(matcher, *args)

    def isOnline(self) -> bool:
        """是否为在线状态 (可以收发业务包的状态)"""
        return self.__is_online

    # ---- 协议信息 ----

    def getApkInfo(self, platform, ver=None) -> Dict[str, Any]:
        if platform == Platform.iPad:
            platform = Platform.aPad
        apks = self.getApkInfoList(platform)
        for val in apks:
            if val["ver"] == ver:
                return val
        return apks[0]

    def getApkInfoList(self, platform) -> List[Dict[str, Any]]:
        return device_getApkInfoList(platform)

    def buildReserveFields(self, cmd: str, sec_info: bytes) -> bytes:
        qImei36 = self.device.qImei36 or self.device.qImei16
        if self.apk["ssover"] >= 20 and False:
            reserveFields = {
                9: 1,
                11: 2052,
                12: qImei36,
                14: 0,
                15: "",
                16: self.uid or "",
                18: 0,
                19: 1,
                20: 1,
                21: 32,
                24: sec_info,
                26: 100,
                28: 3,
            }
        else:
            reserveFields = {
                9: 1,
                12: qImei36,
                14: 0,
                16: self.uin,
                18: 0,
                19: 1,
                20: 1,
                21: 0,
                24: sec_info,
                28: 3,
            }
        return pb.encode(reserveFields)

    async def switchQQVer(self, ver: str = "") -> bool:
        if self.config.get("sign_api_addr") and not self.sig.sign_api_init:
            await self.setSignServer(self.config["sign_api_addr"])
        if self.config.get("ver"):
            self.statistics["ver"] = self.config["ver"]
            return False
        old_ver = self.statistics["ver"] or self.config.get("ver")
        ver = ver or await self.getApiQQVer()
        if old_ver != ver:
            new_apk = self.getApkInfo(self.config["platform"], ver)
            if new_apk["ver"] == ver:
                self.apk = new_apk
                self.device.apk = self.apk
                self.statistics["ver"] = ver
                return True
        return False

    async def updateCmdWhiteList(self) -> None:
        lst = await self.getCmdWhiteList()
        if lst and len(lst):
            self.signCmd = list(dict.fromkeys(self.signCmd + list(lst)))

    # 以下为默认实现，配置签名服务器后会被 sign/qsign 模块的实现覆盖
    async def getCmdWhiteList(self) -> List[str]:
        return []

    async def getApiQQVer(self) -> str:
        return self.config.get("ver", "")

    async def getT544(self, cmd: str) -> bytes:
        return self.generateT544Packet(cmd, BUF0)

    async def getSign(self, cmd: str, seq: int, body: bytes) -> bytes:
        return BUF0

    def generateT544Packet(self, cmd: str, sign: bytes) -> bytes:
        t = tlv.getPacker(self)

        def getLocalT544(cmd: str) -> bytes:
            if cmd == "810_2":
                return t(0x544, 0, 2)
            if cmd == "810_7":
                return t(0x544, 0, 7)
            if cmd == "810_9":
                return t(0x544, 2, 9)
            if cmd == "810_a":
                return t(0x544, 2, 10)
            if cmd == "810_f":
                return t(0x544, 2, 15)
            return BUF0

        if not sign or len(sign) < 1:
            return getLocalT544(cmd)
        return t(0x544, -1, -1, sign)

    def generateSignPacket(self, sign: str, token: str, extra: str) -> bytes:
        if not sign:
            return BUF0
        sec_info = {
            1: bytes.fromhex(sign),
            2: bytes.fromhex(token),
            3: bytes.fromhex(extra),
        }
        return pb.encode(sec_info)

    async def ssoPacketListHandler(self, lst) -> None:
        def handle(l):
            new_list = []
            for val in l:
                try:
                    data = pb.decode(bytes.fromhex(val["body"]))
                    val["type"] = data[1].toString()
                except Exception:
                    pass
                new_list.append(val)
            return new_list

        if lst is None and self.isOnline():
            if len(self.ssoPacketList) > 0:
                lst = self.ssoPacketList
                self.ssoPacketList = []
        if not lst or not len(lst):
            return
        if not self.isOnline():
            lst = handle(lst)
            if len(self.ssoPacketList) > 0:
                list1 = self.ssoPacketList
                self.ssoPacketList = []
                for val in lst:
                    ssoPacket = next(
                        (d for d in list1 if d["cmd"] == val["cmd"] and d["type"] == val["type"]),
                        None,
                    )
                    if ssoPacket:
                        ssoPacket["body"] = val["body"]
                    else:
                        list1.append(val)
                # 注意：JS 原版这里合并结果会丢失（疑似 bug），此处按显然意图回写
                self.ssoPacketList = list1
            else:
                self.ssoPacketList = self.ssoPacketList + lst
            return
        for ssoPacket in lst:
            cmd = ssoPacket["cmd"]
            body = bytes.fromhex(ssoPacket["body"])
            callbackId = ssoPacket.get("callbackId", -1)
            payload = await self.sendUni(cmd, body)
            self.emit("internal.verbose", f"sendUni:{cmd} result: {payload.hex()}", VerboseLevel.Debug)
            if callbackId > -1:
                await self.submitSsoPacket(cmd, callbackId, payload)

    async def requestToken(self) -> None:
        if (time.time() * 1000 - self.sig.requestTokenTime) >= (60 * 60 * 1000):
            self.sig.requestTokenTime = time.time() * 1000
            lst = await self.requestSignToken()
            await self.ssoPacketListHandler(lst)

    async def requestSignToken(self) -> List[Any]:
        return []

    async def submitSsoPacket(self, cmd: str, callbackId: int, body: bytes) -> List[Any]:
        return []

    def calcPoW(self, data: bytes) -> bytes:
        """tlv546 的 PoW 计算（JS 同步执行，此处保持一致；单次约 1 万次 sha256）。"""
        if not data or len(data) == 0:
            return bytes(0)
        r = Reader(data)
        version = r.readUInt8()
        typ = r.readUInt8()
        hashType = r.readUInt8()
        ok = r.readUInt8() == 0
        maxIndex = r.readUInt16BE()
        reserveBytes = r.read(2)
        src = r.read(r.readUInt16BE())
        tgt = r.read(r.readUInt16BE())
        cpy = r.read(r.readUInt16BE())
        if hashType != 1:
            self.emit("internal.verbose", f"Unsupported tlv546 hash type {hashType}", VerboseLevel.Warn)
            return bytes(0)
        inputNum = int(src.hex(), 16)
        if typ == 1:
            # TODO
            # See https://github.com/mamoe/mirai/blob/cc7f35519ea7cc03518a57dc2ee90d024f63be0e/mirai-core/src/commonMain/kotlin/network/protocol/packet/login/wtlogin/WtLoginExt.kt#L207
            self.emit("internal.verbose", f"Unsupported tlv546 algorithm type {typ}", VerboseLevel.Warn)
        elif typ == 2:
            # Calc SHA256
            dst = None
            elp = 0
            cnt = 0
            if len(tgt) == 32:
                start = time.time() * 1000
                h = hashlib.sha256(bytes.fromhex(format(inputNum, "x").rjust(256, "0"))).digest()
                while h != tgt:
                    inputNum += 1
                    h = hashlib.sha256(bytes.fromhex(format(inputNum, "x").rjust(256, "0"))).digest()
                    cnt += 1
                    if cnt > 6000000:
                        self.emit("internal.verbose", "Calculating PoW cost too much time, maybe something wrong",
                                  VerboseLevel.Error)
                        raise Exception("Calculating PoW cost too much time, maybe something wrong")
                ok = True
                dst = bytes.fromhex(format(inputNum, "x").rjust(256, "0"))
                elp = time.time() * 1000 - start
                self.emit("internal.verbose", f"Calculating PoW of plus {cnt} times cost {elp} ms",
                          VerboseLevel.Debug)
            if not ok:
                return bytes(0)
            body = (
                Writer()
                .writeU8(version)
                .writeU8(typ)
                .writeU8(hashType)
                .writeU8(1 if ok else 0)
                .writeU16(maxIndex)
                .writeBytes(reserveBytes)
                .writeTlv(src)
                .writeTlv(tgt)
                .writeTlv(cpy)
            )
            if dst:
                body.writeTlv(dst)
            body.writeU32(int(elp)).writeU32(cnt)
            return body.read()
        else:
            self.emit("internal.verbose", f"Unsupported tlv546 algorithm type {typ}", VerboseLevel.Warn)
        return bytes(0)

    async def logout(self, keepalive: bool = False) -> None:
        """下线 (keepalive: 是否保持tcp连接)"""
        await self.register(True)
        if not keepalive and self.__net.connected:
            fut = asyncio.get_running_loop().create_future()
            self.__net.once("close", lambda: fut.set_result(None))
            self.terminate()
            await fut

    def terminate(self) -> None:
        """关闭连接"""
        self.__is_online = False
        self.__net.close()

    async def refreshToken(self, force: bool = False) -> bool:
        return await refresh_token(self, force)

    # ---- 登录 ----

    async def tokenLogin(self, token: bytes = BUF0, cmd: int = 11) -> bytes:
        """使用接收到的token登录"""
        if not self.device.qImei36 or not self.device.qImei16:
            await self.device.getQIMEI()
        if token != BUF0:
            self.sig.randkey = os.urandom(16)
            self.sig.session = os.urandom(4)
            self.__ecdh = Ecdh()
            try:
                r = Reader(token)
                info = r.read(r.readUInt16BE())
                if "icqq" in (info.decode("utf-8", errors="replace") or ""):
                    info = json.loads(info.decode("utf-8", errors="replace"))
                    if info["apk"]["version"] != self.apk["version"]:
                        if info["apk"]["id"] != self.apk["id"] or (
                            self.statistics["ver"] and info["apk"]["subid"] > self.apk["subid"]
                        ):
                            self.sig.token_retry_count = self.token_retry_num
                            await self.token_expire()
                            return BUF0
                        elif not self.statistics["ver"]:
                            if await self.switchQQVer(info["apk"]["ver"]):
                                self.emit("internal.verbose",
                                          f"[{self.uin}]获取到token协议版本：{self.statistics['ver']}",
                                          VerboseLevel.Info)
                                apk_info = f"{self.apk['display']}_{self.apk['version']}"
                                self.emit("internal.verbose", f"[{self.uin}]使用协议：{apk_info}",
                                          VerboseLevel.Info)
                                await self.device.getQIMEI()
                    t119 = r.read(r.readUInt16BE())
                    self.sig.tgtgt = r.read(r.readUInt16BE())
                    self.sig.a1 = r.read(r.readUInt16BE())
                    self.sig.d2 = r.read(r.readUInt16BE())
                    self.sig.d2key = r.read(r.readUInt16BE())
                    self.sig.tgt = r.read(r.readUInt16BE())
                    self.sig.tgt_key = r.read(r.readUInt16BE())
                    self.sig.ticket_key = r.read(r.readUInt16BE())
                    self.sig.sig_key = r.read(r.readUInt16BE())
                    self.sig.srm_token = r.read(r.readUInt16BE())
                    self.sig.device_token = r.read(r.readUInt16BE())
                    self.sig.t543 = r.read(r.readUInt16BE())
                    if info["token_ver"] >= 3:
                        self.sig.randkey = r.read(r.readUInt16BE())
                        self.sig.session = r.read(r.readUInt16BE())
                    if self.sig.token_retry_count == 0 and info["token_ver"] >= 3:
                        read_bigdata(self)
                        dec = decode_t119(self, t119)
                        nickname, gender, age = dec["nickname"], dec["gender"], dec["age"]
                        err = await self.register()
                        if err == 1:
                            self.sig.emp_time = info["emp_time"]
                            self.sig.register_retry_count = 0
                            await self.updateCmdWhiteList()
                            await self.ssoPacketListHandler(None)
                            self.emit("internal.online", BUF0, nickname, gender, age)
                            return BUF0
                        elif err == -2:
                            return BUF0
                else:
                    self.sig.d2key = info
                    self.sig.d2 = r.read(r.readUInt16BE())
                    self.sig.tgt = r.read(r.readUInt16BE())
                    self.sig.ticket_key = r.read(r.readUInt16BE())
                    self.sig.sig_key = r.read(r.readUInt16BE())
                    self.sig.srm_token = r.read(r.readUInt16BE())
                    self.sig.tgt = r.read(r.readUInt16BE())
                    self.sig.md5Pass = r.read(r.readUInt16BE())
                    self.sig.device_token = r.read(r.readUInt16BE())
                    try:
                        self.sig.t543 = r.read(r.readUInt16BE()) or BUF0
                    except Exception:
                        pass
            except Exception:
                self.emit("internal.verbose", "旧版token于当前版本不兼容，请手动删除token后重新运行",
                          VerboseLevel.Error)
                self.emit("internal.verbose", "若非无法登录，请勿随意升级版本", VerboseLevel.Warn)
                self.emit("internal.error.login", 123456, "token不兼容")
                return BUF0
        cmd = cmd if (len(self.sig.srm_token) and len(self.sig.a1)) else 11
        self.sig.tgtgt = self.sig.tgtgt if cmd == 15 else md5(self.sig.d2key)
        t = tlv.getPacker(self)
        tlvs = [
            t(0x8), t(0x18), t(0x100), t(0x116), t(0x141), t(0x142), t(0x144),
            t(0x145), t(0x147), t(0x154), t(0x177), t(0x187), t(0x188),
            t(0x511), t(0x542), t(0x548),
        ]
        if cmd == 15:
            tlvs += [
                t(0x1),
                Writer().writeU16(0x106).writeTlv(self.sig.a1).read(),
                t(0x107), t(0x16a), t(0x191), t(0x516), t(0x521, 0),
            ]
        else:
            tlvs += [t(0x108), t(0x10a), t(0x112), t(0x143)]
        if self.apk["ssover"] >= 5:
            tlvs.append(await self.getT544("810_f" if cmd == 15 else "810_a"))
            if self.sig.t553:
                tlvs.append(t(0x553))
        if self.device.qImei16:
            tlvs.append(t(0x545, self.device.qImei16))
        else:
            tlvs.append(t(0x194))
            tlvs.append(t(0x202))
        writer = Writer().writeU16(cmd).writeU16(len(tlvs))
        for v in tlvs:
            writer.writeBytes(v)
        body = writer.read()
        if token != BUF0:
            await self._send_login("wtlogin.exchange_emp", body)
            return BUF0
        return body

    async def passwordLogin(self, uin: int, md5pass: bytes) -> None:
        """使用密码登录"""
        if not self.device.qImei36 or not self.device.qImei16:
            await self.device.getQIMEI()
        self.uin = uin
        self.sig.session = os.urandom(4)
        self.sig.randkey = os.urandom(16)
        self.sig.tgtgt = os.urandom(16)
        self.__ecdh = Ecdh()
        t = tlv.getPacker(self)
        tlvs = [
            t(0x1), t(0x8), t(0x18), t(0x100), t(0x106, md5pass), t(0x107),
            t(0x116), t(0x141), t(0x142), t(0x144), t(0x145), t(0x147),
            t(0x154), t(0x177), t(0x187), t(0x188), t(0x191), t(0x511),
            t(0x516), t(0x521, 0), t(0x525), t(0x542), t(0x548),
        ]
        if self.apk["ssover"] >= 12:
            tlvs.append(await self.getT544("810_9"))
            if self.sig.t553:
                tlvs.append(t(0x553))
        if self.device.qImei16:
            tlvs.append(t(0x545, self.device.qImei16))
        else:
            tlvs.append(t(0x194))
            tlvs.append(t(0x202))
        writer = Writer().writeU16(9).writeU16(len(tlvs))
        for v in tlvs:
            writer.writeBytes(v)
        asyncio.create_task(self._send_login("wtlogin.login", writer.read()))

    async def submitSlider(self, ticket: str) -> None:
        """收到滑动验证码后，用于提交滑动验证码"""
        try:
            if len(self.sig.t546):
                self.sig.t547 = self.calcPoW(self.sig.t546)
        except Exception:
            pass
        ticket = str(ticket).strip()
        t = tlv.getPacker(self)
        tlvs = [t(0x8), t(0x104), t(0x116), t(0x193, ticket.encode("utf-8"))]
        if self.apk["ssover"] >= 12:
            tlvs.append(await self.getT544("810_2"))
            if self.sig.t553:
                tlvs.append(t(0x553))
        if len(self.sig.t547):
            tlvs.append(t(0x547))
        writer = Writer().writeU16(2).writeU16(len(tlvs))
        for v in tlvs:
            writer.writeBytes(v)
        asyncio.create_task(self._send_login("wtlogin.login", writer.read()))

    async def sendSmsCode(self) -> None:
        """收到设备锁验证请求后，用于发短信"""
        t = tlv.getPacker(self)
        tlv_count = 6
        writer = (
            Writer()
            .writeU16(8)
            .writeU16(tlv_count)
            .writeBytes(t(0x8))
            .writeBytes(t(0x104))
            .writeBytes(t(0x116))
            .writeBytes(t(0x174))
            .writeBytes(t(0x17a))
            .writeBytes(t(0x197))
        )
        asyncio.create_task(self._send_login("wtlogin.login", writer.read()))

    async def submitSmsCode(self, code: str) -> None:
        """提交短信验证码"""
        code = str(code).strip()
        if len(code.encode("utf-8")) != 6:
            code = "123456"
        t = tlv.getPacker(self)
        tlvs = [t(0x8), t(0x104), t(0x116), t(0x174), t(0x17c, code.encode("utf-8")), t(0x198), t(0x401)]
        if self.apk["ssover"] >= 12:
            tlvs.append(await self.getT544("810_7"))
            if self.sig.t553:
                tlvs.append(t(0x553))
        if len(self.sig.t547):
            tlvs.append(t(0x547))
        writer = Writer().writeU16(7).writeU16(len(tlvs))
        for v in tlvs:
            writer.writeBytes(v)
        asyncio.create_task(self._send_login("wtlogin.login", writer.read()))

    async def fetchQrcode(self) -> None:
        """获取登录二维码"""
        t = tlv.getPacker(self)
        body = (
            Writer()
            .writeU16(0)
            .writeU32(16)
            .writeU64(0)
            .writeU8(8)
            .writeTlv(BUF0)
            .writeU16(6)
            .writeBytes(t(0x16))
            .writeBytes(t(0x1B))
            .writeBytes(t(0x1D))
            .writeBytes(t(0x1F))
            .writeBytes(t(0x33))
            .writeBytes(t(0x35, self.apk["device_type"]))
            .read()
        )
        pkt = await build_code2d_packet(self, 0x31, 0x11100, body)

        async def task():
            try:
                payload = await self._send(pkt)
                payload = tea.decrypt(payload[16:-1], self.__ecdh.share_key)
                r = Reader(payload)
                r.read(54)
                retcode = r.read(1)[0]
                qrsig = r.read(r.readUInt16BE())
                r.read(2)
                t = read_tlv(r)
                if not retcode and 0x17 in t:
                    self.sig.qrsig = qrsig
                    self.emit("internal.qrcode", t[0x17])
                else:
                    self.emit("internal.error.qrcode", retcode, "获取二维码失败，请重试")
            except Exception:
                self.emit("internal.error.network", -2, "server is busy")

        asyncio.create_task(task())

    async def qrcodeLogin(self) -> None:
        """扫码后调用此方法登录"""
        result = await self.queryQrcodeResult()
        retcode = result["retcode"]
        uin = result["uin"]
        t106 = result["t106"]
        t16a = result["t16a"]
        t318 = result["t318"]
        tgtgt = result["tgtgt"]
        if retcode < 0:
            self.emit("internal.error.network", -2, "server is busy")
        elif retcode == 0 and t106 and t16a and t318 and tgtgt:
            if self.apk.get("qua") != "" and (not self.device.qImei36 or not self.device.qImei16):
                await self.device.getQIMEI()
            self.uin = uin
            self.sig.qrsig = BUF0
            self.sig.tgtgt = tgtgt
            t = tlv.getPacker(self)
            tlvs = [
                t(0x1), t(0x8), t(0x18), t(0x100),
                Writer().writeU16(0x106).writeTlv(t106).read(),
                t(0x107), t(0x116), t(0x141), t(0x142), t(0x144), t(0x145),
                t(0x147), t(0x154), t(0x16a, t16a), t(0x177), t(0x187),
                t(0x188), t(0x191), t(0x511), t(0x516),
                t(0x521, self.apk["device_type"]),
                Writer().writeU16(0x318).writeTlv(t318).read(),
            ]
            if self.apk["ssover"] >= 5:
                tlvs.append(t(0x542))
                tlvs.append(await self.getT544("810_9"))
                tlvs.append(t(0x548))
                if self.sig.t553:
                    tlvs.append(t(0x553))
            if self.device.qImei16:
                tlvs.append(t(0x545, self.device.qImei16))
            else:
                tlvs.append(t(0x194))
                tlvs.append(t(0x202))
            writer = Writer().writeU16(9).writeU16(len(tlvs))
            for v in tlvs:
                writer.writeBytes(v)
            asyncio.create_task(self._send_login("wtlogin.login", writer.read()))
        else:
            if retcode == QrcodeResult.Timeout:
                message = "二维码超时，请重新获取"
            elif retcode == QrcodeResult.WaitingForScan:
                message = "二维码尚未扫描"
            elif retcode == QrcodeResult.WaitingForConfirm:
                message = "二维码尚未确认"
            elif retcode == QrcodeResult.Canceled:
                message = "二维码被取消，请重新获取"
            else:
                message = "扫码遇到未知错误，请重新获取"
            self.sig.qrsig = BUF0
            self.emit("internal.error.qrcode", retcode, message)

    async def queryQrcodeResult(self) -> Dict[str, Any]:
        """获取扫码结果(可定时查询，retcode为0则调用qrcodeLogin登录)"""
        retcode = -1
        uin = None
        t106 = None
        t16a = None
        t318 = None
        tgtgt = None
        if not len(self.sig.qrsig):
            return {"retcode": retcode, "uin": uin, "t106": t106, "t16a": t16a,
                    "t318": t318, "tgtgt": tgtgt}
        body = (
            Writer()
            .writeU16(5)
            .writeU8(1)
            .writeU32(8)
            .writeU32(16)
            .writeTlv(self.sig.qrsig)
            .writeU64(0)
            .writeU8(8)
            .writeTlv(BUF0)
            .writeU16(0)
            .read()
        )
        pkt = await build_code2d_packet(self, 0x12, 0x6200, body)
        try:
            payload = await self._send(pkt)
            payload = tea.decrypt(payload[16:-1], self.__ecdh.share_key)
            r = Reader(payload)
            r.read(48)
            ln = r.readUInt16BE()
            if ln > 0:
                ln -= 1
                if r.read(1)[0] == 2:
                    r.read(8)
                    ln -= 8
                if ln > 0:
                    r.read(ln)
            r.read(4)
            retcode = r.read(1)[0]
            if retcode == 0:
                r.read(4)
                uin = r.readUInt32BE()
                r.read(6)
                t = read_tlv(r)
                t106 = t[0x18]
                t16a = t[0x19]
                t318 = t[0x65]
                tgtgt = t[0x1E]
        except Exception:
            pass
        return {"retcode": retcode, "uin": uin, "t106": t106, "t16a": t16a,
                "t318": t318, "tgtgt": tgtgt}

    # ---- 收发包 ----

    def __next_seq(self) -> int:
        self.sig.seq += 1
        if self.sig.seq >= 0x8000:
            self.sig.seq = 1
        return self.sig.seq

    async def _send(self, pkt: bytes, timeout: float = 5, seq: int = 0) -> bytes:
        """发送一个包并等待对应 seq 的回包（JS [FN_SEND]）。"""
        self.statistics["sent_pkt_cnt"] += 1
        seq = seq or self.sig.seq
        loop = asyncio.get_running_loop()
        fut: asyncio.Future = loop.create_future()

        def on_timeout():
            if not fut.done():
                self.__handlers.pop(seq, None)
                self.statistics["lost_pkt_cnt"] += 1
                fut.set_exception(ApiRejection(-2, f"packet timeout (seq: {seq})"))

        timer = loop.call_later(timeout, on_timeout)

        async def send():
            try:
                await self.__net.join()
            except Exception as e:
                timer.cancel()
                if not fut.done():
                    fut.set_exception(e)
                return

            def handler(payload: bytes):
                timer.cancel()
                self.__handlers.pop(seq, None)
                if not fut.done():
                    fut.set_result(payload)

            if not fut.done():
                self.__handlers[seq] = handler
                self.__net.write(pkt)

        asyncio.create_task(send())
        return await fut

    async def _send_login(self, cmd: str, body: bytes) -> None:
        """发送登录包（JS [FN_SEND_LOGIN]）。"""
        if self.__is_online or self.__login_lock:
            return
        pkt = await build_login_packet(self, cmd, body)
        try:
            self.__login_lock = True
            ret = decode_login_response(self, await self._send(pkt))
            if ret is not None:
                asyncio.create_task(ret)
        except Exception as e:
            self.__login_lock = False
            self.emit("internal.error.network", -2, "server is busy")
            self.emit("internal.verbose", str(e), VerboseLevel.Error)
            self.emit("internal.verbose", traceback.format_exc(), VerboseLevel.Debug)

    async def writeUni(self, cmd: str, body: bytes, seq: int = 0) -> None:
        """发送一个业务包不等待返回"""
        self.statistics["sent_pkt_cnt"] += 1
        pkt = await build_uni_pkt(self, cmd, body, seq)
        if len(pkt) > 0:
            self.__net.write(pkt)

    def sendOidb(self, cmd: str, body: bytes, timeout: float = 5):
        """dont use it if not clear the usage"""
        sp = cmd.replace("OidbSvc.", "").replace("oidb_", "").split("_")
        type1 = int(sp[0], 16)
        try:
            type2 = int(sp[1])
        except (IndexError, ValueError):
            type2 = 1
        body = pb.encode({
            1: type1,
            2: type2,
            3: 0,
            4: body,
            6: "android " + self.apk["ver"],
        })
        return self.sendUni(cmd, body, timeout)

    async def sendPacket(self, type: str, cmd: str, body: bytes) -> bytes:
        if type == "Uni":
            return await self.sendUni(cmd, body)
        else:
            return await self.sendOidb(cmd, body)

    async def sendUni(self, cmd: str, body: bytes, timeout: float = 5) -> bytes:
        """发送一个业务包并等待返回"""
        if not self.__is_online:
            raise ApiRejection(-1, f"client not online (cmd: {cmd})")
        seq = self.__next_seq()
        pkt = await build_uni_pkt(self, cmd, body, seq)
        if len(pkt) < 1:
            return pb.encode({1: -1, 2: "签名api异常", 3: {}})
        return await self._send(pkt, timeout, seq)

    async def sendOidbSvcTrpcTcp(self, cmd: str, body: bytes) -> bytes:
        sp = cmd.replace("OidbSvcTrpcTcp.", "").split("_")
        type1 = int(sp[0], 16)
        type2 = int(sp[1])
        body = pb.encode({
            1: type1,
            2: type2,
            4: body,
            6: "android " + self.apk["ver"],
        })
        payload = await self.sendUni(cmd, body)
        rsp = pb.decode(payload)
        if rsp.get(3) == 0:
            return rsp[4]
        raise ApiRejection(rsp.get(3), rsp.get(5))

    async def register(self, logout: bool = False, reflush: bool = False) -> int:
        """上线（注册推送服务）"""
        async def re_register():
            err = await _register(self, logout, reflush)
            if err == 1:
                self.sig.register_retry_count = 0
                return err
            elif err == -1:
                if self.register_retry_num > self.sig.register_retry_count:
                    self.sig.register_retry_count += 1
                    self.emit("internal.verbose", f"上线失败，第{self.sig.register_retry_count}次重试",
                              VerboseLevel.Warn)
                    await asyncio.sleep(2)
                    return await re_register()
                else:
                    self.sig.register_retry_count = 0
                    self.sig.token_retry_count = self.token_retry_num
                    return err
            else:
                self.sig.register_retry_count = 0
                return err

        return await re_register()

    def syncTimeDiff(self) -> None:
        async def task():
            try:
                pkt = await build_login_packet(self, "Client.CorrectTime", BUF4, 0)
                buf = await self._send(pkt)
                try:
                    self.sig.time_diff = i32(buf) - timestamp()
                except Exception:
                    pass
            except Exception:
                pass

        asyncio.create_task(task())

    async def token_expire(self, data: Optional[dict] = None) -> None:
        data = data or {}
        self.emit("internal.error.token", data.get("retcode"), data.get("retmsg"))

    async def sendHeartbeat(self) -> None:
        if callable(self.heartbeat):
            try:
                await self.heartbeat()
            except Exception:
                pass
        self.syncTimeDiff()
        try:
            await self._send(await build_login_packet(self, "Heartbeat.Alive", BUF0, 0), 10)
        except Exception:
            self.emit("internal.verbose", "Heartbeat.Alive timeout", VerboseLevel.Warn)
            try:
                await self._send(await build_login_packet(self, "Heartbeat.Alive", BUF0, 0), 10)
            except Exception as e:
                self.emit("internal.verbose", "Heartbeat.Alive timeout x 2", VerboseLevel.Warn)
                raise e

    # ---- 心跳任务管理 ----

    def _start_heartbeat(self) -> None:
        self._stop_heartbeat()
        if self.interval > 0:
            self.__heartbeat_task = asyncio.create_task(self.__heartbeat_loop())

    def _stop_heartbeat(self) -> None:
        if self.__heartbeat_task is not None:
            self.__heartbeat_task.cancel()
            self.__heartbeat_task = None

    async def __heartbeat_loop(self) -> None:
        try:
            while True:
                await asyncio.sleep(self.interval)
                try:
                    await self.sendHeartbeat()
                    await heartbeat_success(self)
                except Exception:
                    self.__net.close()
        except asyncio.CancelledError:
            pass


# ================================================================
# 模块级函数（JS 中通过 .call(this) / .bind(this) 使用）
# ================================================================

def sso_listener(self: BaseClient, cmd: str, payload: bytes, seq: int) -> None:
    if cmd in ("StatSvc.ReqMSFOffline", "MessageSvc.PushForceOffline"):
        asyncio.create_task(self.logout())
        nested = decodeWrapper(payload)
        if nested.get(4):
            msg = f"[{nested[4]}]{nested.get(3, 'undefined')}"
        else:
            msg = f"[{nested[1]}]{nested.get(2, 'undefined')}"
        self.emit(EVENT_KICKOFF, msg)
        return
    if cmd == "QualityTest.PushList":
        asyncio.create_task(self.writeUni(cmd, BUF0, seq))
        return
    if cmd == "OnlinePush.SidTicketExpired":
        asyncio.create_task(self.writeUni(cmd, BUF0, seq))
        return
    if cmd == "ConfigPushSvc.PushReq":
        if payload[0] == 0:
            payload = payload[4:]
        nested = decodeWrapper(payload)
        if nested.get(1) == 2 and nested.get(2):
            buf = jce_decode(nested[2])[5][5]
            decoded = pb.decode(buf)[1281]
            try:
                self.sig.bigdata["sig_session"] = decoded[1].toBuffer()
                self.sig.bigdata["session_key"] = decoded[2].toBuffer()
                for v in decoded[3]:
                    if v[1] == 10:
                        self.sig.bigdata["port"] = v[2][0][3]
                        self.sig.bigdata["ip"] = int32ip2str(v[2][0][2])
                save_bigdata(self, buf)
            except Exception:
                self.sig.bigdata = {"ip": "", "port": 0, "sig_session": BUF0, "session_key": BUF0}
        asyncio.create_task(config_push_resp(self, [nested.get(1), nested.get(3)]))


def save_bigdata(self: BaseClient, data: bytes) -> None:
    try:
        with open(os.path.join(self.config["data_dir"], str(self.uin) + "_bigdata"), "wb") as f:
            f.write(data)
    except Exception:
        pass


def read_bigdata(self: BaseClient) -> None:
    try:
        file = os.path.join(self.config["data_dir"], str(self.uin) + "_bigdata")
        if not os.path.exists(file):
            return
        with open(file, "rb") as f:
            data = f.read()
        decoded = pb.decode(data)[1281]
        self.sig.bigdata["sig_session"] = decoded[1].toBuffer()
        self.sig.bigdata["session_key"] = decoded[2].toBuffer()
        for v in decoded[3]:
            if v[1] == 10:
                self.sig.bigdata["port"] = v[2][0][3]
                self.sig.bigdata["ip"] = int32ip2str(v[2][0][2])
    except Exception:
        pass


async def config_push_resp(self: BaseClient, data: list) -> None:
    MainServant = encodeStruct(data)
    body = encodeWrapper({"MainServant": MainServant}, "QQService.ConfigPushSvc.MainServant", "PushResp")
    await self.writeUni("ConfigPushSvc.PushResp", body)


def online_listener(self: BaseClient, *args) -> None:
    if self.listenerCount(EVENT_KICKOFF) == 0:
        def kickoff(c, msg):
            c._BaseClient__is_online = False
            c._stop_heartbeat()
            c.emit("internal.kickoff", msg)

        self.trapOnce(EVENT_KICKOFF, kickoff)


def lost_listener(self: BaseClient) -> None:
    self._stop_heartbeat()
    if self._BaseClient__is_online:
        self._BaseClient__is_online = False
        self.statistics["lost_times"] += 1

        async def delayed():
            await asyncio.sleep(0.05)
            await self.register()

        asyncio.create_task(delayed())


async def parse_sso(self: BaseClient, buf: bytes) -> Dict[str, Any]:
    r = Reader(buf)
    headlen = r.readUInt32BE()
    seq = r.readInt32BE()
    retcode = r.readInt32BE()
    retmsg = r.read(r.readUInt32BE() - 4).decode("utf-8", errors="replace")
    cmd = r.read(r.readUInt32BE() - 4).decode("utf-8", errors="replace")
    session = r.read(r.readUInt32BE() - 4)
    flag = r.readInt32BE()
    r.read(r.readUInt32BE() - 4)
    payload = r.read(r.readUInt32BE() - 4) or BUF0
    if retcode != 0:
        expire_codes = (210, -10000, -10001, -10003, -10004, -10005, -10006, -10008, -10106, -12003)
        if retcode in expire_codes:
            await self.token_expire({"seq": seq, "retcode": retcode, "retmsg": retmsg,
                                     "cmd": cmd, "session": session, "flag": flag})
    else:
        if flag == 0:
            pass
        elif flag == 1:
            payload = await unzip(payload)
        elif flag == 8:
            pass
        else:
            raise Exception("unknown compressed flag: " + str(flag))
    return {"retcode": retcode, "seq": seq, "cmd": cmd, "payload": payload}


async def packet_listener(self: BaseClient, pkt: bytes) -> None:
    self.statistics["recv_pkt_cnt"] += 1
    self._BaseClient__login_lock = False
    try:
        flag = pkt[4]
        encrypted = pkt[u32(pkt, 6) + 6:]
        if flag == 0:
            decrypted = encrypted
        elif flag == 1:
            try:
                decrypted = tea.decrypt(bytes(encrypted), self.sig.d2key)
            except Exception:
                decrypted = tea.decrypt(bytes(encrypted), self.sig.old_d2key)
        elif flag == 2:
            decrypted = tea.decrypt(encrypted, BUF16)
        else:
            await self.token_expire({"flag": flag})
            raise Exception("unknown flag:" + str(flag))
        sso = await parse_sso(self, decrypted)
        self.emit(
            "internal.verbose",
            f"recv:{sso['cmd']} seq:{sso['seq']}"
            + ("" if sso["retcode"] == 0 else f" retcode:{sso['retcode']}"),
            VerboseLevel.Debug if sso["retcode"] == 0 else VerboseLevel.Error,
        )
        if sso["seq"] in self._BaseClient__handlers:
            handler = self._BaseClient__handlers.get(sso["seq"])
            if handler:
                handler(sso["payload"])
        else:
            self.emit("internal.sso", sso["cmd"], sso["payload"], sso["seq"])
    except Exception as e:
        self.emit("internal.verbose", str(e), VerboseLevel.Error)
        self.emit("internal.verbose", traceback.format_exc(), VerboseLevel.Debug)


async def _register(self: BaseClient, logout: bool = False, reflush: bool = False) -> int:
    self._BaseClient__is_online = False
    self._stop_heartbeat()
    err = 1
    pb_buf = pb.encode({
        1: [
            {1: 46, 2: timestamp()},
            {1: 283, 2: 0},
        ]
    })
    d = self.device
    SvcReqRegister = encodeStruct([
        self.uin,
        (0 if logout else 7), 0, "", (21 if logout else 11), 0,
        0, 0, 0, 0, (44 if logout else 0),
        d.version["sdk"], 1, "", 0, None,
        d.guid, 2052, 0, d.model, d.model,
        d.version["release"], 1, 0, 0, None,
        0, 0, "", 0, d.brand,
        d.brand, "", pb_buf, 0, None,
        0, None, 1000, 98,
    ])
    body = encodeWrapper({"SvcReqRegister": SvcReqRegister}, "PushService", "SvcReqRegister")
    pkt = await build_login_packet(self, "StatSvc.register", body, 1)
    try:
        payload = await self._send(pkt, 6)
        if logout:
            return 0
        rsp = decodeWrapper(payload)
        result = bool(rsp[9])
        if not result and not reflush:
            err = -1
        else:
            self._BaseClient__is_online = True
            self._start_heartbeat()

            async def hb0():
                try:
                    await self.sendHeartbeat()
                    await heartbeat_success(self)
                except Exception:
                    self._BaseClient__net.close()

            asyncio.create_task(hb0())
    except Exception:
        err = -2
    return err


async def heartbeat_success(self: BaseClient) -> None:
    hb480_cmd = "OidbSvc.0x480_9" if self.config.get("platform") == Platform.Tim else "OidbSvc.0x480_9_IMCore"
    try:
        await self.sendUni(hb480_cmd, self.sig.hb480)
    except Exception:
        self.emit("internal.verbose", hb480_cmd + " timeout", VerboseLevel.Warn)
    await self.refreshToken()
    asyncio.create_task(self.requestToken())


async def refresh_token(self: BaseClient, force: bool = False) -> bool:
    if (not self.isOnline() or self.emp_interval == 0
            or timestamp() - self.sig.emp_time < self.emp_interval) and not force:
        return False
    pkt = await build_login_packet(self, "wtlogin.exchange_emp", await self.tokenLogin())
    try:
        payload = await self._send(pkt)
        payload = tea.decrypt(payload[16:len(payload) - 1], self._BaseClient__ecdh.share_key)
        r = Reader(payload)
        r.read(2)
        type_ = r.readUInt8()
        r.read(2)
        t = read_tlv(r)
        self.emit("internal.verbose", "refresh token type: " + str(type_), VerboseLevel.Debug)
        if type_ == 0:
            token = decode_t119(self, t[0x119])["token"]
            await self.register(False, True)
            if self._BaseClient__is_online:
                self.emit("internal.token", token)
                return True
    except Exception as e:
        self.emit("internal.verbose", "refresh token error: " + str(e), VerboseLevel.Error)
    return False


def read_tlv(r: Reader) -> Dict[int, bytes]:
    t = {}
    while r.remaining() > 2:
        k = r.readUInt16BE()
        t[k] = r.read(r.readUInt16BE())
    return t


async def build_login_packet(self: BaseClient, cmd: str, body: bytes, type: int = 2) -> bytes:
    seq = self._BaseClient__next_seq()
    self.emit("internal.verbose", f"send:{cmd} seq:{seq}", VerboseLevel.Debug)
    uin = self.uin
    cmdid = 0x810
    subappid = self.apk["subid"]
    if cmd == "wtlogin.trans_emp":
        uin = 0
        cmdid = 0x812
    if type == 2:
        body = (
            Writer()
            .writeU8(0x02)
            .writeU8(0x01)
            .writeBytes(self.sig.randkey)
            .writeU16(0x131)
            .writeU16(0x01)
            .writeTlv(self._BaseClient__ecdh.public_key)
            .writeBytes(tea.encrypt(body, self._BaseClient__ecdh.share_key))
            .read()
        )
        body = (
            Writer()
            .writeU8(0x02)
            .writeU16(29 + len(body))  # 1 + 27 + body.length + 1
            .writeU16(8001)  # protocol ver
            .writeU16(cmdid)  # command id
            .writeU16(1)  # const
            .writeU32(uin)
            .writeU8(3)  # const
            .writeU8(0x87)  # encrypt type 7:0 69:emp 0x87:4
            .writeU8(0)  # const
            .writeU32(2)  # const
            .writeU32(0)  # app client ver
            .writeU32(0)  # const
            .writeBytes(body)
            .writeU8(0x03)
            .read()
        )
    sec_info = BUF0
    if cmd in self.signCmd:
        sec_info = await self.getSign(cmd, seq, bytes(body))
    if self.sig.ksid is None:
        self.sig.ksid = f"|{self.device.imei}|{self.apk['name']}".encode("utf-8")
    ksid = self.sig.ksid
    sso = (
        Writer()
        .writeWithLength(
            Writer()
            .write32(seq)
            .writeU32(subappid)
            .writeU32(subappid)
            .writeBytes(bytes([0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00]))
            .writeWithLength(self.sig.tgt)
            .writeWithLength(cmd.encode("utf-8") if isinstance(cmd, str) else cmd)
            .writeWithLength(self.sig.session)
            .writeWithLength(self.device.imei.encode("utf-8"))
            .writeU32(4)
            .writeU16(len(ksid) + 2)
            .writeBytes(ksid)
            .writeWithLength(self.buildReserveFields(cmd, sec_info))
            .read()
        )
        .writeWithLength(body)
        .read()
    )
    if type == 1:
        sso = tea.encrypt(sso, self.sig.d2key)
    elif type == 2:
        sso = tea.encrypt(sso, BUF16)
    return (
        Writer()
        .writeWithLength(
            Writer()
            .writeU32(0x0A)
            .writeU8(type)
            .writeWithLength(self.sig.d2)
            .writeU8(0)
            .writeWithLength(str(uin).encode("utf-8"))
            .writeBytes(sso)
            .read()
        )
        .read()
    )


async def build_code2d_packet(self: BaseClient, cmdid: int, head: int, body: bytes) -> bytes:
    body = (
        Writer()
        .writeU32(head)
        .writeU32(0x1000)
        .writeU16(0)
        .writeU32(0x72000000)
        .writeU32(timestamp())
        .writeU8(2)
        .writeU16(44 + len(body))
        .writeU16(cmdid)
        .writeBytes(bytes(21))
        .writeU8(3)
        .writeU16(0)
        .writeU16(50)
        .writeU32(self.sig.seq + 1)
        .writeU64(0)
        .writeBytes(body)
        .writeU8(3)
        .read()
    )
    return await build_login_packet(self, "wtlogin.trans_emp", body)


async def build_uni_pkt(self: BaseClient, cmd: str, body: bytes, seq: int = 0) -> bytes:
    seq = seq or self._BaseClient__next_seq()
    self.emit("internal.verbose", f"send:{cmd} seq:{seq}", VerboseLevel.Debug)
    sec_info = BUF0
    if cmd in self.signCmd:
        sec_info = await self.getSign(cmd, seq, bytes(body))
        if sec_info == BUF0 and self.sig.sign_api_addr and self.apk.get("qua"):
            return BUF0
    sso = (
        Writer()
        .writeWithLength(
            Writer()
            .writeWithLength(cmd.encode("utf-8") if isinstance(cmd, str) else cmd)
            .writeWithLength(self.sig.session)
            .writeWithLength(self.buildReserveFields(cmd, sec_info))
            .read()
        )
        .writeWithLength(body)
        .read()
    )
    encrypted = tea.encrypt(sso, self.sig.d2key)
    return (
        Writer()
        .writeWithLength(
            Writer()
            .writeU32(0x0B)
            .writeU8(1)  # type
            .write32(seq)
            .writeU8(0)
            .writeWithLength(str(self.uin).encode("utf-8"))
            .writeBytes(encrypted)
            .read()
        )
        .read()
    )


def decode_t119(self: BaseClient, t119: bytes) -> Dict[str, Any]:
    t119key = bytes(self.sig.tgtgt)
    r = Reader(tea.decrypt(bytes(t119), t119key))
    r.read(2)
    t = read_tlv(r)
    self.sig.tgt = t.get(0x10A) or self.sig.tgt
    self.sig.tgt_key = t.get(0x10D) or self.sig.tgt_key
    self.sig.st_key = t.get(0x10E) or self.sig.st_key
    self.sig.st_web = t.get(0x103) or self.sig.st_web
    self.sig.a1 = t.get(0x106) or self.sig.a1
    self.sig.srm_token = t.get(0x16A) or self.sig.srm_token
    self.sig.skey = t.get(0x120) or self.sig.skey
    self.sig.d2 = t.get(0x143) or self.sig.d2
    self.sig.old_d2key = self.sig.d2key or BUF16
    self.sig.d2key = t.get(0x305) or self.sig.d2key
    self.sig.tgtgt = t.get(0x10C) or md5(self.sig.d2key)
    self.sig.ksid = t.get(0x108) or f"|{self.device.imei}|{self.apk['name']}".encode("utf-8")
    self.sig.sig_key = t.get(0x133) or self.sig.sig_key
    self.sig.ticket_key = t.get(0x134) or self.sig.ticket_key
    self.sig.device_token = t.get(0x322) or self.sig.device_token
    self.sig.t543 = t.get(0x543) or self.sig.t543 or BUF0
    self.sig.emp_time = timestamp()
    self.uid = self.sig.t543[6:].decode("utf-8", errors="replace") if len(self.sig.t543) > 6 else ""
    if 0x512 in t:
        r2 = Reader(t[0x512])
        ln = r2.readUInt16BE()
        while ln > 0:
            ln -= 1
            domain = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
            self.pskey[domain] = r2.read(r2.readUInt16BE())
            self.pt4token[domain] = r2.read(r2.readUInt16BE())
    info = {
        "emp_time": self.sig.emp_time,
        "icqq_ver": self.pkg["version"],
        "token_ver": 3,
        "apk": {
            "name": self.apk["name"],
            "id": self.apk["id"],
            "ver": self.apk["ver"],
            "version": self.apk["version"],
            "subid": self.apk["subid"],
            "sdkver": self.apk["sdkver"],
        },
    }
    token = (
        Writer()
        .writeTlv(json.dumps(info).encode("utf-8"))
        .writeTlv(t119)
        .writeTlv(t119key)
        .writeTlv(self.sig.a1 or BUF0)
        .writeTlv(self.sig.d2)
        .writeTlv(self.sig.d2key)
        .writeTlv(self.sig.tgt)
        .writeTlv(self.sig.tgt_key)
        .writeTlv(self.sig.ticket_key)
        .writeTlv(self.sig.sig_key)
        .writeTlv(self.sig.srm_token or BUF0)
        .writeTlv(self.sig.device_token or BUF0)
        .writeTlv(self.sig.t543 or BUF0)
        .writeTlv(self.sig.randkey)
        .writeTlv(self.sig.session)
        .read()
    )
    age = t[0x11A][2:3][0]
    gender = t[0x11A][3:4][0]
    nickname = t[0x11A][5:].decode("utf-8", errors="replace")
    return {"token": token, "nickname": nickname, "gender": gender, "age": age}


def decode_login_response(self: BaseClient, payload: bytes):
    """返回 Optional[coroutine]：JS 中某些分支 return 了一个 Promise（如 204 分支
    的 FN_SEND_LOGIN、15/16 分支的 token_expire），由 _send_login create_task。"""
    payload = tea.decrypt(payload[16:len(payload) - 1], self._BaseClient__ecdh.share_key)
    r = Reader(payload)
    r.read(2)
    type_ = r.readUInt8()
    r.read(2)
    t = read_tlv(r)
    if 0x402 in t:
        self.sig.dPwd = os.urandom(16)
        self.sig.t402 = t[0x402]
        self.sig.g = md5((bytes(self.device.guid) + self.sig.dPwd) + self.sig.t402)
    if 0x546 in t:
        self.sig.t546 = t[0x546]
    if type_ == 204:
        self.sig.t104 = t.get(0x104, BUF0)
        self.emit("internal.verbose", "unlocking...", VerboseLevel.Mark)
        tt = tlv.getPacker(self)
        body = (
            Writer()
            .writeU16(20)
            .writeU16(4)
            .writeBytes(tt(0x8))
            .writeBytes(tt(0x104))
            .writeBytes(tt(0x116))
            .writeBytes(tt(0x401))
            .read()
        )
        return self._send_login("wtlogin.login", body)
    if type_ == 0:
        self.sig.t104 = BUF0
        self.sig.t174 = BUF0
        if 0x403 in t:
            self.sig.randomSeed = t[0x403]
        dec = decode_t119(self, t[0x119])
        token = dec["token"]
        nickname = dec["nickname"]
        gender = dec["gender"]
        age = dec["age"]
        read_bigdata(self)

        async def after_register():
            err = await self.register()
            if self._BaseClient__is_online:
                self.sig.register_retry_count = 0
                await self.updateCmdWhiteList()
                await self.ssoPacketListHandler(None)
                self.emit("internal.online", token, nickname, gender, age)
            elif err == -1:
                await self.token_expire()

        asyncio.create_task(after_register())
        return None
    if type_ == 15 or type_ == 16:
        return self.token_expire()
    if type_ == 2:
        self.sig.t104 = t.get(0x104, BUF0)
        if 0x192 in t:
            self.emit("internal.slider", t[0x192].decode("utf-8", errors="replace"))
            return None
        self.emit("internal.error.login", type_, "[登陆失败]未知格式的验证码")
        return None
    if type_ == 40:
        if 0x146 in t:
            r2 = Reader(t[0x146])
            r2.read(4)
            title = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
            content = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
            self.emit("internal.verbose", f"[{title}]{content}(错误码：{type_})", VerboseLevel.Warn)
        self.emit("internal.error.login", type_, "账号被冻结")
        return None
    if type_ == 45 and 0x146 in t:
        r2 = Reader(t[0x146])
        r2.read(4)
        title = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        content = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        self.emit("internal.verbose", f"[{title}]{content}(错误码：{type_})", VerboseLevel.Warn)
        if "你当前使用的QQ版本过低" in content:
            self.emit("internal.error.login", type_, "QQ协议版本过低，请更新！")
        return None
    if type_ == 160 or type_ == 162 or type_ == 239:
        if not (0x204 in t) and not (0x174 in t):
            self.emit("internal.verbose", "已向密保手机发送短信验证码", VerboseLevel.Mark)
            return None
        phone = ""
        if 0x174 in t and 0x178 in t:
            self.sig.t104 = t.get(0x104, BUF0)
            self.sig.t174 = t[0x174]
            raw = bytes(t[0x178])
            idx = raw.find(b"\x0b") + 1
            phone = raw[idx:idx + 11].decode("utf-8", errors="replace")
        verify = t.get(0x204)
        if isinstance(verify, bytes):
            verify = verify.decode("utf-8", errors="replace")
        self.emit("internal.verify", verify or "", phone)
        return None
    if type_ == 235:
        dir_ = os.path.abspath(self.config["data_dir"])
        device_path = os.path.join(dir_, "device.json")
        self.emit("internal.error.login", type_,
                  f'[登陆失败]({type_})当前设备信息被拉黑，建议删除"{device_path}"后重新登录！')
        return None
    if type_ == 237:
        self.emit("internal.error.login", type_,
                  f"[登陆失败]({type_})当前QQ登录频繁，暂时被限制登录，建议更换QQ或稍后再尝试登录！")
        return None
    if 0x149 in t:
        r2 = Reader(t[0x149])
        r2.read(2)
        title = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        content = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        self.emit("internal.error.login", type_, f"[{title}]{content}")
        return None
    if 0x146 in t:
        r2 = Reader(t[0x146])
        r2.read(4)
        title = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        content = r2.read(r2.readUInt16BE()).decode("utf-8", errors="replace")
        message = f"[{title}]{content}"
        self.emit("internal.verbose", message + f"(错误码：{type_})", VerboseLevel.Warn)
        self.emit("internal.error.login", type_, message)
        return None
    self.emit("internal.error.login", type_, "[登陆失败]未知错误")
    return None
