"""事件类型表（events.js 是空文件，仅声明 EventMap 类型）。

这里保留文档性说明：icqq 的事件名（字符串）与 JS 完全一致，
供 Python 框架在 client.on(...) / client.once(...) 时参考。

主要事件名（完整列表见 events.d.ts）：
- "message" / "message.group" / "message.private" / "message.discuss" / "message.guild"
- "notice" / "notice.group.increase" / "notice.group.decrease" / "notice.group.recall" /
  "notice.group.poke" / "notice.group.admin" / "notice.group.ban" / "notice.group.transfer" ...
- "request" / "request.friend" / "request.group.add" / "request.group.invite"
- "system.login.qrcode" / "system.login.slider" / "system.login.device" / "system.login.error"
- "system.online" / "system.offline" / "internal.verbose" 等
"""
from __future__ import annotations

# JS: export {} —— 空模块，无运行时代码
