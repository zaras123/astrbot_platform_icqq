"""好友与用户实体（friend.js 的移植）。"""
from __future__ import annotations

import os
import weakref

from .core import jce, pb
from .core.buffer import pack_u32, u32
from .core.pb import decodePb
from .errors import ErrorCode, drop
from .common import PB_CONTENT, code2uin, fileHash, hide, lock, md5, sha, timestamp
from .message import PrivateMessage, genDmMessageId, parseDmMessageId, rand2uuid
from .internal import CmdID, Contactable, buildSyncCookie, highwayHttpUpload

# JS: const weakmap = new WeakMap();  （info 对象 → Friend 实例，值为弱引用）
_weakmap: "dict[int, weakref.ReferenceType[Friend]]" = {}


def _weakmap_get(key):
    if not key:
        return None
    ref = _weakmap.get(id(key))
    return ref() if ref is not None else None


def _weakmap_set(key, value) -> None:
    if not key:
        return
    _weakmap[id(key)] = weakref.ref(value)


class _BytesStream:
    """把 bytes 包装为异步可迭代流（Node Readable.from(buf) 的等价物）。"""

    def __init__(self, data: bytes):
        self._data = data

    async def __aiter__(self):
        yield self._data


class _FileStream:
    """把本地文件包装为异步分块可迭代流（fs.createReadStream 的等价物）。"""

    def __init__(self, path: str, high_water_mark: int = 524288):
        self._path = path
        self._chunk = high_water_mark

    async def __aiter__(self):
        with open(self._path, "rb") as f:
            while True:
                chunk = f.read(self._chunk)
                if not chunk:
                    break
                yield chunk


def _str(v) -> str:
    """JS String(...) 的等价物：bytes → utf8 解码（非法字节替换），Proto → toString()，其余 str()。"""
    if isinstance(v, (bytes, bytearray)):
        return v.decode("utf-8", errors="replace")
    return str(v)


class User(Contactable):
    """用户

    JS 的静态工厂 `User.as(this, uid)` 在 Python 中命名为 `User.as_`（`as` 是保留字）。
    """

    @property
    def user_id(self) -> int:
        """`self.uid`的别名"""
        return self.uid

    @staticmethod
    def as_(c, uid: int) -> "User":
        # JS: static as(this: Client, uid): User
        return User(c, int(uid))

    def __init__(self, c, uid: int):
        super().__init__(c)
        self.uid = uid
        lock(self, "uid")

    def asFriend(self, strict: bool = False) -> "Friend":
        """返回作为好友的实例"""
        return self.c.pickFriend(self.uid, strict)

    def asMember(self, gid: int, strict: bool = False):
        """返回作为某群群员的实例"""
        return self.c.pickMember(gid, self.uid, strict)

    def getAvatarUrl(self, size: int = 0) -> str:
        """
        获取头像url
        :param size: 头像大小，默认`0`
        :return: 头像的url地址
        """
        return f"https://q1.qlogo.cn/g?b=qq&s={size}&nk={self.uid}"

    async def getAddFriendSetting(self) -> int:
        FS = jce.encodeStruct([self.c.uin, self.uid, 3004, 0, None, 1])
        body = jce.encodeWrapper(
            {"FS": FS}, "mqq.IMService.FriendListServiceServantObj", "GetUserAddFriendSettingReq"
        )
        payload = await self.c.sendUni("friendlist.getUserAddFriendSetting", body)
        return jce.decodeWrapper(payload)[2]

    async def thumbUp(self, times: int = 1) -> bool:
        """
        点赞，支持陌生人点赞
        :param times: 点赞次数，默认1次
        """
        if times > 20:
            times = 20
        if self.c.fl.get(self.uid):
            ReqFavorite = jce.encodeStruct(
                [
                    jce.encodeNested(
                        [
                            self.c.uin,
                            1,
                            self.c.sig.seq + 1,
                            1,
                            0,
                            bytes.fromhex("0C180001060131160131"),
                        ]
                    ),
                    self.uid,
                    0,
                    1,
                    int(times),
                ]
            )
        else:
            ReqFavorite = jce.encodeStruct(
                [
                    jce.encodeNested(
                        [
                            self.c.uin,
                            1,
                            self.c.sig.seq + 1,
                            1,
                            0,
                            bytes.fromhex("0C180001060131160135"),
                        ]
                    ),
                    self.uid,
                    0,
                    5,
                    int(times),
                ]
            )
        body = jce.encodeWrapper(
            {"ReqFavorite": ReqFavorite}, "VisitorSvc", "ReqFavorite", self.c.sig.seq + 1
        )
        payload = await self.c.sendUni("VisitorSvc.ReqFavorite", body)
        return jce.decodeWrapper(payload)[0][3] == 0

    async def getSimpleInfo(self) -> dict:
        """查看资料"""
        arr = [None, 0, "", [self.uid], 1, 1, 0, 0, 0, 1, 0, 1]
        # JS 数组可稀疏赋值 arr[101] = 1，Python 需先扩容
        arr.extend([None] * (101 - len(arr)))
        arr[101] = 1
        req = jce.encodeStruct(arr)
        body = jce.encodeWrapper(
            {"req": req}, "KQQ.ProfileService.ProfileServantObj", "GetSimpleInfo"
        )
        payload = await self.c.sendUni("ProfileService.GetSimpleInfo", body)
        nested = jce.decodeWrapper(payload)
        for v in nested:
            return {
                # 账号
                "user_id": v[1],
                # 昵称
                "nickname": v[5] or "",
                # 性别
                "sex": "unknown" if v[3] == -1 else "female" if v[3] else "male",
                # 年龄
                "age": v[4] or 0,
                # 地区
                "area": (str(v[13]) + " " + str(v[14]) + " " + str(v[15])).strip(),
            }
        drop(ErrorCode.UserNotExists)

    async def getChatHistory(self, time=None, cnt: int = 20) -> list:
        """
        获取`time`往前的`cnt`条聊天记录
        :param time: 默认当前时间，为时间戳的分钟数（`Date.now() / 1000`）
        :param cnt: 聊天记录条数，默认`20`，超过`20`按`20`处理
        :return: 私聊消息列表，服务器记录不足`cnt`条则返回能获取到的最多消息记录
        """
        if time is None:
            time = timestamp()
        if cnt > 20:
            cnt = 20
        body = pb.encode({1: self.uid, 2: int(time), 3: 0, 4: int(cnt)})
        payload = await self.c.sendUni("MessageSvc.PbGetOneDayRoamMsg", body)
        obj = pb.decode(payload)
        messages = []
        if (obj.get(1) or 0) > 0 or not obj.get(6):
            return messages
        if not isinstance(obj[6], list):
            obj[6] = [obj[6]]
        for proto in obj[6]:
            try:
                messages.append(PrivateMessage(proto, self.c.uin))
            except Exception:
                pass
        return messages

    async def markRead(self, time=None) -> None:
        """
        标记`time`之前为已读
        :param time: 默认当前时间，为时间戳的分钟数（`Date.now() / 1000`）
        """
        if time is None:
            time = timestamp()
        body = pb.encode({3: {2: {1: self.uid, 2: int(time)}}})
        await self.c.sendUni("PbMessageSvc.PbMsgReadedReport", body)

    async def recallMsg(self, param, rand: int = 0, time: int = 0) -> bool:
        """撤回消息，cqhttp方法用"""
        if isinstance(param, PrivateMessage):
            seq, rand, time = param.seq, param.rand, param.time
        elif isinstance(param, str):
            parsed = parseDmMessageId(param)
            seq, rand, time = parsed["seq"], parsed["rand"], parsed["time"]
        else:
            seq = param
        body = pb.encode(
            {
                1: [
                    {
                        1: [
                            {
                                1: self.c.uin,
                                2: self.uid,
                                3: int(seq),
                                4: rand2uuid(int(rand)),
                                5: int(time),
                                6: int(rand),
                            },
                        ],
                        2: 0,
                        3: {1: 0 if self.uid in self.c.fl or self.uid in self.c.sl else 1},
                        4: 1,
                    },
                ],
            }
        )
        payload = await self.c.sendUni("PbMessageSvc.PbMsgWithDraw", body)
        return pb.decode(payload)[1][1] <= 2

    def _getRouting(self, file: bool = False) -> dict:
        if hasattr(self, "gid"):
            return {3: {1: code2uin(getattr(self, "gid")), 2: self.uid}}
        return {15: {1: self.uid, 2: 4}} if file else {1: {1: self.uid}}

    async def sendMsg(self, content, source=None) -> dict:
        """
        发送一条消息
        :param content: 消息内容
        :param source: 引用回复的消息
        """
        converter = await self._preprocess(content, source)
        return await self._sendMsg({1: converter.rich}, converter.brief)

    async def _sendMsg(self, proto3, brief: str, file: bool = False) -> dict:
        seq = self.c.sig.seq + 1
        rand = int.from_bytes(os.urandom(4), "big")
        body = pb.encode(
            {
                1: self._getRouting(file),
                2: PB_CONTENT,
                3: proto3,
                4: seq,
                5: rand,
                6: buildSyncCookie(u32(self.c.sig.session, 0)),
            }
        )
        payload = await self.c.sendUni("MessageSvc.PbSendMsg", body)
        rsp = pb.decode(payload)
        if rsp.get(1) != 0 or rsp.get(14) == 0:
            self.c.logger.error(f"failed to send: [Private: {self.uid}] {rsp.get(2)}({rsp.get(1)})")
            drop(rsp.get(1) or -70, rsp.get(2) or "私聊消息发送失败，可能被风控")
        self.c.logger.info(f"succeed to send: [Private({self.uid})] " + brief)
        self.c.stat.sent_msg_cnt += 1
        time = rsp[3]
        message_id = genDmMessageId(self.uid, seq, rand, time, 1)
        messageRet = {"message_id": message_id, "seq": seq, "rand": rand, "time": time}
        self.c.emit("send", messageRet)
        return messageRet

    async def addFriendBack(self, seq: int, remark: str = "") -> bool:
        """
        回添双向好友
        :param seq: 申请消息序号
        :param remark: 好友备注
        """
        body = pb.encode(
            {
                1: 1,
                2: int(seq),
                3: self.uid,
                4: 10,
                5: 2004,
                6: 1,
                7: 0,
                8: {1: 2, 52: str(remark)},
            }
        )
        payload = await self.c.sendUni("ProfileService.Pb.ReqSystemMsgAction.Friend", body)
        return pb.decode(payload)[1][1] == 0

    async def setFriendReq(self, seq: int, yes: bool = True, remark: str = "", block: bool = False) -> bool:
        """
        处理好友申请
        :param seq: 申请消息序号
        :param yes: 是否同意
        :param remark: 好友备注
        :param block: 是否屏蔽来自此用户的申请
        """
        body = pb.encode(
            {
                1: 1,
                2: int(seq),
                3: self.uid,
                4: 1,
                5: 6,
                6: 7,
                8: {1: 2 if yes else 3, 52: str(remark), 53: 1 if block else 0},
            }
        )
        payload = await self.c.sendUni("ProfileService.Pb.ReqSystemMsgAction.Friend", body)
        return pb.decode(payload)[1][1] == 0

    async def setGroupReq(
        self, gid: int, seq: int, yes: bool = True, reason: str = "", block: bool = False
    ) -> bool:
        """
        处理入群申请
        :param gid: 群号
        :param seq: 申请消息序号
        :param yes: 是否同意
        :param reason: 若拒绝，拒绝的原因
        :param block: 是否屏蔽来自此用户的申请
        """
        body = pb.encode(
            {
                1: 1,
                2: int(seq),
                3: self.uid,
                4: 1,
                5: 3,
                6: 31,
                7: 1,
                8: {1: 11 if yes else 12, 2: int(gid), 50: str(reason), 53: 1 if block else 0},
            }
        )
        payload = await self.c.sendUni("ProfileService.Pb.ReqSystemMsgAction.Group", body)
        return pb.decode(payload)[1][1] == 0

    async def setGroupInvite(self, gid: int, seq: int, yes: bool = True, block: bool = False) -> bool:
        """
        处理群邀请
        :param gid: 群号
        :param seq: 申请消息序号
        :param yes: 是否同意
        :param block: 是否屏蔽来自此群的邀请
        """
        body = pb.encode(
            {
                1: 1,
                2: int(seq),
                3: self.uid,
                4: 1,
                5: 3,
                6: 10016,
                7: 2,
                8: {1: 11 if yes else 12, 2: int(gid), 53: 1 if block else 0},
            }
        )
        payload = await self.c.sendUni("ProfileService.Pb.ReqSystemMsgAction.Group", body)
        return pb.decode(payload)[1][1] == 0

    async def getFileInfo(self, fid: str) -> dict:
        """
        获取文件信息
        :param fid: 文件id
        """
        body = pb.encode(
            {
                1: 1200,
                14: {10: self.c.uin, 20: fid, 30: 2},
                101: 3,
                102: 104,
                99999: {1: 90200},
            }
        )
        payload = await self.c.sendUni(
            "OfflineFilleHandleSvr.pb_ftn_CMD_REQ_APPLY_DOWNLOAD-1200", body
        )
        rsp = pb.decode(payload)[14]
        if rsp.get(10) != 0:
            drop(ErrorCode.OfflineFileNotExists, rsp.get(20))
        obj = rsp[30]
        url = str(obj[50])
        if not url.startswith("http"):
            url = f"http://{obj[30]}:{obj[40]}" + url
        return {
            "name": str(rsp[40][7]),
            "fid": str(rsp[40][6]),
            "md5": rsp[40][100].toHex(),
            "size": rsp[40][3],
            "duration": rsp[40][4],
            "url": url,
        }

    async def getFileUrl(self, fid: str) -> str:
        """
        获取离线文件下载地址
        :param fid: 文件id
        """
        return (await self.getFileInfo(fid))["url"]


class Friend(User):
    """好友

    JS 的静态工厂 `Friend.as(this, uid, strict)` 在 Python 中命名为 `Friend.as_`（`as` 是保留字）。
    """

    @staticmethod
    def as_(c, uid: int, strict: bool = False) -> "Friend":
        # JS: static as(this: Client, uid, strict): Friend
        info = c.fl.get(uid)
        if strict and not info:
            raise Exception(str(uid) + "不是你的好友")
        friend = _weakmap_get(info)
        if friend:
            return friend
        friend = Friend(c, int(uid), info)
        if info:
            _weakmap_set(info, friend)
        return friend

    @property
    def info(self) -> dict:
        """好友资料"""
        return self._info

    @property
    def nickname(self):
        """昵称"""
        return self.info["nickname"] if self.info else None

    @property
    def sex(self):
        """性别"""
        return self.info["sex"] if self.info else None

    @property
    def remark(self):
        """备注"""
        return self.info["remark"] if self.info else None

    @property
    def class_id(self):
        """分组id"""
        return self.info["class_id"] if self.info else None

    @property
    def class_name(self):
        """分组名"""
        return self.c.classes.get(self.info["class_id"] if self.info else None)

    def __init__(self, c, uid: int, _info=None):
        super().__init__(c, uid)
        self._info = _info
        hide(self, "_info")

    async def setRemark(self, remark: str) -> None:
        """设置备注"""
        req = jce.encodeStruct([self.uid, str(remark or "")])
        body = jce.encodeWrapper(
            {"req": req}, "KQQ.ProfileService.ProfileServantObj", "ChangeFriendName"
        )
        await self.c.sendUni("ProfileService.ChangeFriendName", body)

    async def setClass(self, id: int) -> None:
        """设置分组(注意：如果分组id不存在也会成功)"""
        buf = bytearray(10)
        buf[0] = 1
        buf[2] = 5
        buf[3:7] = pack_u32(self.uid)
        buf[7] = int(id)
        MovGroupMemReq = jce.encodeStruct([self.c.uin, 0, bytes(buf)])
        body = jce.encodeWrapper(
            {"MovGroupMemReq": MovGroupMemReq},
            "mqq.IMService.FriendListServiceServantObj",
            "MovGroupMemReq",
        )
        await self.c.sendUni("friendlist.MovGroupMemReq", body)

    async def poke(self, self_: bool = False) -> bool:
        """
        戳一戳
        :param self_: 是否戳自己
        """
        body = pb.encode({1: self.c.uin if self_ else self.uid, 5: self.uid})
        payload = await self.c.sendOidb("OidbSvc.0xed3", body)
        return pb.decode(payload)[3] == 0

    async def delete(self, block: bool = True) -> bool:
        """
        删除好友
        :param block: 屏蔽此好友的申请，默认为`true`
        """
        DF = jce.encodeStruct([self.c.uin, self.uid, 2, 1 if block else 0])
        body = jce.encodeWrapper(
            {"DF": DF}, "mqq.IMService.FriendListServiceServantObj", "DelFriendReq"
        )
        payload = await self.c.sendUni("friendlist.delFriend", body)
        self.c.sl.delete(self.uid)
        return jce.decodeWrapper(payload)[2] == 0

    async def sendFile(self, file, filename=None, callback=None) -> str:
        """
        发送离线文件
        :param file: `str`表示从该本地文件路径获取，`bytes`表示直接发送这段内容
        :param filename: 对方看到的文件名，`file`为`bytes`时，若留空则自动以md5命名
        :param callback: 监控上传进度的回调函数，拥有一个"百分比进度"的参数
        :return: 文件id(撤回时使用)
        """
        if isinstance(file, (bytes, bytearray)):
            file = bytes(file)
            filesize = len(file)
            filemd5 = md5(file)
            filesha = sha(file)
            filename = str(filename) if filename else "file" + filemd5.hex()
            filestream = _BytesStream(file)
        else:
            file = str(file)
            filesize = os.path.getsize(file)
            filemd5, filesha = await fileHash(file)
            filename = str(filename) if filename else os.path.basename(file)
            filestream = _FileStream(file)
        body1700 = pb.encode(
            {
                1: 1700,
                2: 6,
                19: {
                    10: self.c.uin,
                    20: self.uid,
                    30: filesize,
                    40: filename,
                    50: filemd5,
                    60: filesha,
                    70: "/storage/emulated/0/Android/data/com.tencent.mobileqq/Tencent/QQfile_recv/"
                    + filename,
                    80: 0,
                    90: 0,
                    100: 0,
                    110: filemd5,
                },
                101: 3,
                102: 104,
                200: 1,
            }
        )
        payload = await self.c.sendUni(
            "OfflineFilleHandleSvr.pb_ftn_CMD_REQ_APPLY_UPLOAD_V3-1700", body1700
        )
        rsp1700 = pb.decode(payload)[19]
        if rsp1700[10] != 0:
            drop(rsp1700[10], rsp1700[20])
        fid = rsp1700[90].toBuffer()
        if not rsp1700[110]:
            ext = pb.encode(
                {
                    1: 100,
                    2: 2,
                    100: {
                        100: {
                            1: 3,
                            100: self.c.uin,
                            200: self.uid,
                            400: 0,
                            700: payload,
                        },
                        200: {
                            100: filesize,
                            200: filemd5,
                            300: filesha,
                            400: filemd5,
                            600: fid,
                            700: rsp1700[220].toBuffer(),
                        },
                        300: {
                            100: 2,
                            200: str(self.c.apk.subid),
                            300: 2,
                            400: "d92615c5",
                            600: 4,
                        },
                        400: {
                            100: filename,
                        },
                    },
                    200: 1,
                }
            )
            await highwayHttpUpload(
                self.c,
                filestream,
                {
                    "md5": filemd5,
                    "size": filesize,
                    "cmdid": CmdID.OfflineFile,
                    "ext": ext,
                    "callback": callback,
                },
            )
        body800 = pb.encode(
            {
                1: 800,
                2: 7,
                10: {10: self.c.uin, 20: self.uid, 30: fid},
                101: 3,
                102: 104,
            }
        )
        await self.c.sendUni("OfflineFilleHandleSvr.pb_ftn_CMD_REQ_UPLOAD_SUCC-800", body800)
        proto3 = {
            2: {
                1: {
                    1: 0,
                    3: fid,
                    4: filemd5,
                    5: filename,
                    6: filesize,
                    9: 1,
                },
            },
        }
        await self._sendMsg(proto3, f"[文件：{filename}]", True)
        return _str(fid)

    async def recallFile(self, fid: str) -> bool:
        """
        撤回离线文件
        :param fid: 文件id
        """
        body = pb.encode(
            {
                1: 400,
                2: 0,
                6: {1: self.c.uin, 2: fid},
                101: 3,
                102: 104,
                200: 1,
            }
        )
        payload = await self.c.sendUni("OfflineFilleHandleSvr.pb_ftn_CMD_REQ_RECALL-400", body)
        rsp = pb.decode(payload)[6]
        return rsp.get(1) == 0

    async def forwardFile(self, fid: str, group_id: int = 0) -> str:
        """
        转发离线文件
        :param fid: 文件fid
        :param group_id: 群号，转发群文件时填写
        :return: 转发成功后新文件的id
        """
        if group_id > 0:
            body = pb.encode(
                {
                    3: {
                        1: group_id,
                        2: 3,
                        3: 102,
                        4: f"/{fid}",
                        5: 3,
                        6: self.uid,
                    },
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d9_2", body)
            rsp = payload[3]
            if rsp[1] != 0:
                drop(rsp[1], rsp[2])
            new_fid = rsp[4]
            info = await self.getFileInfo(new_fid)
            proto3 = {
                2: {
                    1: {
                        1: 0,
                        3: new_fid,
                        4: bytes.fromhex(info["md5"]),
                        5: info["name"],
                        6: info["size"],
                        9: 1,
                    },
                },
            }
            await self._sendMsg(proto3, f"[文件：{info['name']}]", True)
        else:
            body = pb.encode(
                {
                    1: 700,
                    2: 0,
                    9: {10: self.c.uin, 20: self.uid, 30: fid},
                    101: 3,
                    102: 104,
                    200: 1,
                }
            )
            payload = await self.c.sendUni(
                "OfflineFilleHandleSvr.pb_ftn_CMD_REQ_APPLY_FORWARD_FILE-700", body
            )
            rsp = pb.decode(payload)[9]
            new_fid = rsp[50]
            ticket = rsp[60]
            if rsp[10] != 0:
                drop(rsp[10], rsp[20])
            info = await self.getFileInfo(fid)
            proto3 = {
                2: {
                    1: {
                        1: 0,
                        3: new_fid,
                        4: bytes.fromhex(info["md5"]),
                        5: info["name"],
                        6: info["size"],
                        9: 1,
                        57: ticket,
                    },
                },
            }
            await self._sendMsg(proto3, f"[文件：{info['name']}]", True)
        return _str(new_fid)

    async def searchSameGroup(self) -> list:
        """查找机器人与这个人的共群"""
        body = pb.encode(
            {
                "1": 3316,
                "2": 0,
                "3": 0,
                "4": {
                    "1": self.c.uin,
                    "2": self.uid,
                    "4": 1,
                    "5": [
                        {
                            "3": {"1": self.c.uin, "2": self.uid},
                            "5": 3436,
                        },
                        {
                            "3": {
                                "1": {
                                    "1": {"6": f"{self.uid}"},
                                    "2": 1,
                                },
                            },
                            "5": 3460,
                        },
                    ],
                    "6": 0,
                },
                "6": "android 8.9.28",
            }
        )
        payload = await self.c.sendUni("OidbSvc.0xcf4", body)
        # JS 的 decodePb 是 async（zlib inflate），Python 版为同步
        res = decodePb(payload)
        if not res[4][12][1]:
            return []
        return [{"groupName": item[3], "Group_Id": item[1]} for item in res[4][12][1]]
