"""群员实体（member.js 的移植）。"""
from __future__ import annotations

import asyncio
import weakref

from .core import jce, pb
from .core.buffer import pack_u16, pack_u32
from .errors import ErrorCode, drop
from .common import hide, lock, parseFunString, timestamp
from .friend import User

# JS: const weakmap = new WeakMap();  （info 对象 → Member 实例，值为弱引用）
_weakmap: "dict[int, weakref.ReferenceType[Member]]" = {}


def _weakmap_get(key):
    if not key:
        return None
    ref = _weakmap.get(id(key))
    return ref() if ref is not None else None


def _weakmap_set(key, value) -> None:
    if not key:
        return
    _weakmap[id(key)] = weakref.ref(value)


def _fire(coro) -> None:
    """JS: promise.catch(NOOP) 的等价物：后台执行协程并吞掉异常。"""
    task = asyncio.create_task(coro)

    def _done(t) -> None:
        if not t.cancelled():
            t.exception()

    task.add_done_callback(_done)


class Member(User):
    """@ts-ignore ts(2417) 群员

    JS 的静态工厂 `Member.as(this, gid, uid, strict)` 在 Python 中命名为 `Member.as_`（`as` 是保留字）。
    """

    @staticmethod
    def as_(c, gid: int, uid: int, strict: bool = False) -> "Member":
        # JS: static as(this: Client, gid, uid, strict): Member
        gml_map = c.gml.get(gid)
        info = gml_map.get(uid) if gml_map else None
        if strict and not info:
            raise Exception(f"群{gid}中找不到群员" + str(uid))
        member = _weakmap_get(info)
        if member:
            return member
        member = Member(c, int(gid), int(uid), info)
        if info:
            _weakmap_set(info, member)
        return member

    @property
    def info(self) -> dict:
        """群员资料"""
        if not self.c.config.get("cache_group_member"):
            return self._info
        if not self._info or timestamp() - (self._info.get("update_time") or 0) >= 900:
            _fire(self.renew())
        return self._info

    @property
    def group_id(self) -> int:
        """{@link gid} 的别名"""
        return self.gid

    @property
    def card(self):
        """名片"""
        return (self.info or {}).get("card") or (self.info or {}).get("nickname")

    @property
    def title(self):
        """头衔"""
        return self.info["title"] if self.info else None

    @property
    def is_friend(self) -> bool:
        """是否是我的好友"""
        return self.uid in self.c.fl

    @property
    def is_owner(self) -> bool:
        """是否是群主"""
        return bool(self.info) and self.info["role"] == "owner"

    @property
    def is_admin(self) -> bool:
        """是否是管理员"""
        return (bool(self.info) and self.info["role"] == "admin") or self.is_owner

    @property
    def mute_left(self) -> int:
        """禁言剩余时间"""
        t = (self.info["shutup_time"] if self.info else 0) - timestamp()
        return t if t > 0 else 0

    @property
    def group(self):
        """返回所在群的实例"""
        return self.c.pickGroup(self.gid)

    def __init__(self, c, gid: int, uid: int, _info=None):
        super().__init__(c, uid)
        self.gid = gid
        self._info = _info
        lock(self, "gid")
        hide(self, "_info")

    async def renew(self) -> dict:
        """强制刷新群员资料"""
        if not self.gid in self.c.gml and self.c.config.get("cache_group_member"):
            _fire(self.group.getMemberMap())
        if self._info:
            self._info["update_time"] = timestamp()
        body = pb.encode({1: self.gid, 2: self.uid, 3: 1, 4: 1, 5: 1})
        payload = await self.c.sendUni("group_member_card.get_group_member_card_info", body)
        proto = pb.decode(payload)[3]
        if not proto.get(27):
            gml_map = self.c.gml.get(self.gid)
            if gml_map:
                gml_map.delete(self.uid)
            drop(ErrorCode.MemberNotExists)
        card = parseFunString(proto[8].toBuffer()) if proto[8] else ""
        gml_map = self.c.gml.get(self.gid)
        shutup_time = (gml_map.get(self.uid) or {}).get("shutup_time") if gml_map else 0
        info = {
            "group_id": self.gid,
            "user_id": self.uid,
            "nickname": proto[11].toString() if proto[11] else "",
            "card": card,
            "sex": "male" if proto[9] == 0 else "female" if proto[9] == 1 else "unknown",
            "age": proto[12] or 0,
            "area": proto[10].toString() if proto[10] else "",
            "join_time": proto[14],
            "last_sent_time": proto[15],
            "level": proto[39],
            "rank": str(proto[13]) if 13 in proto else "",
            "role": "owner" if proto[27] == 3 else "admin" if proto[27] == 2 else "member",
            "title": str(proto[31]) if 31 in proto else "",
            "title_expire_time": proto[32] if 32 in proto else 0xFFFFFFFF,
            "shutup_time": shutup_time or 0,
            "update_time": timestamp(),
        }
        gml_map = self.c.gml.get(self.gid)
        info = dict((gml_map.get(self.uid) if gml_map else None) or self._info or {}, **info)
        gml_map = self.c.gml.get(self.gid)
        if gml_map:
            gml_map.set(self.uid, info)
        self._info = info
        _weakmap_set(info, self)
        return info

    async def setAdmin(self, yes: bool = True) -> bool:
        """
        设置/取消管理员
        :param yes: 是否设为管理员
        """
        buf = bytearray(9)
        buf[0:4] = pack_u32(self.gid)
        buf[4:8] = pack_u32(self.uid)
        buf[8] = 1 if yes else 0
        payload = await self.c.sendOidb("OidbSvc.0x55c_1", bytes(buf))
        ret = pb.decode(payload).get(3) == 0
        if ret and self.info and not self.is_owner:
            self.info["role"] = "admin" if yes else "member"
        return ret

    async def setTitle(self, title: str = "", duration: int = -1) -> bool:
        """
        设置头衔
        :param title: 头衔名
        :param duration: 持续时间，默认`-1`，表示永久
        """
        body = pb.encode(
            {
                1: self.gid,
                3: {1: self.uid, 7: str(title), 5: str(title), 6: int(duration) or -1},
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0x8fc_2", body)
        return pb.decode(payload).get(3) == 0

    async def setCard(self, card: str = "") -> bool:
        """
        修改名片
        :param card: 名片
        """
        MGCREQ = jce.encodeStruct(
            [
                0,
                self.gid,
                0,
                [jce.encodeNested([self.uid, 31, str(card), 0, "", "", ""])],
            ]
        )
        body = jce.encodeWrapper(
            {"MGCREQ": MGCREQ}, "mqq.IMService.FriendListServiceServantObj", "ModifyGroupCardReq"
        )
        payload = await self.c.sendUni("friendlist.ModifyGroupCardReq", body)
        ret = len(jce.decodeWrapper(payload)[3]) > 0
        if ret and self.info:
            self.info["card"] = str(card)
        return ret

    async def kick(self, msg=None, block: bool = False) -> bool:
        """
        踢出群
        :param msg: @todo 未知参数
        :param block: 是否屏蔽群员
        """
        body = pb.encode(
            {
                "1": self.gid,
                "2": {"1": 5, "2": self.uid, "3": 1 if block else 0},
                "5": msg,
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0x8a0_0", body)
        ret = pb.decode(payload)[4][2][1] == 0
        if ret:
            gml_map = self.c.gml.get(self.gid)
            if gml_map:
                gml_map.delete(self.uid)
        return ret

    async def mute(self, duration: int = 1800) -> None:
        """
        禁言
        :param duration: 禁言时长（秒），默认`1800`
        """
        if duration > 2592000 or duration < 0:
            duration = 2592000
        buf = bytearray(15)
        buf[0:4] = pack_u32(self.gid)
        buf[4] = 32
        buf[5:7] = pack_u16(1)
        buf[7:11] = pack_u32(self.uid)
        buf[11:15] = pack_u32(int(duration) or 0)
        await self.c.sendOidb("OidbSvc.0x570_8", bytes(buf))

    async def poke(self) -> bool:
        """戳一戳"""
        body = pb.encode({1: self.uid, 2: self.gid})
        payload = await self.c.sendOidb("OidbSvc.0xed3", body)
        return pb.decode(payload).get(3) == 0

    async def setScreenMsg(self, isScreen: bool = True) -> bool:
        """
        是否屏蔽该群成员消息
        :param isScreen:
        """
        body = pb.encode(
            {
                1: {
                    1: {
                        1: self.gid,
                        **({5: {1: self.uid}} if isScreen else {6: self.uid}),
                    },
                },
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0x8bb_7" if isScreen else "OidbSvc.0x8bb_9", body)
        return pb.decode(payload).get(3) == 0

    async def addFriend(self, comment: str = "") -> bool:
        """
        加为好友
        :param comment: 申请消息
        """
        type_ = await self.getAddFriendSetting()
        if type_ not in [0, 1, 4]:
            return False
        comment = str(comment)
        AF = jce.encodeStruct(
            [
                self.c.uin,
                self.uid,
                1 if type_ else 0,
                1,
                0,
                len(comment.encode("utf-8")),
                comment,
                0,
                1,
                None,
                3004,
                11,
                None,
                None,
                pb.encode({1: self.gid}) if self.gid else None,
                0,
                None,
                None,
                0,
            ]
        )
        body = jce.encodeWrapper(
            {"AF": AF}, "mqq.IMService.FriendListServiceServantObj", "AddFriendReq"
        )
        payload = await self.c.sendUni("friendlist.addFriend", body)
        return jce.decodeWrapper(payload)[6] == 0
