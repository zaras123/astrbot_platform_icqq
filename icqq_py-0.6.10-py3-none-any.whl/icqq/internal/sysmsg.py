"""系统消息（好友请求/群请求）处理（sysmsg.js 的移植）。"""
from __future__ import annotations

import asyncio

from ..core.buffer import pack_u32
from ..core.pb import decode, encode


def genFriendRequestFlag(user_id, seq, single=False):
    """@cqhttp"""
    flag = format(user_id, "08x") + format(seq, "x")
    if single:
        flag = "~" + flag
    return flag


def parseFriendRequestFlag(flag):
    """@cqhttp"""
    single = False
    if flag.startswith("~"):
        flag = flag[1:]
        single = True
    user_id = int(flag[:8], 16)
    seq = int("0x" + flag[8:], 16)
    return {"user_id": user_id, "seq": seq, "single": single}


def genGroupRequestFlag(user_id, group_id, seq, invite):
    """@cqhttp"""
    return pack_u32(user_id).hex() + pack_u32(group_id).hex() + str(invite) + format(seq, "x")


def parseGroupRequestFlag(flag):
    """@cqhttp"""
    user_id = int(flag[:8], 16)
    group_id = int(flag[8:16], 16)
    invite = int(flag[16:17])
    seq = int("0x" + flag[17:], 16)
    return {"user_id": user_id, "group_id": group_id, "seq": seq, "invite": invite}


def parseFrdSysMsg(proto):
    p50 = proto.get(50) or {}
    if (p50.get(1) == 9 or p50.get(1) == 10) and str(p50.get(6)) == "":
        single = True
    elif p50.get(1) == 1:
        single = False
    else:
        raise Exception("unsupported friend request type: " + str(p50.get(1)))
    time = proto.get(4)
    user_id = proto.get(5)
    nickname = str(p50.get(51))
    seq = proto.get(3)
    flag = genFriendRequestFlag(user_id, proto.get(3), p50.get(1) == 9 or p50.get(1) == 1)
    source = str(p50.get(5))
    comment = str(p50.get(4) if p50.get(4) else "")
    sex = "male" if p50.get(67) == 0 else "female" if p50.get(67) == 1 else "unknown"
    age = p50.get(68)
    return {
        "post_type": "request",
        "request_type": "friend",
        "sub_type": "single" if single else "add",
        "user_id": user_id, "nickname": nickname, "source": source, "comment": comment,
        "seq": seq, "sex": sex, "age": age, "flag": flag, "time": time,
    }


def parseGrpSysMsg(proto):
    p50 = proto.get(50) or {}
    if p50.get(1) != 1:
        raise Exception("unsupported group request type: " + str(p50.get(1)))
    type_ = p50.get(12)
    time = proto.get(4)
    group_id = p50.get(10)
    group_name = str(p50.get(52))
    seq = proto.get(3)
    if type_ == 2:  # invite
        return {
            "post_type": "request",
            "request_type": "group",
            "sub_type": "invite",
            "time": time,
            "group_id": group_id,
            "group_name": group_name,
            "seq": seq,
            "user_id": p50.get(11),
            "nickname": str(p50.get(53)),
            "role": "member" if p50.get(13) == 1 else "admin",
            "flag": genGroupRequestFlag(p50.get(11), group_id, seq, 1),
        }
    elif type_ == 1 or type_ == 22:  # add
        return {
            "post_type": "request",
            "request_type": "group",
            "sub_type": "add",
            "time": time,
            "group_id": group_id,
            "group_name": group_name,
            "user_id": proto.get(5),
            "seq": seq,
            "nickname": str(p50.get(51)),
            "comment": str(p50.get(4)),
            "inviter_id": p50.get(11),
            "tips": str(p50.get(32)),
            "flag": genGroupRequestFlag(proto.get(5), group_id, seq, 0),
        }
    raise Exception("unsupported group request sub type: " + str(type_))


FRD_BUF = encode({
    1: 20,
    4: 1000,
    5: 2,
    6: {
        4: 1,
        7: 1,
        9: 1,
        10: 1,
        15: 1,
    },
    7: 0,
    8: 0,
    9: 0,
    10: 1,
    11: 2,
})


async def getFrdSysMsg(self):
    payload = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Friend", FRD_BUF)
    rsp = decode(payload)
    rsp = rsp.get(9) if rsp is not None else None
    if rsp is None:
        return
    if not isinstance(rsp, list):
        rsp = [rsp]
    for proto in rsp:
        try:
            e = parseFrdSysMsg(proto)
            if self._msgExists(e["user_id"], 0, proto.get(3), e["time"]):
                continue

            def _approve(yes=True):
                return self.pickUser(e["user_id"]).setFriendReq(e["seq"], yes)

            e["approve"] = _approve
            if e["sub_type"] == "single":
                self.sl[e["user_id"]] = {
                    "user_id": e["user_id"],
                    "nickname": e["nickname"],
                }
                self.logger.info(f"{e['user_id']}({e['nickname']}) 将你添加为单向好友 (seq: {e['seq']}, flag: {e['flag']})")
                self.em("request.friend.single", e)
            else:
                self.logger.info(f"收到 {e['user_id']}({e['nickname']}) 的加好友请求 (seq: {e['seq']}, flag: {e['flag']})")
                self.em("request.friend.add", e)
        except Exception as e2:
            self.logger.trace(getattr(e2, "message", None) or str(e2))


GRP_BUF = encode({
    1: 20,
    4: 1000,
    5: 3,
    6: {
        1: 1,
        2: 1,
        3: 1,
        5: 1,
        6: 1,
        7: 1,
        8: 1,
        9: 1,
        10: 1,
        11: 1,
        12: 1,
        13: 1,
        14: 1,
        15: 1,
        16: 1,
        17: 1,
    },
    7: 0,
    8: 0,
    9: 0,
    10: 1,
    11: 1,
})
GRP_BUF_RISK = encode({
    1: 20,
    4: 1000,
    5: 3,
    6: {
        1: 1,
        2: 1,
        3: 1,
        5: 1,
        6: 1,
        7: 1,
        8: 1,
        9: 1,
        10: 1,
        11: 1,
        12: 1,
        13: 1,
        14: 1,
        15: 1,
        16: 1,
        17: 1,
    },
    7: 0,
    8: 0,
    9: 0,
    10: 1,
    11: 2,
})


async def getGrpSysMsg(self):
    arr = []
    payload = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Group", GRP_BUF)
    rsp = decode(payload)
    rsp = rsp.get(10) if rsp is not None else None
    if rsp:
        arr = arr + (rsp if isinstance(rsp, list) else [rsp])
    payload = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Group", GRP_BUF_RISK)
    rsp = decode(payload)
    rsp = rsp.get(10) if rsp is not None else None
    if rsp:
        arr = arr + (rsp if isinstance(rsp, list) else [rsp])
    for proto in arr:
        try:
            e = parseGrpSysMsg(proto)
            p50 = proto.get(50) or {}
            if self._msgExists(e["group_id"], p50.get(12), proto.get(3), e["time"]):
                continue

            def _approve(yes=True):
                return getattr(
                    self.pickUser(e["user_id"]),
                    "setGroupReq" if e["sub_type"] == "add" else "setGroupInvite",
                )(e["group_id"], e["seq"], yes)

            e["approve"] = _approve
            if e["sub_type"] == "add":
                self.logger.info(
                    f"用户 {e['user_id']}({e['nickname']}) 请求加入群 {e['group_id']}({e['group_name']}) "
                    f"(seq: {e['seq']}, flag: {e['flag']})")
                self.em("request.group.add", e)
            else:
                self.logger.info(
                    f"用户 {e['user_id']}({e['nickname']}) 邀请你加入群 {e['group_id']}({e['group_name']}) "
                    f"(seq: {e['seq']}, flag: {e['flag']})")
                self.em("request.group.invite", e)
        except Exception as e2:
            self.logger.trace(getattr(e2, "message", None) or str(e2))


async def getSysMsg(self):
    ret = []

    async def task1():
        blob = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Friend", FRD_BUF)
        rsp = decode(blob)
        rsp = rsp.get(9) if rsp is not None else None
        if not rsp:
            return
        if not isinstance(rsp, list):
            rsp = [rsp]
        dbl = set()
        for proto in rsp:
            try:
                e = parseFrdSysMsg(proto)

                def _approve(yes=True):
                    return self.pickUser(e["user_id"]).setFriendReq(e["seq"], yes)

                e["approve"] = _approve
                if e["user_id"] in dbl:
                    continue
                dbl.add(e["user_id"])
                ret.append(e)
            except Exception:
                pass

    async def task2():
        arr = []
        payload = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Group", GRP_BUF)
        rsp = decode(payload)
        rsp = rsp.get(10) if rsp is not None else None
        if rsp:
            arr = arr + (rsp if isinstance(rsp, list) else [rsp])
        payload = await self.sendUni("ProfileService.Pb.ReqSystemMsgNew.Group", GRP_BUF_RISK)
        rsp = decode(payload)
        rsp = rsp.get(10) if rsp is not None else None
        if rsp:
            arr = arr + (rsp if isinstance(rsp, list) else [rsp])
        for proto in arr:
            try:
                e = parseGrpSysMsg(proto)

                def _approve(yes=True):
                    return getattr(
                        self.pickUser(e["user_id"]),
                        "setGroupReq" if e["sub_type"] == "add" else "setGroupInvite",
                    )(e["group_id"], e["seq"], yes)

                e["approve"] = _approve
                ret.append(e)
            except Exception:
                pass

    await asyncio.gather(task1(), task2())
    return ret
