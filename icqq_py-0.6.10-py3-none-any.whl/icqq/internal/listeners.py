"""internal 事件监听器绑定（listeners.js 的移植）。

事件监听绑定：`self.on("internal.xxx", fn)` —— 事件系统调用
`fn(self, *args)`（对应 JS listener.apply(this, args)）；async 监听器返回
coroutine 时由事件系统自动 create_task，不需要自己包 task。
"""
from __future__ import annotations

import asyncio
import io
import os

from PIL import Image as PILImage  # pngjs 的替代（Pillow）

from ..common import BUF0, OnlineStatus
from ..core.jce import decodeWrapper
from .guild import guildMsgListener
from .onlinepush import (discussMsgListener, dmMsgSyncListener, groupMsgListener,
                         onlinePushListener, onlinePushTransListener)
from .pbgetmsg import pbGetMsg, pushReadedListener
from .sysmsg import getFrdSysMsg, getGrpSysMsg


async def pushNotifyListener(self, payload):
    if not self._sync_cookie:
        return
    try:
        nested = decodeWrapper(payload[4:])
    except Exception:
        nested = decodeWrapper(payload[15:])
    type_ = nested.get(5)
    if type_ == 33:  # 群员入群
        return await pbGetMsg(self)
    if type_ == 38:  # 建群
        return await pbGetMsg(self)
    if type_ == 85:  # 群申请被同意
        return await pbGetMsg(self)
    if type_ == 141:  # 陌生人
        return await pbGetMsg(self)
    if type_ == 166:  # 好友
        return await pbGetMsg(self)
    if type_ == 167:  # 单向好友
        return await pbGetMsg(self)
    if type_ == 208:  # 好友语音
        return await pbGetMsg(self)
    if type_ == 529:  # 离线文件
        return await pbGetMsg(self)
    if type_ == 84:  # 群请求
        return await getGrpSysMsg(self)
    if type_ == 87:  # 群邀请
        return await getGrpSysMsg(self)
    if type_ == 525:  # 群请求(来自群员的邀请)
        return await getGrpSysMsg(self)
    if type_ == 187:  # 好友请求
        return await getFrdSysMsg(self)
    if type_ == 191:  # 单向好友增加
        return await getFrdSysMsg(self)
    if type_ == 528:  # 黑名单同步
        return await self.reloadBlackList()


# cmd → 监听函数，统一 (self, payload, seq) 签名（JS 里多余的参数会被忽略）
events = {
    "OnlinePush.PbPushGroupMsg": lambda self, payload, seq: groupMsgListener(self, payload),
    "OnlinePush.PbPushDisMsg": lambda self, payload, seq: discussMsgListener(self, payload, seq),
    "OnlinePush.ReqPush": lambda self, payload, seq: onlinePushListener(self, payload, seq),
    "OnlinePush.PbPushTransMsg": lambda self, payload, seq: onlinePushTransListener(self, payload, seq),
    "OnlinePush.PbC2CMsgSync": lambda self, payload, seq: dmMsgSyncListener(self, payload, seq),
    "MessageSvc.PushNotify": lambda self, payload, seq: pushNotifyListener(self, payload),
    "MessageSvc.PushReaded": lambda self, payload, seq: pushReadedListener(self, payload),
    # "trpc.group_pro.synclogic.SyncLogic.PushFirstView": guildListPushListener,
    "MsgPush.PushGroupProMsg": lambda self, payload, seq: guildMsgListener(self, payload),
}


async def eventsListener(self, cmd, payload, seq):
    """事件总线, 在这里捕获奇怪的错误"""
    try:
        fn = events.get(cmd)
        if fn:
            result = fn(self, payload, seq)
            if asyncio.iscoroutine(result) or asyncio.isfuture(result):
                await result
    except Exception as e:
        self.logger.trace(e)


async def onlineListener(self, token, nickname, gender, age):
    """上线后加载资源"""
    self.nickname = nickname
    self.age = age
    self.sex = "male" if gender == 1 else "female" if gender else "unknown"
    # 恢复之前的状态
    self.status = self.status or OnlineStatus.Online
    r = self.setOnlineStatus(self.status)
    if asyncio.iscoroutine(r) or asyncio.isfuture(r):
        asyncio.create_task(r)
    # 存token
    tokenUpdatedListener(self, token)
    self.log_level = self.config.get("log_level")
    self.logger.mark(f"Welcome, {self.nickname} ! 正在加载资源...")
    await asyncio.gather(
        self.reloadFriendList(),
        self.reloadGroupList(),
        self.reloadStrangerList(),
        self.reloadGuilds(),
        self.reloadBlackList(),
        return_exceptions=True,
    )
    self.logger.mark(f"加载了{len(self.fl)}个好友，{len(self.gl)}个群，{len(self.guilds)}个频道，{len(self.sl)}个陌生人")

    async def _pb_get_msg():
        try:
            await pbGetMsg(self)
        except Exception:
            pass

    asyncio.create_task(_pb_get_msg())
    self.em("system.online")


def tokenUpdatedListener(self, token):
    if token == BUF0:
        return
    token_path = os.path.join(self.dir, f"{self.uin}_token")
    if os.path.exists(token_path):
        os.rename(token_path, token_path + "_bak")
    with open(token_path, "wb") as f:
        f.write(token)
    try:
        os.unlink(token_path + "_bak")
    except OSError:
        pass
    self.sig.token_retry_count = 0


def kickoffListener(self, message):
    self.logger.warn(message)
    self.terminate()
    # fs.unlink(path.join(this.dir, this.uin + '_token'), NOOP)
    self.em("system.offline.kickoff", {"message": message})


def logQrcode(img):
    # pngjs 的 PNG.sync.read 默认读出 RGBA；Pillow convert("RGBA") 逐像素一致
    png = PILImage.open(io.BytesIO(img)).convert("RGBA")
    width, height = png.size
    data = png.tobytes()
    color_reset = "\x1b[0m"
    color_fg_blk = "\x1b[30m"
    color_bg_blk = "\x1b[40m"
    color_fg_wht = "\x1b[37m"
    color_bg_wht = "\x1b[47m"
    for i in range(36, height * 4 - 36, 24):
        line = ""
        for j in range(36, width * 4 - 36, 12):
            r0 = data[i * width + j]
            r1 = data[i * width + j + (width * 4 * 3)]
            bgcolor = color_bg_wht if r0 == 255 else color_bg_blk
            fgcolor = color_fg_wht if r1 == 255 else color_fg_blk
            line += f"{fgcolor + bgcolor}▄"
        print(line + color_reset)
    print(f"{color_fg_blk + color_bg_wht}       请使用 手机QQ 扫描二维码        {color_reset}")
    print(f"{color_fg_blk + color_bg_wht}                                       {color_reset}")


def qrcodeListener(self, image):
    file = os.path.join(self.dir, "qrcode.png")
    with open(file, "wb") as f:
        f.write(image)
    try:
        logQrcode(image)
    except Exception:
        pass
    self.logger.mark("二维码图片已保存到：" + file)
    self.em("system.login.qrcode", {"image": image})


def sliderListener(self, url):
    self.logger.mark("收到滑动验证码，请访问以下地址完成滑动，并从网络响应中取出ticket输入：" + url)
    self.em("system.login.slider", {"url": url})


def verifyListener(self, url, phone):
    self.logger.mark("收到登录保护，只需验证一次便长期有效，可以访问URL验证或发短信验证。访问URL完成验证后调用login()可直接登录。发短信验证需要调用sendSmsCode()和submitSmsCode()方法。")
    self.logger.mark("登录保护验证URL：" + url.replace("verify", "qrcode"))
    self.logger.mark("密保手机号：" + phone)
    return self.em("system.login.device", {"url": url, "phone": phone})


async def _loginDelayed(self, seconds, *args):
    await asyncio.sleep(seconds)
    await self.login(*args)


def loginErrorListener(self, code, message):
    """
    登录相关错误
    @param code -2服务器忙 -3上线失败(需要删token)
    """
    if message:
        self.logger.error(message)
    if self.login_timer:
        return
    # token expired
    if not code or code < -100:
        self.logger.mark("登录token过期")
        self.em("system.token.expire")
        self.sig.token_retry_count += 1
        # fs.unlink(path.join(this.dir, this.uin + "_token"), NOOP)
        self.logger.mark("3秒后重新连接")
        self.login_timer = asyncio.create_task(_loginDelayed(self, 3))
    elif code < 0:
        # network error
        self.terminate()
        if code == -3:  # register failed
            # fs.unlink(path.join(this.dir, this.uin + "_token"), NOOP)
            self.sig.token_retry_count = self.token_retry_num - 1
        t = self.config.get("reconn_interval")
        if t >= 1:
            self.logger.mark(f"{t}秒后重新连接")
            self.login_timer = asyncio.create_task(_loginDelayed(self, t, self.uin))
        self.em("system.offline.network", {"message": message})
    elif code > 0:
        # login error
        self.em("system.login.error", {"code": code, "message": message})


def qrcodeErrorListener(self, code, message):
    self.logger.error(f"二维码扫码遇到错误: {code} ({message})")
    self.logger.mark("二维码已更新")
    asyncio.create_task(self.login())


def bindInternalListeners(self):
    self.on("internal.online", onlineListener)
    self.on("internal.kickoff", kickoffListener)
    self.on("internal.token", tokenUpdatedListener)
    self.on("internal.qrcode", qrcodeListener)
    self.on("internal.slider", sliderListener)
    self.on("internal.verify", verifyListener)
    self.on("internal.error.token", loginErrorListener)
    self.on("internal.error.login", loginErrorListener)
    self.on("internal.error.qrcode", qrcodeErrorListener)
    self.on("internal.error.network", loginErrorListener)
    self.on("internal.sso", eventsListener)
