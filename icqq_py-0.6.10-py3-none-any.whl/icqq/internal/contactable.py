"""所有用户和群的基类 Contactable（contactable.js 的移植）。"""
from __future__ import annotations

import asyncio
import base64
import json
import math
import os
import re
from urllib.parse import urlencode

from ..common import IS_WIN, MAX_UPLOAD_SIZE, TMP_DIR, escapeXml, int32ip2str, md5Stream, timestamp, uuid
from ..core.base_client import ApiRejection
from ..core.buffer import u32
from ..core.constants import BUF0, gzip, lock, md5, unzip
from ..core.http import http_get, http_post
from ..core.pb import Proto, decode, encode
from ..core.silk import encode as silk_encode, getDuration as silk_getDuration
from ..core.tea import decrypt as tea_decrypt
from ..errors import ErrorCode, drop
from ..message import Converter, ForwardMessage, Image, PrivateMessage, buildMusic, musicFactory, rand2uuid
from ..message.share import buildShare

from .highway import CmdID, highwayUpload


def _first(v):
    """JS `v?.[0] || v` 的等价物（repeated 字段取第一个元素）。"""
    if isinstance(v, list):
        return v[0] if len(v) else v
    return v


def _proto_to_buffer(v):
    """JS `v.toBuffer?.() || v` 的等价物。"""
    if isinstance(v, Proto):
        return v.toBuffer()
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    return v


def _proto_to_str(v, fallback=""):
    """JS `v?.toString() || fallback` 的等价物。"""
    if isinstance(v, Proto):
        return v.toString()
    if v is None:
        return fallback
    return str(v)


def _spread(base, obj):
    """JS 对象展开 `{...base, ...obj}`：兼容 dict 与普通对象两种元素表示。"""
    result = dict(base)
    if isinstance(obj, dict):
        result.update(obj)
    else:
        for k, v in vars(obj).items():
            if not k.startswith("_"):
                result[k] = v
    return result


def _get(e, key):
    """元素字段访问：兼容 dict 与属性两种表示。"""
    if isinstance(e, dict):
        return e.get(key)
    return getattr(e, key, None)


async def _exec(cmd):
    """child_process.exec 的 asyncio 等价物。"""
    proc = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    stdout, stderr = await proc.communicate()
    return stdout.decode("utf-8", errors="replace"), stderr.decode("utf-8", errors="replace")


class Contactable:
    """所有用户和群的基类"""

    def __init__(self, c):
        self.c = c
        # lock(this, "c")  —— Python 无此机制，no-op 保留
        lock(self, "c")

    # 对方账号，可能是群号也可能是QQ号
    @property
    def target(self):
        return self.uid or self.gid or self.c.uin

    # 是否是 Direct Message (私聊)
    @property
    def dm(self):
        return bool(self.uid)

    # 返回所属的客户端对象
    @property
    def client(self):
        return self.c

    # 取私聊图片fid
    async def _offPicUp(self, imgs):
        req = []
        for img in imgs:
            req.append({
                1: self.c.uin,
                2: self.uid,
                3: 0,
                4: img.md5,
                5: img.size,
                6: img.md5.hex(),
                7: 5,
                8: 9,
                9: 0,
                10: 0,
                11: 0,  # retry
                12: 1,  # bu
                13: 1 if img.origin else 0,
                14: img.width,
                15: img.height,
                16: img.type,
                17: self.c.apk.version,
                22: 0,
            })
        body = encode({
            1: 1,
            2: req,
            # 10: 3
        })
        payload = await self.c.sendUni("LongConn.OffPicUp", body)
        return decode(payload)[2]

    # 取群聊图片fid
    async def _groupPicUp(self, imgs):
        req = []
        for img in imgs:
            req.append({
                1: self.gid,
                2: self.c.uin,
                3: 0,
                4: img.md5,
                5: img.size,
                6: img.md5.hex(),
                7: 5,
                8: 9,
                9: 1,  # bu
                10: img.width,
                11: img.height,
                12: img.type,
                13: self.c.apk.version,
                14: 0,
                15: 1052,
                16: 1 if img.origin else 0,
                18: 0,
                19: 0,
            })
        body = encode({
            1: 3,
            2: 1,
            3: req,
        })
        payload = await self.c.sendUni("ImgStore.GroupPicUp", body)
        return decode(payload)[3]

    # 上传一批图片以备发送(无数量限制)，理论上传一次所有群和好友都能发
    async def uploadImages(self, imgs):
        self.c.logger.debug(f"开始图片任务，共有{len(imgs)}张图片")
        for i in range(len(imgs)):
            if not isinstance(imgs[i], Image):
                imgs[i] = Image(imgs[i], self.dm, os.path.join(self.c.dir, "../image"))
        tasks = []
        for i in range(len(imgs)):
            t = imgs[i].task
            tasks.append(t if t is not None else asyncio.sleep(0))
        res1 = list(await asyncio.gather(*tasks, return_exceptions=True))
        for i, r in enumerate(res1):
            if isinstance(r, BaseException):
                self.c.logger.warn(f"图片{i + 1}失败, reason: " + (getattr(r, "message", None) or str(r)))
        n = 0
        while len(imgs) > n:
            rsp = await (self._offPicUp if self.dm else self._groupPicUp)(imgs[n:n + 20])
            if not isinstance(rsp, list):
                rsp = [rsp]
            tasks2 = []
            for i in range(n, len(imgs)):
                if i >= n + 20:
                    break
                tasks2.append(self._uploadImage(imgs[i], rsp[i % 20]))
            res2 = await asyncio.gather(*tasks2, return_exceptions=True)
            for i, r in enumerate(res2):
                if isinstance(r, BaseException):
                    res1[n + i] = r
                    self.c.logger.warn(f"图片{n + i + 1}上传失败, reason: " + (getattr(r, "message", None) or str(r)))
            n += 20
        self.c.logger.debug("图片任务结束")
        return res1

    async def _uploadImage(self, img, rsp):
        j = 1 if self.dm else 0
        if rsp.get(2 + j) != 0:
            raise Exception(str(rsp.get(3 + j)))
        img.fid = _proto_to_buffer(rsp.get(9 + j))
        if rsp.get(4 + j):
            img.deleteTmpFile()
            return
        if not img.readable:
            img.deleteCacheFile()
            return
        ip = _first(rsp.get(6 + j))
        port = _first(rsp.get(7 + j))
        try:
            return await highwayUpload(self.c, img.readable, {
                "cmdid": CmdID.DmImage if j else CmdID.GroupImage,
                "md5": img.md5,
                "size": img.size,
                "ticket": rsp.get(8 + j).toBuffer(),
            }, ip, port)
        finally:
            # JS: .finally(img.deleteTmpFile.bind(img))
            img.deleteTmpFile()

    # 发送网址分享
    async def shareUrl(self, content, config=None):
        body = buildShare((self.gid or self.uid), 0 if self.dm else 1, content, config)
        await self.c.sendOidb("OidbSvc.0xb77_9", encode(body))

    # 发送音乐分享
    async def shareMusic(self, platform, id):
        body = await buildMusic((self.gid or self.uid), 0 if self.dm else 1, platform, id)
        await self.c.sendOidb("OidbSvc.0xb77_9", encode(body))

    # 发消息预处理
    async def _preprocess(self, content, source=None):
        try:
            if not isinstance(content, list):
                content = [content]
            forwardNode = [e for e in content if not isinstance(e, str) and _get(e, "type") == "node"]
            flat = []
            for item in content:
                if item in forwardNode:
                    continue
                if isinstance(item, str):
                    flat.append({"type": "text", "text": item})
                elif isinstance(item, list):
                    flat.extend(item)
                else:
                    flat.append(item)

            async def _task(elem):
                type_ = _get(elem, "type")
                if type_ == "video":
                    return await self.uploadVideo(elem)
                if type_ == "share":
                    return await self.shareUrl(elem)
                if type_ == "music":
                    info = await musicFactory[_get(elem, "platform")].getMusicInfo(_get(elem, "id"))
                    return _spread(info, elem)
                if type_ == "record":
                    return await self.uploadPtt(elem)
                return elem

            task = [_task(e) for e in flat]
            if len(forwardNode):
                task.append(self.makeForwardMsg(forwardNode))
            content = [c for c in (await asyncio.gather(*task)) if c]
            converter = Converter(content, {
                "dm": self.dm,
                "cachedir": os.path.join(self.c.dir, "image"),
                "mlist": self.c.gml.get(self.gid),
            })
            if source:
                await converter.quote(source)
            if len(converter.imgs):
                await self.uploadImages(converter.imgs)
            return converter
        except Exception as e:
            drop(ErrorCode.MessageBuilderError, getattr(e, "message", None) or str(e))

    async def _downloadFileToTmpDir(self, url, headers=None):
        savePath = os.path.join(TMP_DIR, uuid())
        # JS: axios(stream) → DownloadTransform(超过 MAX_UPLOAD_SIZE 报错) → 写文件
        data = await http_get(url, headers=headers)
        if len(data) > MAX_UPLOAD_SIZE:
            raise Exception("文件大小超限")
        with open(savePath, "wb") as f:
            f.write(data)
        return savePath

    async def _saveFileToTmpDir(self, file):
        buf = file if isinstance(file, (bytes, bytearray)) else base64.b64decode(file[9:])
        savePath = os.path.join(TMP_DIR, uuid())
        with open(savePath, "wb") as f:
            f.write(buf)
        return savePath

    # 上传一个视频以备发送(理论上传一次所有群和好友都能发)
    async def uploadVideo(self, elem):
        file = _get(elem, "file")
        temp = _get(elem, "temp")
        if temp is None:
            temp = False
        if isinstance(file, (bytes, bytearray)) or file.startswith("base64://"):
            file = await self._saveFileToTmpDir(file)
            temp = True
        elif file.startswith("protobuf://"):
            return elem
        elif file.startswith("https://") or file.startswith("http://"):
            file = await self._downloadFileToTmpDir(file)
            temp = True
        file = re.sub(r"^file://", "", file)
        if IS_WIN and file.startswith("/"):
            file = file[1:]
        thumb = os.path.join(TMP_DIR, uuid())
        stdout, stderr = await _exec(
            f'{self.c.config.get("ffmpeg_path") or "ffmpeg"} -y -i "{file}" -f image2 -frames:v 1 "{thumb}"')
        self.c.logger.debug("ffmpeg output: " + stdout + stderr)
        if not os.path.exists(thumb):
            raise ApiRejection(ErrorCode.FFmpegVideoThumbError, "ffmpeg获取视频图像帧失败")
        stdout, stderr = await _exec(f'{self.c.config.get("ffprobe_path") or "ffprobe"} -i "{file}" -show_streams')
        lines = (stdout or stderr or "").split("\n")
        width = 1280
        height = 720
        seconds = 120
        for line in lines:
            if line.startswith("width="):
                width = int(float(line[6:]))
            elif line.startswith("height="):
                height = int(float(line[7:]))
            elif line.startswith("duration="):
                seconds = int(float(line[9:]))
                break
        md5video = await md5Stream(open(file, "rb"))
        md5thumb = await md5Stream(open(thumb, "rb"))
        name = md5video.hex() + ".mp4"
        videosize = os.path.getsize(file)
        thumbsize = os.path.getsize(thumb)
        ext = encode({
            1: self.c.uin,
            2: self.target,
            3: 1,
            4: 2,
            5: {
                1: name,
                2: md5video,
                3: md5thumb,
                4: videosize,
                5: height,
                6: width,
                7: 3,
                8: seconds,
                9: thumbsize,
            },
            6: self.target,
            20: 1,
        })
        body = encode({
            1: 300,
            3: ext,
            100: {
                1: 0,
                2: 1,
            },
        })
        payload = await self.c.sendUni("PttCenterSvr.GroupShortVideoUpReq", body)
        rsp = decode(payload)[3]
        if rsp.get(1):
            raise Exception(str(rsp.get(2)))
        if not rsp.get(7):
            md5_ = await md5Stream(await createReadable(thumb, file))
            await highwayUpload(self.c, await createReadable(thumb, file), {
                "cmdid": CmdID.ShortVideo,
                "md5": md5_,
                "size": thumbsize + videosize,
                "ext": ext,
                "encrypt": True,
            })
        try:
            os.unlink(thumb)
        except OSError:
            pass
        if temp:
            try:
                os.unlink(file)
            except OSError:
                pass
        buf = encode({
            1: rsp[5].toBuffer(),
            2: md5video,
            3: name,
            4: 3,
            5: seconds,
            6: videosize,
            7: width,
            8: height,
            9: md5thumb,
            10: "camera",
            11: thumbsize,
            12: 0,
            15: 1,
            16: width,
            17: height,
            18: 0,
            19: 0,
        })
        return {
            "type": "video", "file": "protobuf://" + base64.b64encode(buf).decode(),
        }

    # 上传一个语音以备发送(理论上传一次所有群和好友都能发)
    async def uploadPtt(self, elem, transcoding=True, brief=""):
        self.c.logger.debug("开始语音任务")
        if isinstance(_get(elem, "file"), str) and _get(elem, "file").startswith("protobuf://"):
            return elem
        buf = await getPttBuffer(_get(elem, "file"), transcoding, self.c.config.get("ffmpeg_path") or "ffmpeg")
        if not _get(elem, "seconds") and b"SILK" in buf[:7]:
            elem.seconds = math.ceil(((await silk_getDuration(buf)) or 0) / 1000)
        hash_ = md5(buf)
        codec = 1 if (b"SILK" in buf[:7] or not transcoding) else 0
        body = {
            1: 3,
            2: 3,
            5: {
                1: self.target,
                2: self.c.uin,
                3: 0,
                4: hash_,
                5: len(buf),
                6: hash_.hex() + (".slk" if codec else ".amr"),
                7: 2,
                8: 9,
                9: 3,
                10: self.c.apk.version,
                12: _get(elem, "seconds") or 1,
                13: 1,
                14: codec,
                15: 2,
            },
        }
        payload = await self.c.sendUni("PttStore.GroupPttUp", encode(body))
        rsp = decode(payload)[5]
        if rsp.get(2):
            drop(rsp.get(2), rsp.get(3))
        ip = _first(rsp.get(5))
        port = _first(rsp.get(6))
        ukey = rsp[7].toHex()
        filekey = rsp[11].toHex()
        if self.c.sig.bigdata.port:
            await highwayUpload(self.c, bytes(buf), {
                "cmdid": CmdID.GroupPtt,
                "md5": hash_,
                "size": len(buf),
                "ext": encode(body),
            })
        else:
            params = {
                "ver": 4679,
                "ukey": ukey,
                "filekey": filekey,
                "filesize": len(buf),
                "bmd5": hash_.hex(),
                "mType": "pttDu",
                "voice_encodec": codec,
            }
            url = f"http://{int32ip2str(ip)}:{port}/?" + urlencode(params)
            headers = {
                "User-Agent": f"QQ/{self.c.apk.version} CFNetwork/1126",
                "Net-Type": "Wifi",
            }
            await http_post(url, bytes(buf), headers=headers)
        self.c.logger.debug("语音任务结束")
        fid = rsp[11].toBuffer()
        b = {
            1: 4,
            2: self.c.uin,
            3: fid,
            4: hash_,
            5: hash_.hex() + ".amr",
            6: len(buf),
            8: 0,
            11: 1,
            18: fid,
            29: codec,
            30: {
                1: 0,
                5: 0,
                6: "",
                7: 0,
                8: brief,
            },
        }
        if _get(elem, "seconds"):
            b[19] = _get(elem, "seconds")
        return {
            "type": "record", "file": "protobuf://" + base64.b64encode(encode(b)).decode(),
        }

    async def _newUploadMultiMsg(self, compressed):
        body = encode({
            2: {
                1: 1 if self.dm else 3,
                2: {
                    2: self.target,
                },
                4: compressed,
            },
            15: {
                1: 4,
                2: 2,
                3: 9,
                4: 0,
            },
        })
        payload = await self.c.sendUni("trpc.group.long_msg_interface.MsgService.SsoSendLongMsg", body)
        rsp = decode(payload)
        rsp = rsp.get(2) if rsp is not None else None
        if not (rsp.get(3) if rsp is not None else None):
            v2 = rsp.get(2) if rsp is not None else None
            drop(rsp.get(1) if rsp is not None else None,
                 _proto_to_str(v2, "unknown trpc.group.long_msg_interface.MsgService.SsoSendLongMsg error"))
        return rsp[3].toString()

    async def _uploadMultiMsg(self, compressed):
        body = encode({
            1: 1,
            2: 5,
            3: 9,
            4: 3,
            5: self.c.apk.version,
            6: [{
                1: self.target,
                2: len(compressed),
                3: md5(compressed),
                4: 3,
                5: 0,
            }],
            8: 1,
        })
        payload = await self.c.sendUni("MultiMsg.ApplyUp", body)
        rsp = decode(payload)[2]
        if rsp.get(1) != 0:
            v2 = rsp.get(2)
            drop(rsp.get(1), _proto_to_str(v2, "unknown MultiMsg.ApplyUp error"))
        buf = encode({
            1: 1,
            2: 5,
            3: 9,
            4: [{
                1: 1 if self.dm else 3,
                2: self.target,
                4: compressed,
                5: 2,
                6: rsp[3].toBuffer(),
            }],
        })
        ip = _first(rsp.get(4))
        port = _first(rsp.get(5))
        await highwayUpload(self.c, bytes(buf), {
            "cmdid": CmdID.MultiMsg,
            "md5": md5(buf),
            "size": len(buf),
            "ticket": rsp[10].toBuffer(),
        }, ip, port)
        return rsp[2].toString()

    # 制作一条合并转发消息以备发送（制作一次可以到处发）
    # 需要注意的是，好友图片和群图片的内部格式不一样，对着群制作的转发消息中的图片，发给好友可能会裂图，反过来也一样
    # 支持4层套娃转发（PC仅显示3层）
    async def makeForwardMsg(self, msglist, nt=False):
        if not isinstance(msglist, list):
            msglist = [msglist]
        nodes = []
        makers = []
        preview = []
        cnt = 0
        MultiMsg = []
        for fake in msglist:
            brief = None
            if not isinstance(fake.message, list):
                fake.message = [fake.message]
            if len(fake.message) == 1 and not isinstance(fake.message[0], str) \
                    and _get(fake.message[0], "type") in ("xml", "json"):
                elem = fake.message[0]
                resid = None
                fileName = None
                if _get(elem, "type") == "xml":
                    brief_reg = re.search(r'brief="(.*?)"', _get(elem, "data") or "", re.M)
                    if brief_reg and len(brief_reg.groups()) > 0:
                        brief = brief_reg.group(1)
                    else:
                        brief = "[XML]"
                    resid_reg = re.search(r'm_resid="(.*?)"', _get(elem, "data") or "", re.M)
                    fileName_reg = re.search(r'm_fileName="(.*?)"', _get(elem, "data") or "", re.M)
                    if resid_reg and len(resid_reg.groups()) > 1 and fileName_reg and len(fileName_reg.groups()) > 1:
                        resid = resid_reg.group(1)
                        fileName = fileName_reg.group(1)
                elif _get(elem, "type") == "json":
                    brief = "[JSON]"
                    json_ = None
                    try:
                        json_ = _get(elem, "data") if isinstance(_get(elem, "data"), dict) else json.loads(_get(elem, "data"))
                    except Exception:
                        pass
                    if json_:
                        brief = json_.get("prompt")
                        if json_.get("app") == "com.tencent.multimsg" and (json_.get("meta") or {}).get("detail"):
                            detail = json_["meta"]["detail"]
                            resid = detail.get("resid")
                            fileName = detail.get("uniseq")
                if resid and fileName:
                    if nt:
                        buff = await self._newDownloadMultiMsg(str(resid), 1 if self.dm else 2)
                    else:
                        buff = await self._downloadMultiMsg(str(resid), 1 if self.dm else 2)
                    arr = decode(buff)[2]
                    if not isinstance(arr, list):
                        arr = [arr]
                    for val in arr:
                        m_fileName = val[1].toString()
                        if m_fileName == "MultiMsg":
                            MultiMsg.append({
                                1: fileName,
                                2: val[2],
                            })
                        else:
                            MultiMsg.append(val)
            maker = await self._preprocess(fake.message)
            if maker is not None and maker.brief and brief:
                maker.brief = brief
            makers.append(maker)
            seq = int.from_bytes(os.urandom(2), "big", signed=True)
            rand = int.from_bytes(os.urandom(4), "big", signed=True)
            nickname = str(_get(fake, "nickname") or _get(fake, "user_id"))
            if not nickname and isinstance(fake, PrivateMessage):
                f = self.c.fl.get(_get(fake, "user_id"))
                s = self.c.sl.get(_get(fake, "user_id"))
                nickname = (f or {}).get("nickname") or (s or {}).get("nickname") or nickname
            if cnt < 4:
                preview.append({
                    "text": f"{escapeXml(nickname)}: {escapeXml(maker.brief[:50])}",
                })
                cnt += 1
            if nt:
                nodes.append({
                    1: {
                        1: _get(fake, "user_id"),
                        # 2: 'uid',
                        6: self.c.uin if self.dm else None,
                        8: None if self.dm else {
                            1: self.target,
                            2: nickname,
                            5: 2,
                        },
                    },
                    2: {
                        1: 166 if self.dm else 82,
                        4: rand,
                        5: seq,
                        6: _get(fake, "time") or timestamp(),
                        7: 1,
                        8: 0,
                        9: 0,
                    },
                    3: {
                        1: maker.rich,
                    },
                })
            else:
                nodes.append({
                    1: {
                        1: _get(fake, "user_id"),
                        2: self.target,
                        3: 166 if self.dm else 82,
                        4: 11 if self.dm else None,
                        5: seq,
                        6: _get(fake, "time") or timestamp(),
                        7: rand2uuid(rand),
                        9: None if self.dm else {
                            1: self.target,
                            4: nickname,
                        },
                        14: nickname if self.dm else None,
                        20: {
                            1: 0,
                            2: rand,
                        },
                    },
                    3: {
                        1: maker.rich,
                    },
                })
        MultiMsg.append({
            1: "MultiMsg",
            2: {
                1: nodes,
            },
        })
        compressed = await gzip(encode({
            # 1: nodes,
            2: MultiMsg,
        }))
        resid = None
        try:
            resid = await self._newUploadMultiMsg(compressed) if nt else await self._uploadMultiMsg(compressed)
        except Exception:
            resid = await self._newUploadMultiMsg(compressed) if nt else await self._uploadMultiMsg(compressed)
        json_ = {
            "app": "com.tencent.multimsg",
            "config": {"autosize": 1, "forward": 1, "round": 1, "type": "normal", "width": 300},
            "desc": "[聊天记录]",
            "extra": "",
            "meta": {
                "detail": {
                    "news": preview,
                    "resid": resid,
                    "source": "群聊的聊天记录",
                    "summary": f"查看{len(nodes)}条转发消息",
                    "uniseq": uuid().upper(),
                },
            },
            "prompt": "[聊天记录]",
            "ver": "0.0.0.5",
            "view": "contact",
        }
        return {
            "type": "json",
            "data": json_,
        }

    # 下载并解析合并转发
    async def getForwardMsg(self, resid, fileName="MultiMsg", nt=False):
        ret = []
        if nt:
            buf = await self._newDownloadMultiMsg(str(resid), 1 if self.dm else 2)
        else:
            buf = await self._downloadMultiMsg(str(resid), 1 if self.dm else 2)
        a = decode(buf)[2]
        if not isinstance(a, list):
            a = [a]
        for b in a:
            m_fileName = b[1].toString()
            if m_fileName == fileName:
                a = b
                break
        if isinstance(a, list):
            a = a[0]
        a = a[2][1]
        if not isinstance(a, list):
            a = [a]
        for proto in a:
            try:
                ret.append(ForwardMessage(proto))
            except Exception:
                pass
        return ret

    async def _newDownloadMultiMsg(self, resid, bu):
        body = encode({
            1: {
                1: {
                    2: self.target,
                },
                2: resid,
                3: 3 if bu == 2 else 1,
            },
            15: {
                1: 2,
                2: 2,
                3: 9,
                4: 0,
            },
        })
        payload = await self.c.sendUni("trpc.group.long_msg_interface.MsgService.SsoRecvLongMsg", body)
        rsp = decode(payload)
        rsp = rsp.get(1) if rsp is not None else None
        if rsp is None or not rsp.get(4):
            return BUF0
        return await unzip(rsp[4].toBuffer())

    async def _downloadMultiMsg(self, resid, bu):
        body = encode({
            1: 2,
            2: 5,
            3: 9,
            4: 3,
            5: self.c.apk.version,
            7: [{
                1: resid,
                2: 3,
            }],
            8: bu,
            9: 2,
        })
        payload = await self.c.sendUni("MultiMsg.ApplyDown", body)
        rsp = decode(payload)[3]
        ip = int32ip2str(_first(rsp.get(4)))
        port = _first(rsp.get(5))
        url = f"https://{ip}" if port == 443 else f"http://{ip}:{port}"
        url += rsp[2]
        data = await http_get(url, headers={
            "Host": f"{'ssl.' if port == 443 else ''}htdata.qq.com",
            "User-Agent": f"QQ/{self.c.apk.version} CFNetwork/1126",
            "Net-Type": "Wifi",
        })
        # JS: headers["accept-encoding"]?.includes("gzip") 恒为 false（响应头里没有该字段），
        # 且 axios 已透明解压，故直接使用原始数据
        buf = data
        head_len = u32(buf, 1)
        body_len = u32(buf, 5)
        buf = tea_decrypt(buf[head_len + 9:head_len + 9 + body_len], rsp[3].toBuffer())
        return await unzip(decode(buf)[3][3].toBuffer())

    # 获取视频下载地址
    async def getVideoUrl(self, fid, md5_):
        body = encode({
            1: 400,
            4: {
                1: self.c.uin,
                2: self.c.uin,
                3: 1,
                4: 7,
                5: fid,
                6: 1,
                8: md5_ if isinstance(md5_, (bytes, bytearray)) else bytes.fromhex(md5_),
                9: 1,
                10: 2,
                11: 2,
                12: 2,
            },
        })
        payload = await self.c.sendUni("PttCenterSvr.ShortVideoDownReq", body)
        rsp = decode(payload)[4]
        if rsp.get(1) != 0:
            drop(rsp.get(1), "获取视频下载地址失败")
        obj = rsp[9]
        obj10 = obj.get(10)
        return str(obj10[0] if isinstance(obj10, list) else obj10) + str(obj.get(11))


# 两个文件合并到一个流
async def createReadable(file1, file2):
    """JS stream.Readable.from(concatStreams(...)) 的等价物：异步生成器。"""

    async def gen():
        for path in (file1, file2):
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(256 * 1024)
                    if not chunk:
                        break
                    yield chunk

    return gen()


async def getPttBuffer(file, transcoding=True, ffmpeg="ffmpeg"):
    if isinstance(file, (bytes, bytearray)) or file.startswith("base64://"):
        # Buffer或base64
        buf = bytes(file) if isinstance(file, (bytes, bytearray)) else base64.b64decode(file[9:])
        head = buf[:7]
        if b"SILK" in head or b"AMR" in head or not transcoding:
            return buf
        else:
            tmpfile = os.path.join(TMP_DIR, uuid())
            with open(tmpfile, "wb") as f:
                f.write(buf)
            return await audioTrans(tmpfile, ffmpeg, True)
    elif file.startswith("http://") or file.startswith("https://"):
        # 网络文件
        tmpfile = os.path.join(TMP_DIR, uuid())
        data = await http_get(file)
        if len(data) > MAX_UPLOAD_SIZE:
            raise Exception("文件大小超限")
        with open(tmpfile, "wb") as f:
            f.write(data)
        head = await read7Bytes(tmpfile)
        if b"SILK" in head or b"AMR" in head or not transcoding:
            buf = open(tmpfile, "rb").read()
            try:
                os.unlink(tmpfile)
            except OSError:
                pass
            return buf
        else:
            return await audioTrans(tmpfile, ffmpeg, True)
    else:
        # 本地文件
        file = re.sub(r"^file://", "", str(file))
        if IS_WIN and file.startswith("/"):
            file = file[1:]
        head = await read7Bytes(file)
        if b"SILK" in head or b"AMR" in head or not transcoding:
            return open(file, "rb").read()
        else:
            return await audioTrans(file, ffmpeg)


async def audioTransSlik(file, ffmpeg="ffmpeg", temp=False):
    tmpfile = os.path.join(TMP_DIR, uuid())
    try:
        await _exec(f'{ffmpeg} -y -i "{file}" -f s16le -ar 24000 -ac 1 -fs 31457280 "{tmpfile}"')
        pcm = open(tmpfile, "rb").read()
        try:
            slik = (await silk_encode(pcm, 24000)).data
            return bytes(slik)
        except Exception:
            raise ApiRejection(ErrorCode.FFmpegPttTransError, "音频转码到silk失败，请确认你的ffmpeg可以处理此转换")
    except ApiRejection:
        raise
    except Exception:
        raise ApiRejection(ErrorCode.FFmpegPttTransError, "音频转码到pcm失败，请确认你的ffmpeg可以处理此转换")
    finally:
        try:
            os.unlink(tmpfile)
        except OSError:
            pass
        if temp:
            try:
                os.unlink(file)
            except OSError:
                pass


async def audioTrans(file, ffmpeg="ffmpeg", temp=False):
    try:
        slik = await audioTransSlik(file, ffmpeg, temp)
        return slik
    except Exception:
        pass
    tmpfile = os.path.join(TMP_DIR, uuid())
    try:
        await _exec(f'{ffmpeg} -y -i "{file}" -ac 1 -ar 8000 -f amr "{tmpfile}"')
        amr = open(tmpfile, "rb").read()
        return amr
    except Exception:
        raise ApiRejection(ErrorCode.FFmpegPttTransError, "音频转码到amr失败，请确认你的ffmpeg可以处理此转换")
    finally:
        try:
            os.unlink(tmpfile)
        except OSError:
            pass
        if temp:
            try:
                os.unlink(file)
            except OSError:
                pass


async def read7Bytes(file):
    with open(file, "rb") as fd:
        return fd.read(7)
