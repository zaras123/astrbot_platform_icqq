"""客户端内部功能：状态/签名/头像/表情戳/好友分组/列表加载/OCR 等（internal.js 的移植）。"""
from __future__ import annotations

import asyncio
import time

from ..core.buffer import pack_u32
from ..core.device import Platform
from ..core.jce import decodeWrapper, encodeStruct, encodeWrapper
from ..core.pb import decode, encode
from ..errors import drop
from ..guild import Guild
from ..common import timestamp, uuid

from .highway import CmdID, highwayUpload

d50 = encode({
    1: 10002,
    91001: 1,
    101001: 1,
    151001: 1,
    181001: 1,
    251001: 1,
})


async def setStatus(self, status):
    if not status or self.config.get("platform") in [Platform.Watch]:
        return False
    d = self.device
    SvcReqRegister = encodeStruct([
        self.uin,
        7, 0, "", int(status), 0, 0, 0, 0, 0, 248,
        d.version.sdk, 0, "", 0, 0, d.guid, 2052, 0, d.model, d.model,
        d.version.release, 1, 473, 0, 0, 0, 0, "", 0, "",
        "", "", 0, 1, 0, 0, 0, 0, 0,
    ])
    body = encodeWrapper({"SvcReqRegister": SvcReqRegister}, "PushService", "SvcReqRegister")
    payload = await self.sendUni("StatSvc.SetStatusFromClient", body)
    ret = bool(decodeWrapper(payload)[9])
    if ret:
        self.status = int(status)
    return ret


async def setSign(self, sign):
    """
    设置个性签名
    @deprecated 请使用 setPersonalSign
    @param sign {string} 签名
    """
    return await setPersonalSign(self, sign)


async def setPersonalSign(self, sign):
    """
    设置个性签名
    @param sign {string} 签名
    """
    buf = str(sign).encode("utf-8")[:254]
    body = encode({
        1: 2,
        2: int(time.time() * 1000),
        3: {
            1: 109,
            2: {6: 825110830},
            3: self.apk.ver,
        },
        5: {
            1: self.uin,
            2: 0,
            3: 27 + len(buf),
            4: bytes([0x3, len(buf) + 1, 0x20]) + buf + bytes(
                [0x91, 0x04, 0x00, 0x00, 0x00, 0x00, 0x92, 0x04, 0x00, 0x00, 0x00, 0x00,
                 0xA2, 0x04, 0x00, 0x00, 0x00, 0x00, 0xA3, 0x04, 0x00, 0x00, 0x00, 0x00]),
            5: 0,
        },
        6: 1,
    })
    payload = await self.sendUni("Signature.auth", body)
    return decode(payload)[1] == 0


async def getPersonalSign(self):
    body = {
        1: self.uin,
        3: {
            1: [102],
        },
    }
    result = await self.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0xfe1_2", encode(body))
    return result[1][2][2][2].toString()


async def setAvatar(self, img):
    await img.task
    body = encode({
        1281: {
            1: self.uin,
            2: 0,
            3: 16,
            4: 1,
            6: 3,
            7: 5,
        },
    })
    payload = await self.sendUni("HttpConn.0x6ff_501", body)
    rsp = decode(payload)[1281]
    await highwayUpload(self, img.readable, {
        "cmdid": CmdID.SelfPortrait,
        "md5": img.md5,
        "size": img.size,
        "ticket": rsp[1].toBuffer(),
    }, rsp[3][2][0][2], rsp[3][2][0][3])
    img.deleteTmpFile()


async def getStamp(self, no_cache=False):
    if len(self.stamp) > 0 and not no_cache:
        return [f"https://p.qpic.cn/{self.bid}/{self.uin}/{x}/0" for x in self.stamp]
    body = encode({
        1: {
            1: 109,
            2: "7.1.2",
            3: self.apk.ver,
        },
        2: self.uin,
        3: 1,
    })
    payload = await self.sendUni("Faceroam.OpReq", body)
    rsp = decode(payload)
    if rsp[1] != 0:
        drop(rsp[1], rsp[2])
    if rsp[4][1]:
        self.bid = str(rsp[4][3])
        arr = rsp[4][1] if isinstance(rsp[4][1], list) else [rsp[4][1]]
        self.stamp = set(str(x) for x in arr)
    else:
        self.stamp = set()
    return [f"https://p.qpic.cn/{self.bid}/{self.uin}/{x}/0" for x in self.stamp]


async def delStamp(self, id):
    body = encode({
        1: {
            1: 109,
            2: "7.1.2",
            3: self.apk.ver,
        },
        2: self.uin,
        3: 2,
        5: {
            1: id,
        },
    })
    await self.sendUni("Faceroam.OpReq", body)
    for s in id:
        self.stamp.discard(s)


async def addClass(self, name):
    name = name.encode("utf-8")
    length = len(name)
    buf = bytearray(2 + length)
    buf[0] = 0xD
    buf[1] = length
    buf[2:] = name
    SetGroupReq = encodeStruct([
        0, self.uin, bytes(buf),
    ])
    body = encodeWrapper({"SetGroupReq": SetGroupReq}, "mqq.IMService.FriendListServiceServantObj", "SetGroupReq")
    await self.sendUni("friendlist.SetGroupReq", body)


async def delClass(self, id):
    SetGroupReq = encodeStruct([
        2, self.uin, bytes([int(id)]),
    ])
    body = encodeWrapper({"SetGroupReq": SetGroupReq}, "mqq.IMService.FriendListServiceServantObj", "SetGroupReq")
    await self.sendUni("friendlist.SetGroupReq", body)


async def renameClass(self, id, name):
    name = name.encode("utf-8")
    length = len(name)
    buf = bytearray(2 + length)
    buf[0] = int(id)
    buf[1] = length
    buf[2:] = name
    SetGroupReq = encodeStruct([
        1, self.uin, bytes(buf),
    ])
    body = encodeWrapper({"SetGroupReq": SetGroupReq}, "mqq.IMService.FriendListServiceServantObj", "SetGroupReq")
    await self.sendUni("friendlist.SetGroupReq", body)


async def loadFL(self):
    set_ = set()
    start = 0
    limit = 150
    while True:
        FL = encodeStruct([
            3,
            1, self.uin, start, limit, 0,
            1, 0, 0, 0, 1,
            31, 0, 0, 0, 0,
            d50, 0, [13580, 13581, 13582],
        ])
        body = encodeWrapper({"FL": FL}, "mqq.IMService.FriendListServiceServantObj", "GetFriendListReq")
        payload = await self.sendUni("friendlist.getFriendGroupList", body, 10)
        nested = decodeWrapper(payload)
        self.classes.clear()
        for v in nested[14]:
            self.classes[v[0]] = v[1]
        for v in nested[7]:
            uid = v[0]
            info = {
                "user_id": uid,
                "nickname": v.get(14) or "",
                "sex": "male" if v.get(31) == 1 else "female" if v.get(31) else "unknown",
                "remark": v.get(3) or "",
                "class_id": v.get(1),
            }
            old = self.fl.get(uid) or {}
            self.fl[uid] = {**old, **info}
            set_.add(uid)
        start += limit
        if start > nested[5]:
            break
    for uid in list(self.fl.keys()):
        if uid not in set_:
            del self.fl[uid]


async def loadSL(self):
    body = encode({
        1: 1,
        2: {
            1: self.sig.seq + 1,
        },
    })
    payload = await self.sendOidb("OidbSvc.0x5d2_0", body, 10)
    protos = decode(payload)[4][2][2]
    if not protos:
        return
    if not isinstance(protos, list):
        protos = [protos]
    set_ = set()
    for proto in protos:
        self.sl[proto[1]] = {
            "user_id": proto[1],
            "nickname": str(proto[2]),
        }
        set_.add(proto[1])
    for uid in list(self.sl.keys()):
        if uid not in set_:
            del self.sl[uid]


def loadGPL(self):
    """JS 原版不是 async 函数而是返回 Promise，这里保留函数形式返回协程。"""
    async def _sync_first_view():
        try:
            payload = await self.sendUni(
                "trpc.group_pro.synclogic.SyncLogic.SyncFirstView", encode({1: 0, 2: 0, 3: 0}))
            self.tiny_id = str(decode(payload)[6])
        except Exception:
            pass

    async def _wait_push():
        fut = asyncio.Future()

        def _on_push(cmd, payload):
            if cmd != "trpc.group_pro.synclogic.SyncLogic.PushFirstView":
                return
            try:
                proto = decode(payload)
                if proto is not None and proto.get(3):
                    arr = proto[3] if isinstance(proto[3], list) else [proto[3]]
                    tmp = set()
                    for p in arr:
                        id_ = str(p.get(1))
                        name = str(p.get(4))
                        tmp.add(id_)
                        if id_ not in self.guilds:
                            self.guilds[id_] = Guild(self, id_)
                        guild = self.guilds[id_]
                        guild._renew(name, p.get(3))
                    for id_ in list(self.guilds.keys()):
                        if id_ not in tmp:
                            del self.guilds[id_]
            except Exception:
                pass
            if not fut.done():
                fut.set_result(None)

        # JS 中该监听器注册后不摘除，后续 PushFirstView 推送也会走这里刷新频道列表
        self.on("internal.sso", _on_push)
        await asyncio.wait_for(fut, 5.0)

    async def _main():
        # JS 中 SyncFirstView 请求是 fire-and-forget（.catch(NOOP)），不等待
        asyncio.create_task(_sync_first_view())
        await _wait_push()

    return _main()


async def loadGL(self):
    GetTroopListReqV2Simplify = encodeStruct([
        self.uin, 0, 0, [], 1, 8, 0, 1, 1,
    ])
    body = encodeWrapper(
        {"GetTroopListReqV2Simplify": GetTroopListReqV2Simplify},
        "mqq.IMService.FriendListServiceServantObj", "GetTroopListReqV2Simplify")
    payload = await self.sendUni("friendlist.GetTroopListReqV2", body, 10)
    nested = decodeWrapper(payload)
    set_ = set()
    for v in nested[5]:
        gid = v[1]
        info = {
            "group_id": gid,
            "group_name": v.get(4) or "",
            "member_count": v.get(19),
            "max_member_count": v.get(29),
            "owner_id": v.get(23),
            "last_join_time": v.get(27),
            "shutup_time_whole": 0xFFFFFFFF if v.get(9) else 0,
            "shutup_time_me": v.get(10) if (v.get(10) or 0) > timestamp() else 0,
            "admin_flag": bool(v.get(11)),
            "update_time": 0,
        }
        old = self.gl.get(gid) or {}
        self.gl[gid] = {**old, **info}
        set_.add(gid)
    for gid in list(self.gl.keys()):
        if gid not in set_:
            del self.gl[gid]
            if gid in self.gml:
                del self.gml[gid]


async def loadBL(self):
    body = encode({
        1: {
            1: self.uin,
            3: 0,
            4: 1000,
        },
    })
    len_ = bytearray(4)
    len_[0:4] = pack_u32(len(body))
    body = bytes(4) + bytes(len_) + body
    payload = await self.sendUni("SsoSnsSession.Cmd0x3_SubCmd0x1_FuncGetBlockList", body)
    head = decode(payload[8:])
    head = head.get(1) if head is not None else None
    protos = head.get(6) if head is not None else None
    self.blacklist.clear()
    if not protos:
        return
    if not isinstance(protos, list):
        protos = [protos]
    for proto in protos:
        self.blacklist.add(proto[1])


class OcrResult:
    def __init__(self, proto):
        self.wordslist = []
        self.language = proto.get(2).toString() if proto.get(2) is not None else "unknown"
        arr = proto[1] if isinstance(proto.get(1), list) else [proto.get(1)]
        for p in arr:
            if p is None:
                continue
            self.wordslist.append({
                "words": p.get(1).toString() if p.get(1) is not None else "",
                "confidence": float(p.get(2) or 0),
                "polygon": [
                    {"x": float(v.get(1) or 0) if v.get(1) is not None else 0,
                     "y": float(v.get(2) or 0) if v.get(2) is not None else 0}
                    for v in p[3][1]
                ],
            })

    def toString(self):
        str_ = ""
        for elem in self.wordslist:
            str_ += elem["words"]
        return str_

    def __str__(self):
        return self.toString()


async def imageOcr(self, img):
    await img.task
    res = await highwayUpload(self, img.readable, {
        "cmdid": CmdID.Ocr,
        "md5": img.md5,
        "size": img.size,
        "ext": encode({
            1: 0,
            2: uuid(),
        }),
    })
    url = str(res.get(2)) if res is not None else "None"
    body = encode({
        1: 1,
        2: 0,
        3: 1,
        10: {
            1: url,
            10: img.md5.hex(),
            11: img.md5.hex(),
            12: img.size,
            13: img.width,
            14: img.height,
            15: 0,
        },
    })
    payload = await self.sendOidb("OidbSvc.0xe07_0", body, 10)
    rsp = decode(payload)
    if rsp.get(3) != 0:
        drop(rsp.get(3), rsp.get(5))
    return OcrResult(rsp[4][10])
