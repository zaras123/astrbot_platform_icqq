"""频道(子频道)消息相关（guild.js 的移植）。"""
from __future__ import annotations

from ..common import lock
from ..core.pb import decode
from ..message import parse


class GuildMessageEvent:
    """频道消息事件"""

    def __init__(self, proto):
        self.post_type = "message"
        self.detail_type = "guild"
        head1 = proto[1][1][1]
        head2 = proto[1][1][2]
        if head2[1] != 3840:
            raise Exception("unsupport guild message type")
        body = proto[1][3]
        extra = proto[1][4]
        self.guild_id = str(head1[1])
        self.channel_id = str(head1[2])
        self.guild_name = str(extra[2])
        self.channel_name = str(extra[3])
        self.sender = {
            "tiny_id": str(head1[4]),
            "nickname": str(extra[1]),
        }
        self.seq = head2[4]
        self.rand = head2[3]
        self.time = head2[6]
        parsed = parse(body[1])
        self.message = parsed.message
        self.raw_message = parsed.brief
        lock(self, "proto")


def guildMsgListener(self, payload):
    try:
        msg = GuildMessageEvent(decode(payload))
    except Exception:
        return
    if msg.sender["tiny_id"] == self.tiny_id and self.config.get("ignore_self"):
        return
    self.stat.recv_msg_cnt += 1
    self.logger.info(f"recv from: [Guild: {msg.guild_name}, Member: {msg.sender['nickname']}]" + msg.raw_message)

    def _reply(content):
        return self.sendGuildMsg(msg.guild_id, msg.channel_id, content)

    msg.reply = _reply
    self.em("message.guild", msg)
