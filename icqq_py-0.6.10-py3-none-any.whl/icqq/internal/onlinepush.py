"""OnlinePush 相关的推送监听器（onlinepush.js 的移植）。"""
from __future__ import annotations

import asyncio
import datetime

from ..common import OnlineStatus, timestamp
from ..core.buffer import i32, u32
from ..core.jce import decode as jce_decode, decodeWrapper, encodeNested, encodeStruct, encodeWrapper
from ..core.pb import decode as pb_decode
from ..message import DiscussMessage, GroupMessage, PrivateMessage, genDmMessageId, genGroupMessageId


def _obj_get(obj, key):
    """属性/字典两种表示的统一读取（对应 JS obj[key] / obj.key）。"""
    if obj is None:
        return None
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _obj_set(obj, key, value):
    if isinstance(obj, dict):
        obj[key] = value
    else:
        setattr(obj, key, value)


def handleOnlinePush(self, svrip, seq, items=None):
    """OnlinePush回执"""
    if items is None:
        items = []
    resp = encodeStruct([
        self.uin, items, svrip & 0xFFFFFFFF, 0, 0,
    ])
    body = encodeWrapper({"resp": resp}, "OnlinePush", "SvcRespPushMsg", seq)
    self.writeUni("OnlinePush.RespPush", body)


statuslist = [
    None,
    OnlineStatus.Online,
    None,
    OnlineStatus.Absent,
    OnlineStatus.Invisible,
    OnlineStatus.Busy,
    OnlineStatus.Qme,
    OnlineStatus.DontDisturb,
]


def _sub0x27_0(self, data):
    self.classes[data[3][1]] = str(data[3][3])


def _sub0x27_1(self, data):
    v = data[4][1]
    if v in self.classes:
        del self.classes[v]


def _sub0x27_2(self, data):
    self.classes[data[5][1]] = str(data[5][2])


def _sub0x27_4(self, data):
    arr = data[7][1] if isinstance(data[7][1], list) else [data[7][1]]
    for v in arr:
        _obj_set(self.fl.get(v[1]), "class_id", v[3])


def _sub0x27_80(self, data):
    o = data[12]
    gid = o[3]
    if not o[4]:
        return
    _obj_set(self.gl.get(gid), "group_name", str(o[2][2]))


def _sub0x27_5(self, data):
    user_id = data[14][1]
    nickname = _obj_get(self.fl.get(user_id), "nickname") or ""
    if user_id in self.fl:
        del self.fl[user_id]
    self.logger.info(f"更新了好友列表，删除了好友 {user_id}({nickname})")
    return {
        "sub_type": "decrease",
        "user_id": user_id,
        "nickname": nickname,
    }


def _sub0x27_20(self, data):
    # 20002昵称 20009性别 20031生日 23109农历生日 20019说明 20032地区 24002故乡 27372在线状态
    uid = data[8][1]
    o = data[8][2]
    if isinstance(o, list):
        o = o[0]
    key = None
    value = None
    if o[1] == 20002:
        key = "nickname"
        value = str(o[2])
        _obj_set(self.fl.get(uid), "nickname", value)
    elif o[1] == 20009:
        key = "sex"
        value = ["unknown", "male", "female"][o[2].toBuffer()[0]]
    elif o[1] == 20031:
        key = "age"
        value = datetime.date.today().year - u32(o[2].toBuffer(), 0)
    elif o[1] == 27372 and uid == self.uin:
        buf = o[2].toBuffer()
        status = buf[len(buf) - 1]
        self.status = statuslist[status] or 11
        return
    else:
        return
    if uid == self.uin:
        setattr(self, key, value)


def _sub0x27_40(self, data):
    o = data[9][1]
    uid = o[2]
    if (o.get(1) or 0) > 0:
        return  # 0好友备注 1群备注
    _obj_set(self.fl.get(uid), "remark", str(o[3]))


# 好友事件解析
sub0x27 = {
    0: _sub0x27_0,
    1: _sub0x27_1,
    2: _sub0x27_2,
    4: _sub0x27_4,
    80: _sub0x27_80,
    5: _sub0x27_5,
    20: _sub0x27_20,
    40: _sub0x27_40,
}


def _push528_8A(self, buf):
    data = pb_decode(buf)[1]
    if isinstance(data, list):
        data = data[0]
    user_id = data.get(1)
    operator_id = data.get(1)
    flag = 0
    if user_id == self.uin:
        user_id = data.get(2)
        flag = 1
    return {
        "sub_type": "recall",
        "message_id": genDmMessageId(user_id, data.get(3), data.get(6), data.get(5), flag),
        "operator_id": operator_id,
        "user_id": user_id,  # 永远指向对方
        "seq": data.get(3),
        "rand": data.get(6),
        "time": data.get(5),
    }


def _push528_8B(self, buf):
    return _push528_8A(self, buf)


def _push528_B3(self, buf):
    data = pb_decode(buf)[2]
    user_id = data[1]
    nickname = str(data[5])
    self.fl[user_id] = {
        "user_id": user_id,
        "nickname": nickname,
        "sex": "unknown",
        "remark": nickname,
        "class_id": data.get(7),
    }
    if user_id in self.sl:
        del self.sl[user_id]
    self.logger.info(f"更新了好友列表，新增了好友 {user_id}({nickname})")
    return {
        "sub_type": "increase",
        "user_id": user_id,
        "nickname": nickname,
    }


def _push528_D4(self, buf):
    gid = pb_decode(buf)[1]

    async def _renew():
        try:
            await self.pickGroup(gid).renew()
        except Exception:
            pass

    asyncio.create_task(_renew())


def _push528_27(self, buf):
    data = pb_decode(buf)[1]
    if isinstance(data, list):
        data = data[0]
    fn = sub0x27.get(data.get(2))
    if fn:
        return fn(self, data)


def _push528_122(self, buf):
    data = pb_decode(buf)
    e = parsePoke(data)
    if e["action"]:
        e["operator_id"] = e["operator_id"] or self.uin
        e["target_id"] = e["target_id"] or self.uin
        return {**e, "sub_type": "poke"}


def _push528_115(self, buf):
    data = pb_decode(buf)
    user_id = data.get(1)
    end = (data.get(3) or {}).get(4) == 2
    self.emit("internal.input", {"user_id": user_id, "end": end})


push528 = {
    0x8A: _push528_8A,
    0x8B: _push528_8B,
    0xB3: _push528_B3,
    0xD4: _push528_D4,
    0x27: _push528_27,
    0x122: _push528_122,
    0x115: _push528_115,
}


def parsePoke(data):
    target_id = 0
    operator_id = 0
    action = ""
    suffix = ""
    for o in data.get(7) or []:
        name = str(o.get(1))
        val = str(o.get(2))
        if name == "action_str" or name == "alt_str1":
            action = action or val
        elif name == "uin_str1":
            operator_id = int(val)
        elif name == "uin_str2":
            target_id = int(val)
        elif name == "suffix_str":
            suffix = val
    return {"target_id": target_id, "operator_id": operator_id, "action": action, "suffix": suffix}


def parseSign(self, data):
    user_id = self.uin
    nickname = ""
    sign_text = ""
    for o in data.get(7) or []:
        name = str(o.get(1))
        val = str(o.get(2))
        if name == "user_sign":
            sign_text = sign_text or val
        elif name == "mqq_uin":
            user_id = int(val)
        elif name == "mqq_nick":
            nickname = val
    return {"user_id": user_id, "nickname": nickname, "sign_text": sign_text}


def _push732_0C(self, gid, buf):
    operator_id = u32(buf, 6)
    user_id = u32(buf, 16)
    duration = u32(buf, 20)
    try:
        if user_id == 0:
            duration = 0xFFFFFFFF if duration else 0
            _obj_set(self.gl.get(gid), "shutup_time_whole", duration)
        elif user_id == self.uin:
            _obj_set(self.gl.get(gid), "shutup_time_me", timestamp() + duration if duration else 0)
        _obj_set((self.gml.get(gid) or {}).get(user_id), "shutup_time", timestamp() + duration if duration else 0)
    except Exception:
        pass
    self.logger.info(f"用户{user_id}在群{gid}被禁言{duration}秒")
    return {
        "sub_type": "ban",
        "operator_id": operator_id,
        "user_id": user_id,
        "duration": duration,
    }


def _push732_11(self, gid, buf):
    data = pb_decode(buf[7:])[11]
    operator_id = data.get(1)
    msg = data[3][0] if isinstance(data.get(3), list) else data.get(3)
    user_id = msg.get(6)
    message_id = genGroupMessageId(
        gid, user_id, msg.get(1), msg.get(3), msg.get(2),
        len(data[3]) if isinstance(data.get(3), list) else 1)
    return {
        "sub_type": "recall",
        "user_id": user_id,
        "operator_id": operator_id,
        "message_id": message_id,
        "seq": msg.get(1),
        "rand": msg.get(3),
        "time": msg.get(2),
    }


def _push732_14(self, gid, buf):
    data = pb_decode(buf[7:])[26]
    e = parsePoke(data)
    if e["action"]:
        e["operator_id"] = e["operator_id"] or self.uin
        e["target_id"] = e["target_id"] or self.uin
        return {
            **e,
            "sub_type": "poke",
            # @deprecated
            "user_id": e["target_id"],
        }
    sign = {"gid": gid}
    sign.update(parseSign(self, data))
    if sign["sign_text"]:
        return {
            "sub_type": "sign",
            **sign,
        }


def _push732_0E(self, gid, buf):
    if buf[5] != 1:
        return
    duration = i32(buf, 10)
    if buf[14] != 0:
        nickname = buf[15:15 + buf[14]].decode("utf-8", errors="replace")
        operator_id = u32(buf, 6)
        self.logger.info(f"匿名用户{nickname}在群{gid}被禁言{duration}秒")
        return {
            "sub_type": "ban",
            "operator_id": operator_id,
            "user_id": 80000000,
            "nickname": nickname,
            "duration": duration,
        }


# 群事件解析
push732 = {
    0x0C: _push732_0C,
    0x11: _push732_11,
    0x14: _push732_14,
    0x0E: _push732_0E,
}


def emitFriendNoticeEvent(c, uid, e):
    if not e:
        return
    name = "notice.friend." + e["sub_type"]
    f = c.pickFriend(uid)
    event = {
        "post_type": "notice",
        "notice_type": "friend",
        "user_id": uid,
        "friend": f,
        **e,
    }
    c.em(name, event)


def emitGroupNoticeEvent(c, gid, e):
    if not e:
        return
    name = "notice.group." + e["sub_type"]
    group = c.pickGroup(gid)
    event = {
        "post_type": "notice",
        "notice_type": "group",
        "group_id": gid,
        "group": group,
        **e,
    }
    c.em(name, event)


def onlinePushListener(self, payload, seq):
    nested = decodeWrapper(payload)
    list_ = nested[2]
    v = list_[0]
    rubbish = encodeNested([
        self.uin, v[1], v[3], v[8], 0, 0, 0, 0, 0, 0, 0,
    ])
    handleOnlinePush(self, nested[3], seq, [rubbish])
    if not self._sync_cookie:
        return
    if v[2] == 528:
        uid = v[0]
        nested2 = jce_decode(v[6])
        type_ = nested2.get(0)
        buf = nested2.get(10)
        fn = push528.get(type_)
        emitFriendNoticeEvent(self, uid, fn(self, buf) if fn else None)
        r = pb_decode(buf)
        r1 = r.get(1) if r is not None else None
        if r1 is not None and r1.get(2) == 214:
            # 214上报
            req = encodeStruct([self.uin, self.device.android_id, 0])
            servant = "VIP.CustomOnlineStatusServer.CustomOnlineStatusObj"
            func = "GetCustomOnlineStatus"
            body = encodeWrapper({"req": req}, servant, func)
            self.writeUni(f"VipCustom.{func}", body)
    elif v[2] == 732:
        gid = u32(v[6], 0)
        type_ = v[6][4]
        fn = push732.get(type_)
        emitGroupNoticeEvent(self, gid, fn(self, gid, v[6]) if fn else None)


def onlinePushTransListener(self, payload, seq):
    proto = pb_decode(payload)
    handleOnlinePush(self, proto.get(11), seq)
    if not self._sync_cookie:
        return
    v10 = proto.get(10)
    buf = v10.toBuffer() if v10 is not None else b""
    gid = u32(buf, 0)
    if proto.get(3) == 44:
        if buf[5] == 0 or buf[5] == 1:
            user_id = u32(buf, 6)
            set_ = buf[10] > 0
            self.logger.info(f"群{gid}设置管理员{user_id}: " + str(set_))
            emitGroupNoticeEvent(self, gid, {
                "sub_type": "admin",
                "user_id": user_id,
                "set": set_,
            })
            if user_id == self.uin:
                _obj_set(self.gl.get(gid), "admin_flag", set_)
            _obj_set((self.gml.get(gid) or {}).get(user_id), "role", "admin" if set_ else "member")
        elif buf[5] == 0xFF:
            operator_id = u32(buf, 6)
            user_id = u32(buf, 10)
            self.logger.info(f"群{gid}被转让给" + str(user_id))
            emitGroupNoticeEvent(self, gid, {
                "sub_type": "transfer",
                "operator_id": operator_id,
                "user_id": user_id,
            })
            _obj_set(self.gl.get(gid), "owner_id", user_id)
            _obj_set((self.gml.get(gid) or {}).get(user_id), "role", "owner")
            _obj_set((self.gml.get(gid) or {}).get(operator_id), "role", "member")
    elif proto.get(3) == 34:
        user_id = u32(buf, 5)
        operator_id = None
        dismiss = False
        member = (self.gml.get(gid) or {}).get(user_id)
        if buf[9] == 0x82 or buf[9] == 0x2:
            operator_id = user_id
            m = self.gml.get(gid)
            if m is not None:
                m.pop(user_id, None)
            self.logger.info(f"{user_id}离开了群{gid}")
        else:
            operator_id = u32(buf, 10)
            if buf[9] == 0x01 or buf[9] == 0x81:
                dismiss = True
            if user_id == self.uin:
                self.gl.pop(gid, None)
                self.gml.pop(gid, None)
                self.logger.info(f"更新了群列表，删除了群：{gid}")
            else:
                m = self.gml.get(gid)
                if m is not None:
                    m.pop(user_id, None)
                self.logger.info(f"{user_id}离开了群{gid}")
        emitGroupNoticeEvent(self, gid, {
            "sub_type": "decrease",
            "user_id": user_id,
            "operator_id": operator_id,
            "dismiss": dismiss,
            "member": member,
        })
        _obj_set(self.gl.get(gid), "member_count", (_obj_get(self.gl.get(gid), "member_count") or 0) - 1)


def dmMsgSyncListener(self, payload, seq):
    proto = pb_decode(payload)
    handleOnlinePush(self, proto.get(2), seq)
    msg = PrivateMessage(proto[1], self.uin)
    msg.sender.nickname = self.nickname
    self.em("sync.message", msg)


# 分片消息缓存（JS: const fragmap = new Map()）
fragmap = {}


async def _frag_delete(k):
    await asyncio.sleep(5)
    fragmap.pop(k, None)


def groupMsgListener(self, payload):
    self.stat.recv_msg_cnt += 1
    if not self._sync_cookie:
        return
    msg = GroupMessage(pb_decode(payload)[1])
    self.emit(f"internal.{msg.group_id}.{msg.rand}", msg.message_id)
    if msg.user_id == self.uin and self.config.get("ignore_self"):
        return
    # 分片专属屎山
    if msg.pktnum > 1:
        k = ",".join([str(self.uin), str(msg.group_id), str(msg.user_id), str(msg.div)])
        if k not in fragmap:
            fragmap[k] = []
        arr = fragmap[k]
        arr.append(msg)
        asyncio.create_task(_frag_delete(k))
        if len(arr) != msg.pktnum:
            return
        msg = GroupMessage.combine(arr)
    if msg.raw_message:
        group = self.pickGroup(msg.group_id)
        member = group.pickMember(msg.sender.user_id)
        msg.group = group
        msg.member = member

        def _reply(content, quote=False):
            return msg.group.sendMsg(content, msg if quote else None)

        def _recall():
            return msg.group.recallMsg(msg)

        msg.reply = _reply
        msg.recall = _recall
        sender = msg.sender
        if msg.member.info:
            info = msg.member.info
            sender.nickname = _obj_get(info, "nickname")
            sender.sex = _obj_get(info, "sex")
            sender.age = _obj_get(info, "age")
            sender.area = _obj_get(info, "area") or ""
            _obj_set(info, "card", sender.card)
            _obj_set(info, "title", sender.title)
            _obj_set(info, "level", sender.level)
            _obj_set(info, "last_sent_time", timestamp())
        self.logger.info(
            f"recv from: [Group: {msg.group_name}({msg.group_id}), "
            f"Member: {sender.card or sender.nickname}({sender.user_id})] " + str(msg))
        self.em("message.group." + msg.sub_type, msg)
        _obj_set(msg.group.info, "last_sent_time", timestamp())


def discussMsgListener(self, payload, seq):
    self.statistics.recv_msg_cnt += 1
    proto = pb_decode(payload)
    handleOnlinePush(self, proto.get(2), seq)
    if not self._sync_cookie:
        return
    msg = DiscussMessage(proto[1])
    if msg.user_id == self.uin and self.config.get("ignore_self"):
        return
    if msg.raw_message:
        msg.discuss = self.pickDiscuss(msg.discuss_id)
        msg.reply = msg.discuss.sendMsg
        self.logger.info(
            f"recv from: [Discuss: {msg.discuss_name}({msg.discuss_id}), "
            f"Member: {msg.sender.card}({msg.sender.user_id})] " + str(msg))
        self.em("message.discuss", msg)
