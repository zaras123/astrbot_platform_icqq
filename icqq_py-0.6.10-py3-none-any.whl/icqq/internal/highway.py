"""highway 上传通道（highway.js 的移植）。

- highwayUpload: TCP 通道（asyncio open_connection 实现 Node net.connect 的等价物；
  wire 协议字节布局与 JS 完全一致）
- highwayHttpUpload: HTTP 通道（aiohttp，经 core/http.py 封装）
- readable: 字节流的异步可迭代对象（实体类会传 _BytesStream/_FileStream 这类
  async 迭代器，按 async for 消费；同时兼容 bytes 与同步可迭代对象）

偏离说明：JS 用 Node 流 pipe；Python 用「写循环 + 读循环」两个协程并发，
响应处理（百分比/完成/错误码）语义与 JS 逐条对应。
"""
from __future__ import annotations

import asyncio
import os
import time
from enum import IntEnum

from ..core.base_client import ApiRejection
from ..core.buffer import i32, pack_u32
from ..core.constants import BUF0, int32ip2str, md5
from ..core.http import http_post
from ..core.pb import Proto, decode as pb_decode, encode as pb_encode
from ..core.tea import encrypt as tea_encrypt
from ..errors import ErrorCode


class CmdID(IntEnum):
    DmImage = 1
    GroupImage = 2
    SelfPortrait = 5
    ShortVideo = 25
    DmPtt = 26
    MultiMsg = 27
    GroupPtt = 29
    OfflineFile = 69
    GroupFile = 71
    Ocr = 76


# JS: const __ = Buffer.from([41])
__ = bytes([41])


class _CancelError(Exception):
    """对应 JS axios 的 Cancel 错误（highwayHttpUpload 内部使用）。"""


def _to_buffer(v):
    """JS `v.toBuffer()` 的安全等价物。"""
    if isinstance(v, Proto):
        return v.toBuffer()
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    return BUF0


async def _each(readable):
    """把各种「可读流」统一成 bytes 块的异步迭代器。

    兼容三种形态：
    - bytes / bytearray：单块
    - 类文件对象（open(path, "rb") / io.BytesIO，实体类 Image.readable 即这种）：循环 .read(n)
    - 异步可迭代对象（_BytesStream/_FileStream 等）与普通同步可迭代对象
    """
    if isinstance(readable, (bytes, bytearray)):
        yield bytes(readable)
        return
    read = getattr(readable, "read", None)
    if read is not None:
        # 同步类文件对象：循环 .read(n)
        while True:
            chunk = read(1048576)
            if not chunk:
                break
            yield bytes(chunk)
        return
    if hasattr(readable, "__aiter__"):
        async for chunk in readable:
            yield bytes(chunk)
        return
    for chunk in readable:
        yield bytes(chunk)


class HighwayTransform:
    """对应 JS 的 HighwayTransform（Node Transform 流 → 帧生成器）。"""

    def __init__(self, c, obj):
        self.c = c
        self.obj = obj
        # randomBytes(2).readUInt16BE()
        self.seq = int.from_bytes(os.urandom(2), "big")
        self.offset = 0
        if not obj.get("ticket"):
            self.obj["ticket"] = c.sig.bigdata.sig_session
        if obj.get("encrypt") and obj.get("ext"):
            self.obj["ext"] = tea_encrypt(obj["ext"], c.sig.bigdata.session_key)

    def _transform(self, data: bytes):
        offset = 0
        limit = 1048576
        while offset < len(data):
            chunk = data[offset:limit + offset]
            head = pb_encode({
                1: {
                    1: 1,
                    2: str(self.c.uin),
                    3: "PicUp.DataUp",
                    4: self.seq,
                    6: self.c.apk.subid,
                    7: 4096,
                    8: self.obj["cmdid"],
                    10: 2052,
                },
                2: {
                    2: self.obj["size"],
                    3: self.offset + offset,
                    4: len(chunk),
                    6: self.obj["ticket"],
                    8: md5(chunk),
                    9: self.obj["md5"],
                },
                3: self.obj.get("ext"),  # JS: 未提供 ext 时为 undefined，pb encode 跳过
            })
            self.seq += 1
            offset += len(chunk)
            _ = bytearray(9)
            _[0] = 40
            _[1:5] = pack_u32(len(head))
            _[5:9] = pack_u32(len(chunk))
            yield bytes(_)
            yield head
            yield chunk
            yield __
        self.offset += len(data)


async def highwayUpload(self, readable, obj, ip=None, port=None):
    """highway上传数据 (只能上传流)"""
    ip = int32ip2str(ip or self.sig.bigdata.ip)
    port = port or self.sig.bigdata.port
    if not port:
        raise ApiRejection(ErrorCode.NoUploadChannel, "没有上传通道，如果你刚刚登录，请等待几秒")
    if not readable:
        raise ApiRejection(ErrorCode.HighwayFileTypeError, "不支持的file类型")
    md5hex = obj["md5"].hex() if isinstance(obj["md5"], (bytes, bytearray)) else str(obj["md5"])
    highway = HighwayTransform(self, obj)

    async def _attempt(_ip, _port):
        result = {"done": False, "rsp7": None, "err": None, "had_error": False}
        stop = asyncio.Event()
        self.logger.debug(f"[{md5hex}]highway ip:{_ip} port:{_port}")
        try:
            reader, writer = await asyncio.wait_for(asyncio.open_connection(_ip, _port), 6)
        except Exception:
            # JS: connect timeout → socket.destroy → close(had_error=true)
            result["had_error"] = True
            return result

        def handleRspHeader(header):
            rsp = pb_decode(header)
            v3 = rsp.get(3) if rsp is not None else None
            if isinstance(v3, int) and v3 != 0:
                self.logger.warn(f"[{md5hex}]highway upload failed (code: {v3})")
                result["err"] = ApiRejection(v3, f"[{md5hex}]unknown highway error")
                stop.set()
                return
            percentage = f"{(rsp[2][3] + rsp[2][4]) / rsp[2][2] * 100:.2f}"
            # rsp[2][9].toBuffer()
            self.logger.debug(f"[{md5hex}]highway chunk uploaded ({percentage}%)")
            if callable(obj.get("callback")):
                obj["callback"](percentage)
            if float(percentage) >= 100:
                result["done"] = True
                result["rsp7"] = rsp.get(7) if rsp is not None else None
                stop.set()

        async def read_loop():
            buf = BUF0
            while not stop.is_set():
                try:
                    chunk = await reader.read(65536)
                except Exception as err:
                    self.logger.error(err)
                    result["had_error"] = True
                    return
                if not chunk:
                    # 服务器关闭连接
                    result["had_error"] = True
                    return
                try:
                    buf = buf + chunk if buf else chunk
                    while len(buf) >= 5:
                        length = i32(buf, 1)
                        if len(buf) >= length + 10:
                            try:
                                handleRspHeader(buf[9:length + 9])
                            except Exception as err:
                                self.logger.error(err)
                            buf = buf[length + 10:]
                        else:
                            break
                except Exception as err:
                    self.logger.error(err)

        async def write_loop():
            try:
                async for data in _each(readable):
                    for frame in highway._transform(data):
                        writer.write(frame)
                await writer.drain()
            except Exception as err:
                self.logger.error(err)

        write_task = asyncio.create_task(write_loop())
        try:
            if (obj.get("timeout") or 0) > 0:
                try:
                    await asyncio.wait_for(read_loop(), obj["timeout"])
                except asyncio.TimeoutError:
                    # JS: upload_timeout → socket.end() + reject(HighwayTimeout)
                    result["err"] = ApiRejection(
                        ErrorCode.HighwayTimeout, f"[{md5hex}]上传超时({obj['timeout']}s)")
            else:
                await read_loop()
        finally:
            # JS: resolve 或 error 后 socket.end()
            try:
                writer.close()
            except Exception:
                pass
            if not write_task.done():
                write_task.cancel()
        return result

    res = await _attempt(ip, port)
    if res["done"]:
        return res["rsp7"]
    err = res["err"] or ApiRejection(ErrorCode.HighwayNetworkError, f"[{md5hex}]上传遇到网络错误")
    if res["had_error"] and str(ip) != str(int32ip2str(self.sig.bigdata.ip)) and self.sig.bigdata.port:
        # JS: close(had_error) 且 ip 与 bigdata.ip 不同 → 用 bigdata 重试一次
        self.logger.error(f"[{md5hex}]highway ip:{ip} port:{port} network error")
        res2 = await _attempt(int32ip2str(self.sig.bigdata.ip), self.sig.bigdata.port)
        if res2["done"]:
            return res2["rsp7"]
        raise res2["err"] or ApiRejection(ErrorCode.HighwayNetworkError, f"[{md5hex}]上传遇到网络错误")
    raise err


async def highwayHttpUpload(self, readable, obj, ip=None, port=None):
    ip = int32ip2str(ip or self.sig.bigdata.ip)
    port = port or self.sig.bigdata.port
    if not port:
        raise ApiRejection(ErrorCode.NoUploadChannel, "没有上传通道，如果你刚刚登录，请等待几秒")
    self.logger.debug(f"highway(http) ip:{ip} port:{port}")
    url = "http://" + str(ip) + ":" + str(port) + "/cgi-bin/httpconn?htcmd=0x6FF0087&uin=" + str(self.uin)
    seq = 1
    offset = 0
    limit = 524288
    obj["ticket"] = self.sig.bigdata.sig_session
    tasks = []
    abort = False
    finished = 0

    async def _post(buf):
        nonlocal abort, finished
        if abort:
            raise _CancelError()
        # JS: axios.post(url, buf, {...}).then(...).catch(reject)
        resp = await http_post(url, buf, headers={
            "Content-Length": str(len(buf)),
            "Content-Type": "application/octet-stream",
        }, timeout=20.0)
        try:
            header = resp[9:len(resp) - 1]
            rsp = pb_decode(header)
        except Exception as err:
            self.logger.error(err)
            raise
        rsp7buf = _to_buffer(rsp.get(7)) if rsp is not None else BUF0
        v3 = rsp.get(3) if rsp is not None else None
        if v3 != 0:
            abort = True
            raise ApiRejection(v3, "unknown highway error")
        finished += 1
        percentage = f"{finished / len(tasks) * 100:.2f}"
        self.logger.debug(f"highway(http) chunk uploaded ({percentage}%)")
        if callable(obj.get("callback")) and percentage:
            obj["callback"](percentage)
        if finished < len(tasks) and len(rsp7buf) > 0:
            abort = True
            self.logger.debug("highway(http) chunk uploaded (100.00%)")
            if callable(obj.get("callback")):
                obj["callback"]("100.00")
        if finished >= len(tasks) and not len(rsp7buf):
            raise ApiRejection(ErrorCode.UnsafeFile, "文件校验未通过，上传失败")

    async for data in _each(readable):
        _offset = 0
        while _offset < len(data):
            chunk = data[_offset:limit + _offset]
            head = pb_encode({
                1: {
                    1: 1,
                    2: str(self.uin),
                    3: "PicUp.DataUp",
                    4: seq,
                    5: 0,
                    6: self.apk.subid,
                    8: obj["cmdid"],
                },
                2: {
                    1: 0,
                    2: obj["size"],
                    3: offset + _offset,
                    4: len(chunk),
                    6: obj["ticket"],
                    8: md5(chunk),
                    9: obj["md5"],
                    10: 0,
                    13: 0,
                },
                3: obj.get("ext"),  # JS: 未提供 ext 时为 undefined，pb encode 跳过
                4: int(time.time() * 1000),
            })
            seq += 1
            _offset += len(chunk)
            _ = bytearray(9)
            _[0] = 40
            _[1:5] = pack_u32(len(head))
            _[5:9] = pack_u32(len(chunk))
            buf = bytes(_) + head + chunk + __
            tasks.append(asyncio.create_task(_post(buf)))
        offset += len(data)
    # JS: readable 的 end 事件 → Promise.all(tasks)
    #     出错时若为 Cancel 则 resolve(undefined)，否则 cancel 全部并 reject
    try:
        await asyncio.gather(*tasks)
    except _CancelError:
        return None
    except BaseException as err:
        for t in tasks:
            t.cancel()
        raise
    for t in tasks:
        t.cancel()
    return None
