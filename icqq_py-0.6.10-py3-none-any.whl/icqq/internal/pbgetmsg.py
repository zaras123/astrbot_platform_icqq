"""MessageSvc.PbGetMsg 消息同步（pbgetmsg.js 的移植）。"""
from __future__ import annotations

import asyncio
import os

from ..common import timestamp, uin2code
from ..core.buffer import u32
from ..core.jce import decodeWrapper
from ..core.pb import decode, encode
from ..message import PrivateMessage
from .onlinepush import emitGroupNoticeEvent


def _info_get(info, key):
    """属性/字典两种表示的统一读取。"""
    if info is None:
        return None
    if isinstance(info, dict):
        return info.get(key)
    return getattr(info, key, None)


def _info_set(info, key, value):
    if isinstance(info, dict):
        info[key] = value
    else:
        setattr(info, key, value)


def buildSyncCookie(seed):
    """@param seed 填一个常数"""
    time = timestamp()
    return encode({
        1: time,
        2: time,
        3: seed,
        4: 0xFFFFFFFF - seed,
        5: int.from_bytes(os.urandom(4), "big"),
        9: int.from_bytes(os.urandom(4), "big"),
        11: int.from_bytes(os.urandom(4), "big"),
        12: seed & 0xFF,
        13: time,
        14: 0,
    })


async def _handleSyncMsg(self, msg):
    try:
        await handleSyncMsg(self, msg)
    except Exception as e:
        self.logger.debug(e)


async def pbGetMsg(self):
    if not self._sync_cookie:
        self._sync_cookie = buildSyncCookie(u32(self.sig.session, 0))
    body = encode({
        1: 0,
        2: self._sync_cookie,
        3: 0,
        4: 20,
        5: 3,
        6: 1,
        7: 1,
        9: 1,
    })
    payload = await self.sendUni("MessageSvc.PbGetMsg", body)
    proto = decode(payload)
    rubbish = []
    if proto is None:
        return
    if proto.get(3):
        self._sync_cookie = proto[3].toBuffer()
    if proto.get(1, 0) > 0 or not proto.get(5):
        return
    arr5 = proto[5]
    if not isinstance(arr5, list):
        arr5 = [arr5]
    for v in arr5:
        v4 = v.get(4)
        if not v4:
            continue
        if not isinstance(v4, list):
            v4 = [v4]
        for msg in v4:
            item = dict(msg[1])
            item[3] = 187
            rubbish.append(item)
            # JS: handleSyncMsg.call(this, msg).catch(e => this.logger.debug(e))
            asyncio.create_task(_handleSyncMsg(self, msg))
    if len(rubbish):
        self.writeUni("MessageSvc.PbDeleteMsg", encode({1: rubbish}))


typelist = [33, 38, 85, 141, 166, 167, 208, 529]


async def handleSyncMsg(self, proto):
    head = proto.get(1)
    if head is None:
        return
    type_ = head.get(3)
    from_ = head.get(1)
    to = head.get(2)
    if from_ == self.uin and from_ != to:
        return
    if type_ not in typelist:
        return
    if self._msgExists(from_, type_, head.get(5), head.get(6)):
        return
    # 群员入群
    if type_ == 33:
        gid = uin2code(from_)
        user_id = head.get(15)
        nickname = str(head.get(16))
        g = self.pickGroup(gid)
        if user_id == self.uin:
            try:
                await g.renew()
            except Exception:
                pass
            if self.config.get("cache_group_member"):
                g.getMemberMap()
            self.logger.info(f"更新了群列表，新增了群：{gid}")
        else:
            try:
                info = g.info
                _info_set(info, "member_count", (_info_get(info, "member_count") or 0) + 1)
                _info_set(info, "last_join_time", timestamp())
            except Exception:
                pass
            if self.config.get("cache_group_member"):
                try:
                    await g.pickMember(user_id).renew()
                except Exception:
                    pass
            self.logger.info(f"{user_id}({nickname}) 加入了群 {gid}")
        emitGroupNoticeEvent(self, gid, {
            "sub_type": "increase",
            "user_id": user_id,
            "nickname": nickname,
        })
    # 被管理批准入群，建群
    elif type_ == 85 or type_ == 38:
        gid = uin2code(from_)
        user_id = self.uin
        nickname = self.nickname
        g = self.pickGroup(gid)
        try:
            await g.renew()
        except Exception:
            pass
        if self.config.get("cache_group_member"):
            g.getMemberMap()
        self.logger.info(f"更新了群列表，新增了群：{gid}")
        emitGroupNoticeEvent(self, gid, {
            "sub_type": "increase",
            "user_id": user_id,
            "nickname": nickname,
        })
    # 私聊消息
    else:
        self.stat.recv_msg_cnt += 1
        msg = PrivateMessage(proto, self.uin)
        if msg.raw_message:
            msg.friend = self.pickFriend(msg.from_id)
            if msg.sub_type == "friend":
                finfo = _info_get(msg.friend, "info")
                msg.sender.nickname = (_info_get(finfo, "nickname") or ""
                                       ) or _info_get(self.sl.get(msg.from_id), "nickname") or ""
            elif msg.sub_type == "self":
                msg.sender.nickname = self.nickname

            def _reply(content, quote=False):
                if msg.sender.group_id:
                    return msg.friend.asMember(msg.sender.group_id).sendMsg(content, msg if quote else None)
                return msg.friend.sendMsg(content, msg if quote else None)

            msg.reply = _reply
            self.logger.info(f"recv from: [Private: {msg.from_id}({msg.sub_type})] " + str(msg))
            self.em("message.private." + msg.sub_type, msg)


def pushReadedListener(self, payload):
    nested = decodeWrapper(payload[4:])
    for v in nested[1]:
        self.em("sync.read.private", {
            "user_id": v[0],
            "timestamp": v[1],
        })
    for v in nested[2]:
        self.em("sync.read.group", {
            "group_id": v[0],
            "seq": v[3],
        })
