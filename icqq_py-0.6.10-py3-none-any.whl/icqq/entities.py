"""实体数据结构（entities.js 的移植）。

entities.js 只导出 TypeScript 接口（无运行时代码），这里用 TypedDict 保留结构定义，
供类型标注与文档使用。
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional, TypedDict

if TYPE_CHECKING:
    # 仅类型标注使用，避免运行时循环依赖
    from .common import Gender, GroupRole


class StrangerInfo(TypedDict):
    """陌生人资料"""
    # 帐号
    user_id: int
    # 昵称
    nickname: str


class FriendInfo(StrangerInfo):
    """好友资料"""
    # 性别
    sex: Gender
    # 备注
    remark: str
    # 分组id
    class_id: int


class GroupInfo(TypedDict):
    """群资料"""
    # 群号
    group_id: int
    # 群名
    group_name: str
    # 群员数
    member_count: int
    # 群员上限
    max_member_count: int
    # 群主账号
    owner_id: int
    # 是否为该群管理员
    admin_flag: bool
    # 上次入群时间
    last_join_time: int
    # 上次发言时间
    last_sent_time: Optional[int]
    # 全体禁言时间
    shutup_time_whole: int
    # 被禁言时间
    shutup_time_me: int
    # 群创建时间
    create_time: Optional[int]
    # 群活跃等级
    grade: Optional[int]
    # 管理员上限
    max_admin_count: Optional[int]
    # 在线群员数
    active_member_count: Optional[int]
    # 群信息更新时间
    update_time: int


class MemberInfo(TypedDict):
    """群员资料"""
    # 所在群号
    group_id: int
    # 群员账号
    user_id: int
    # 昵称
    nickname: str
    # 性别
    sex: Gender
    # 群名片
    card: str
    # 年龄
    age: int
    # 地区
    area: Optional[str]
    # 入群时间
    join_time: int
    # 上次发言时间
    last_sent_time: int
    # 聊天等级
    level: int
    # 聊天排名
    rank: Optional[str]
    # 群权限
    role: GroupRole
    # 头衔
    title: str
    # 头衔到期时间
    title_expire_time: int
    # 禁言时间
    shutup_time: int
    # 群员信息更新时间
    update_time: int
