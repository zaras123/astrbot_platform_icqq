"""子频道实体（channel.js 的移植）。"""
from __future__ import annotations

import os
from enum import IntEnum

from .core import pb
from .core.base_client import ApiRejection
from .core.constants import lock
from .message import Converter, buildMusic
from .message.share import buildShare


class NotifyType(IntEnum):
    """通知类型"""
    # 未知类型
    Unknown = 0
    # 所有消息
    AllMessages = 1
    # 不通知
    Nothing = 2


class ChannelType(IntEnum):
    """子频道类型"""
    # 未知类型
    Unknown = 0
    # 文字频道
    Text = 1
    # 语音频道
    Voice = 2
    # 直播频道
    Live = 5
    # @todo 未知类型
    App = 6
    # 论坛频道
    Forum = 7


def _pick(obj, *keys):
    """JS 可选链 obj?.[k1]?.[k2]... 的等价物。"""
    cur = obj
    for k in keys:
        if cur is None:
            return None
        if isinstance(cur, dict):
            cur = cur.get(k)
        elif isinstance(cur, list) and isinstance(k, int) and 0 <= k < len(cur):
            cur = cur[k]
        else:
            return None
    return cur


class Channel:
    """子频道"""

    def __init__(self, guild, channel_id: str):
        self.guild = guild
        self.channel_id = channel_id
        # 子频道名
        self.channel_name = ""
        # 频道类型
        self.channel_type = ChannelType.Unknown
        # 通知类型
        self.notify_type = NotifyType.Unknown
        lock(self, "guild")
        lock(self, "channel_id")

    @property
    def c(self):
        return self.guild.c

    def _renew(self, channel_name: str, notify_type: int, channel_type: int) -> None:
        self.channel_name = channel_name
        self.notify_type = notify_type
        self.channel_type = channel_type

    async def shareUrl(self, content, config=None) -> None:
        """发送网址分享"""
        body = buildShare(self.channel_id, self.guild.guild_id, content, config)
        await self.c.sendOidb("OidbSvc.0xb77_9", pb.encode(body))

    async def shareMusic(self, platform: str, id_: str) -> None:
        """发送音乐分享"""
        body = await buildMusic(self.channel_id, self.guild.guild_id, platform, id_)
        await self.c.sendOidb("OidbSvc.0xb77_9", pb.encode(body))

    async def sendMsg(self, content) -> dict:
        """
        发送频道消息
        暂时仅支持发送： 文本、AT、表情
        """
        converter = Converter(content)
        payload = await self.c.sendUni(
            "MsgProxy.SendMsg",
            pb.encode(
                {
                    1: {
                        1: {
                            1: {
                                1: int(self.guild.guild_id),
                                2: int(self.channel_id),
                                3: self.c.uin,
                                4: int(self.c.tiny_id),
                                7: 0,
                            },
                            2: {
                                1: 3840,
                                3: int.from_bytes(os.urandom(4), "big"),
                            },
                        },
                        3: {
                            1: converter.rich,
                        },
                    },
                }
            ),
        )
        rsp = pb.decode(payload)
        if _pick(rsp, 6, 1) != 3:
            raise ApiRejection(
                _pick(rsp, 6, 2) or -70, _pick(rsp, 6, 3) or "频道消息发送失败，可能被风控"
            )
        self.c.logger.info(
            f"succeed to send: [Guild({self.guild.guild_name}),Channel({self.channel_name})] "
            + converter.brief
        )
        self.c.stat.sent_msg_cnt += 1
        return {
            "seq": rsp[4][2][4],
            "rand": rsp[4][2][3],
            "time": rsp[4][2][6],
        }

    async def recallMsg(self, seq: int) -> bool:
        """撤回频道消息"""
        body = pb.encode(
            {
                1: int(self.guild.guild_id),
                2: int(self.channel_id),
                3: int(seq),
            }
        )
        await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0xf5e_1", body)
        return True
