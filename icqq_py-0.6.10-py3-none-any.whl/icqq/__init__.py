"""icqq-py：icqq（Node.js QQ 协议库）的纯 Python 移植。

API 与 icqq 0.6.10 对齐：
    from icqq import Client, segment
    client = Client(123456, {"platform": 2, "sign_api_addr": "http://127.0.0.1:8080/sign"})
    client.on("message", handler)   # handler(client, event)
    await client.login("password")

事件监听器的第一个参数是 client 实例（对应 JS 的 this 绑定）。
"""
from __future__ import annotations

from .client import Client, createClient
from .friend import Friend, User
from .group import Discuss, Group
from .member import Member
from .guild import Guild, GuildRole
from .channel import Channel, ChannelType, NotifyType
from .gfs import Gfs
from .common import OnlineStatus
from .errors import ErrorCode, LoginErrorCode
from .message import (
    Converter,
    ForwardMessage,
    GroupMessage,
    Image,
    Message,
    Parser,
    PrivateMessage,
    DiscussMessage,
    genDmMessageId,
    genGroupMessageId,
    getGroupImageUrl,
    parseDmMessageId,
    parseGroupMessageId,
    parseImageFileParam,
    segment,
)
from .core import ApiRejection, Device, Platform
from .internal import GuildMessageEvent, OcrResult
from . import core

__all__ = [
    "Client",
    "createClient",
    "User",
    "Friend",
    "Discuss",
    "Group",
    "Member",
    "Guild",
    "GuildRole",
    "Channel",
    "ChannelType",
    "NotifyType",
    "Gfs",
    "OnlineStatus",
    "ErrorCode",
    "LoginErrorCode",
    "Message",
    "PrivateMessage",
    "GroupMessage",
    "DiscussMessage",
    "ForwardMessage",
    "genDmMessageId",
    "parseDmMessageId",
    "genGroupMessageId",
    "parseGroupMessageId",
    "segment",
    "Image",
    "parseImageFileParam",
    "Converter",
    "Parser",
    "getGroupImageUrl",
    "ApiRejection",
    "Device",
    "Platform",
    "OcrResult",
    "GuildMessageEvent",
    "core",
]
