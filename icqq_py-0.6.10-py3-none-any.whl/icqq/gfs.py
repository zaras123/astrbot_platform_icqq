"""群文件系统（gfs.js 的移植）。"""
from __future__ import annotations

import asyncio
import os
from urllib.parse import quote

from .core import pb
from .errors import ErrorCode, drop
from .common import fileHash, lock, md5, sha
from .internal import highwayUpload


def checkRsp(rsp) -> None:
    if not rsp.get(1):
        return
    drop(rsp[1], rsp[2])


class _BytesStream:
    """把 bytes 包装为异步可迭代流（Node Readable.from(buf) 的等价物）。"""

    def __init__(self, data: bytes):
        self._data = data

    async def __aiter__(self):
        yield self._data


class _FileStream:
    """把本地文件包装为异步分块可迭代流（fs.createReadStream 的等价物）。"""

    def __init__(self, path: str, high_water_mark: int = 1024 * 256):
        self._path = path
        self._chunk = high_water_mark

    async def __aiter__(self):
        with open(self._path, "rb") as f:
            while True:
                chunk = f.read(self._chunk)
                if not chunk:
                    break
                yield chunk


class Gfs:
    """
    群文件系统
    `fid`表示一个文件或目录的id，`pid`表示它所在目录的id
    根目录的id为"/"
    只能在根目录下创建目录
    删除一个目录会删除下面的全部文件
    """

    @property
    def group_id(self) -> int:
        """`self.gid`的别名"""
        return self.gid

    @property
    def group(self):
        """返回所在群的实例"""
        return self.c.pickGroup(self.gid)

    @property
    def client(self):
        """返回所属的客户端对象"""
        return self.c

    def __init__(self, c, gid: int):
        self.c = c
        self.gid = gid
        lock(self, "c")
        lock(self, "gid")

    async def df(self) -> dict:
        """获取使用空间和文件数"""

        async def _space() -> dict:
            body = pb.encode(
                {
                    4: {1: self.gid, 2: 3},
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d8_3", body)
            rsp = payload[4]
            total = int(rsp[4])
            used = int(rsp[5])
            free = total - used
            return {
                # 总空间
                "total": total,
                # 已使用的空间
                "used": used,
                # 剩余空间
                "free": free,
            }

        async def _count() -> dict:
            body = pb.encode(
                {
                    3: {1: self.gid, 2: 2},
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d8_2", body)
            rsp = payload[3]
            file_count = int(rsp[4])
            max_file_count = int(rsp[6])
            return {
                # 文件数
                "file_count": file_count,
                # 文件数量上限
                "max_file_count": max_file_count,
            }

        a, b = await asyncio.gather(_space(), _count())
        return {**a, **b}

    async def _resolve(self, fid) -> dict:
        body = pb.encode(
            {
                1: {1: self.gid, 2: 0, 4: str(fid)},
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d8_0", body)
        rsp = payload[1]
        checkRsp(rsp)
        return genGfsFileStat(rsp[4])

    async def stat(self, fid: str) -> dict:
        """
        获取文件或目录属性
        :param fid: 目标文件id
        """
        try:
            return await self._resolve(fid)
        except Exception as e:
            files = await self.dir("/")
            for file in files:
                if not file["is_dir"]:
                    break
                if file["fid"] == fid:
                    return file
            raise e

    async def dir(self, pid: str = "/", start: int = 0, limit: int = 100) -> list:
        """
        列出`pid`目录下的所有文件和目录
        :param pid: 目标目录，默认为根目录，即`"/"`
        :param start: @todo 未知参数
        :param limit: 文件/目录上限，超过此上限就停止获取，默认`100`
        :return: 文件和目录列表
        """
        body = pb.encode(
            {
                2: {
                    1: self.gid,
                    2: 1,
                    3: str(pid),
                    5: int(limit) or 100,
                    13: int(start) or 0,
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d8_1", body)
        rsp = payload[2]
        checkRsp(rsp)
        arr = []
        if not rsp[5]:
            return arr
        files = rsp[5] if isinstance(rsp[5], list) else [rsp[5]]
        for file in files:
            if file[3]:
                arr.append(genGfsFileStat(file[3]))
            elif file[2]:
                arr.append(genGfsDirStat(file[2]))
        return arr

    async def ls(self, pid: str = "/", start: int = 0, limit: int = 100) -> list:
        """{@link dir} 的别名"""
        return await self.dir(pid, start, limit)

    async def mkdir(self, name: str) -> dict:
        """创建目录(只能在根目录下创建)"""
        body = pb.encode(
            {
                1: {1: self.gid, 2: 0, 3: "/", 4: str(name)},
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d7_0", body)
        rsp = payload[1]
        checkRsp(rsp)
        return genGfsDirStat(rsp[4])

    async def rm(self, fid) -> None:
        """删除文件/目录(删除目录会删除下面的所有文件)"""
        fid = str(fid)
        if not fid.startswith("/"):
            # 删除文件
            file = await self._resolve(fid)
            body = pb.encode(
                {
                    4: {1: self.gid, 2: 3, 3: file["busid"], 4: file["pid"], 5: file["fid"]},
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_3", body)
            rsp = payload[4]
        else:
            # 删除目录
            body = pb.encode(
                {
                    2: {1: self.gid, 2: 1, 3: str(fid)},
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d7_1", body)
            rsp = payload[2]
        checkRsp(rsp)

    async def rename(self, fid, name: str) -> None:
        """
        重命名文件/目录
        :param fid: 文件id
        :param name: 新命名
        """
        fid = str(fid)
        if not fid.startswith("/"):
            # 重命名文件
            file = await self._resolve(fid)
            body = pb.encode(
                {
                    5: {
                        1: self.gid,
                        2: 4,
                        3: file["busid"],
                        4: file["fid"],
                        5: file["pid"],
                        6: str(name),
                    },
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_4", body)
            rsp = payload[5]
        else:
            # 重命名目录
            body = pb.encode(
                {
                    3: {1: self.gid, 2: 2, 3: str(fid), 4: str(name)},
                }
            )
            payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d7_2", body)
            rsp = payload[3]
        checkRsp(rsp)

    async def mv(self, fid, pid: str) -> None:
        """
        移动文件
        :param fid: 要移动的文件id
        :param pid: 目标目录id
        """
        file = await self._resolve(fid)
        body = pb.encode(
            {
                6: {
                    1: self.gid,
                    2: 5,
                    3: file["busid"],
                    4: file["fid"],
                    5: file["pid"],
                    6: str(pid),
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_5", body)
        rsp = payload[6]
        checkRsp(rsp)

    async def _feed(self, fid, busid) -> dict:
        body = pb.encode(
            {
                5: {
                    1: self.gid,
                    2: 4,
                    3: {
                        1: busid,
                        2: fid,
                        3: int.from_bytes(os.urandom(4), "big", signed=True),
                        5: 1,
                    },
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d9_4", body)
        rsp = payload[5]
        checkRsp(rsp)
        rsp = rsp[4]
        checkRsp(rsp)
        return await self._resolve(rsp[3])

    async def upload(self, file, pid: str = "/", name=None, callback=None) -> dict:
        """
        上传一个文件
        :param file: `str`表示从该本地文件路径上传，`bytes`表示直接上传这段内容
        :param pid: 上传的目标目录id，默认根目录
        :param name: 上传的文件名，`file`为`bytes`时，若留空则自动以md5命名
        :param callback: 监控上传进度的回调函数，拥有一个"百分比进度"的参数
        :return: 上传的文件属性
        """
        if isinstance(file, (bytes, bytearray)):
            file = bytes(file)
            size = len(file)
            md5_ = md5(file)
            sha1 = sha(file)
            name = str(name) if name else "file" + md5_.hex()
        else:
            file = str(file)
            size = os.path.getsize(file)
            md5_, sha1 = await fileHash(file)
            name = str(name) if name else os.path.basename(file)
        body = pb.encode(
            {
                1: {
                    1: self.gid,
                    2: 0,
                    3: 102,
                    4: 5,
                    5: str(pid),
                    6: name,
                    7: "/storage/emulated/0/Pictures/files/s/" + name,
                    8: size,
                    9: sha1,
                    11: md5_,
                    15: 1,
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_0", body)
        rsp = payload[1]
        checkRsp(rsp)
        if not rsp[10]:
            ext = pb.encode(
                {
                    1: 100,
                    2: 1,
                    3: 0,
                    100: {
                        100: {
                            1: rsp[6],
                            100: self.c.uin,
                            200: self.gid,
                            400: self.gid,
                        },
                        200: {
                            100: size,
                            200: md5_,
                            300: sha1,
                            600: rsp[7],
                            700: rsp[9],
                        },
                        300: {
                            100: 2,
                            200: str(self.c.apk.subid),
                            300: 2,
                            400: "9e9c09dc",
                            600: 4,
                        },
                        400: {
                            100: name,
                        },
                        500: {
                            200: {
                                1: {
                                    1: 1,
                                    2: rsp[12],
                                },
                                2: rsp[14],
                            },
                        },
                    },
                }
            )
            if isinstance(file, (bytes, bytearray)):
                stream = _BytesStream(bytes(file))
            else:
                stream = _FileStream(str(file))
            await highwayUpload(
                self.c,
                stream,
                {
                    "cmdid": 71,
                    "callback": callback,
                    "md5": md5_,
                    "size": size,
                    "ext": ext,
                },
            )
        return await self._feed(str(rsp[7]), rsp[6])

    async def forward(self, stat, pid: str = "/", name=None) -> dict:
        """
        将文件转发到当前群
        :param stat: 另一个群中的文件属性
        :param pid: 转发的目标目录，默认根目录
        :param name: 转发后的文件名，默认不变
        :return: 转发的文件在当前群的属性
        """
        body = pb.encode(
            {
                1: {
                    1: self.gid,
                    2: 3,
                    3: 102,
                    4: 5,
                    5: str(pid),
                    6: str(name or stat["name"]),
                    7: "/storage/emulated/0/Pictures/files/s/" + (name or stat["name"]),
                    8: int(stat["size"]),
                    9: bytes.fromhex(stat["sha1"]),
                    11: bytes.fromhex(stat["md5"]),
                    15: 1,
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_0", body)
        rsp = payload[1]
        checkRsp(rsp)
        if not rsp[10]:
            drop(ErrorCode.GroupFileNotExists, "文件不存在，无法被转发")
        return await self._feed(str(rsp[7]), rsp[6])

    async def forwardOfflineFile(self, fid: str, name=None) -> dict:
        """
        将离线(私聊)文件转发到当前群
        :param fid: 私聊文件fid
        :param name: 转发后的文件名，默认不变
        :return: 转发的文件在当前群的属性
        """
        stat = await self.c.pickFriend(self.c.uin).getFileInfo(fid)
        body = pb.encode(
            {
                1: 60100,
                2: 0,
                101: 3,
                102: 103,
                90000: {
                    10: self.gid,
                    30: 102,
                    40: self.c.uin,
                    50: stat["size"],
                    60: str(name or stat["name"]),
                    80: fid,
                },
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0xe37_60100", body)
        rsp = payload[90000]
        if rsp[10] != 0:
            drop(ErrorCode.OfflineFileNotExists, "文件不存在，无法被转发")
        return await self._feed(str(rsp[30]), rsp[50])

    async def download(self, fid: str) -> dict:
        """
        获取文件下载地址
        :param fid: 文件id
        """
        file = await self._resolve(fid)
        body = pb.encode(
            {
                3: {1: self.gid, 2: 2, 3: file["busid"], 4: file["fid"]},
            }
        )
        payload = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0x6d6_2", body)
        rsp = payload[3]
        checkRsp(rsp)
        url = f"http://{rsp[4]}/ftn_handler/{rsp[6].toHex()}/?fname={file['name']}"
        return {
            "name": file["name"],
            # JS: encodeURI(...)
            "url": quote(url, safe=";/?:@&=+$,#-_.!~*'()"),
            "size": file["size"],
            "md5": file["md5"],
            "duration": file["duration"],
            "fid": file["fid"],
        }


def genGfsDirStat(file) -> dict:
    return {
        "fid": str(file[1]),
        "pid": str(file[2]),
        "name": str(file[3]),
        "create_time": file[4],
        "modify_time": file[5],
        "user_id": file[6],
        "file_count": file[8] or 0,
        "is_dir": True,
    }


def genGfsFileStat(file) -> dict:
    stat = {
        "fid": str(file[1]),
        "pid": str(file[16]),
        "name": str(file[2]),
        "busid": file[4],
        "size": file[5],
        "md5": file[12].toHex(),
        "sha1": file[10].toHex(),
        "create_time": file[6],
        "duration": file[7],
        "modify_time": file[8],
        "user_id": file[15],
        "download_times": file[9],
        "is_dir": False,
    }
    if stat["fid"].startswith("/"):
        stat["fid"] = stat["fid"][1:]
    return stat
