"""客户端（client.js 的移植）：一个 QQ 账号对应一个 Client。"""
from __future__ import annotations

import json
import os
import shutil
import struct
from typing import Any, Callable, Dict, List, Optional, Union

from . import common
from .common import OnlineStatus
from .core import ApiRejection, Platform, pb, generateShortDevice
from .core.base_client import BaseClient
from .core.log import get_logger
from .errors import ErrorCode
from .friend import Friend, User
from .group import Discuss, Group
from .guild import Guild
from .internal import bindInternalListeners, getPersonalSign, getStamp, delStamp, getSysMsg, \
    addClass, delClass, renameClass, loadFL, loadSL, loadGPL, loadGL, loadBL, \
    imageOcr, parseFriendRequestFlag, parseGroupRequestFlag, setAvatar, setPersonalSign, setStatus
from .member import Member
from .message import Image, parseDmMessageId, parseGroupMessageId


class _PskeyProxy:
    """对应 JS 的 cookies Proxy：读时拼 cookie 字符串，写无效。"""

    def __init__(self, client):
        self._c = client

    def __getitem__(self, domain: str) -> str:
        cookie = f"uin=o{self._c.uin}; skey={self._c.sig.skey.decode('utf-8', errors='replace')};"
        p = self._c.pskey.get(domain)
        if not p:
            return cookie
        return f"{cookie} p_uin=o{self._c.uin}; p_skey={p.decode('utf-8', errors='replace')};"

    def __setitem__(self, key, value):
        return False


_HEX_CHARS = set("0123456789abcdefABCDEF")


def _js_hex_decode(s: str) -> bytes:
    """复刻 Node `Buffer.from(s, 'hex')` 的宽松行为。

    从开头按两个字符一组解析：遇到第一个无效十六进制字符就停止；
    末尾落单的字符丢弃。因此明文密码（含非 hex 字符）不会抛异常，
    而是解析出 0/部分字节，后续由调用方按长度判断是否走 md5 回退。
    """
    out = bytearray()
    i = 0
    n = len(s)
    while i + 1 < n and s[i] in _HEX_CHARS and s[i + 1] in _HEX_CHARS:
        out.append(int(s[i:i + 2], 16))
        i += 2
    return bytes(out)


class Client(BaseClient):
    """一个客户端"""

    @property
    def bkn(self) -> int:
        """csrf token"""
        bkn = 5381
        for v in self.sig.skey:
            bkn = bkn + (bkn << 5) + v
        bkn &= 2147483647
        return bkn

    @property
    def stat(self):
        """数据统计"""
        self.statistics["msg_cnt_per_min"] = self._calcMsgCntPerMin()
        return self.statistics

    @property
    def log_level(self) -> str:
        return self.config["log_level"]

    @log_level.setter
    def log_level(self, level: str) -> None:
        """修改日志级别"""
        self.logger.level = level
        self.config["log_level"] = level

    def __init__(self, uin=None, conf: Optional[Dict[str, Any]] = None):
        if not isinstance(uin, (int, float)) or isinstance(uin, bool):
            conf = uin
        config: Dict[str, Any] = {
            "log_level": "info",
            "platform": Platform.Android,
            "auto_server": True,
            "ignore_self": True,
            "resend": True,
            "cache_group_member": True,
            "reconn_interval": 5,
            "data_dir": os.path.join(os.getcwd(), "data"),
        }
        if conf:
            config.update(conf)
        dir_ = os.path.abspath(config["data_dir"])
        createDataDir(dir_)
        file = os.path.join(dir_, "device.json")
        device = None
        isNew = False
        try:
            with open(file, "rb") as f:
                device = json.loads(f.read().decode("utf-8"))
            if device is None or "display" not in device:
                raise Exception()
        except Exception:
            device = generateShortDevice()
            isNew = True
            with open(file, "w", encoding="utf-8") as f:
                f.write(json.dumps(device, ensure_ascii=False, indent=2))
        super().__init__(config["platform"], device, config)
        # 得到一个群对象, 通常不会重复创建、调用
        self.pickGroup = lambda gid, strict=False: Group.as_(self, gid, strict)
        # 得到一个好友对象, 通常不会重复创建、调用
        self.pickFriend = lambda uid, strict=False: Friend.as_(self, uid, strict)
        # 得到一个群员对象, 通常不会重复创建、调用
        self.pickMember = lambda gid, uid, strict=False: Member.as_(self, gid, uid, strict)
        # 创建一个用户对象
        self.pickUser = lambda uid: User.as_(self, uid)
        # 创建一个讨论组对象
        self.pickDiscuss = lambda gid: Discuss.as_(self, gid)
        # 创建一个频道对象，通常不会重复创建、调用
        self.pickGuild = lambda guild_id: Guild.as_(self, guild_id)
        self._cache: Dict[int, set] = {}
        # 好友列表
        self.fl: Dict[int, Any] = {}
        # 陌生人列表
        self.sl: Dict[int, Any] = {}
        # 群列表
        self.gl: Dict[int, Any] = {}
        # 群员列表缓存
        self.gml: Dict[int, Any] = {}
        # 我加入的频道列表
        self.guilds: Dict[int, Any] = {}
        # 黑名单列表
        self.blacklist = set()
        # 好友分组
        self.classes: Dict[int, Any] = {}
        # 在线状态
        self.status = OnlineStatus.Offline
        # 昵称
        self.nickname = ""
        # 性别
        self.sex = "unknown"
        # 年龄
        self.age = 0
        self.bid = ""
        # 漫游表情缓存
        self.stamp = set()
        # 相当于频道中的qq号
        self.tiny_id = ""
        # cookies 代理（对应 JS 的 Proxy）
        self.cookies = _PskeyProxy(self)
        self.logger = get_logger("[icqq]")
        if not config.get("sign_api_addr"):
            self.logger.warn("未配置签名API地址，登录/消息发送可能失败")
        self.setSignServer(config.get("sign_api_addr") or "")
        if isinstance(uin, (int, float)) and not isinstance(uin, bool):
            self.uin = int(uin)
        try:
            self.device.mtime = int(os.path.getmtime(file) * 1000)
        except OSError:
            self.device.mtime = int(common.timestamp() * 1000)
        self.logger.level = config["log_level"]
        if isNew:
            self.logger.mark("创建了新的设备文件：" + file)
        self.logger.mark("----------")
        self.logger.mark(f"Package Version: icqq@{self.pkg['version']} (Released on {self.pkg['upday']})")
        self.logger.mark("View Changelogs：https://github.com/icqqjs/icqq/releases")
        self.logger.mark("----------")
        self.dir = dir_
        self.config = config
        bindInternalListeners(self)
        self.on("internal.verbose", _on_verbose)
        self.password_md5: Optional[bytes] = None
        # JS: common.hide(this, "_sync_cookie") —— 初始为 undefined，运行时由 internal 赋值
        self._sync_cookie = None

        n = [0]

        def heartbeat():
            self._calcMsgCntPerMin()
            n[0] += 1
            if n[0] > 10:
                n[0] = 0
                self.setOnlineStatus()

        self.heartbeat = heartbeat
        if not self.config.get("auto_server"):
            self.setRemoteServer("msfwifi.3g.qq.com", 8080)

    # ---- 登录 ----

    async def login(self, uin=None, password=None) -> None:
        if not isinstance(uin, (int, float)) or isinstance(uin, bool):
            password = uin
            uin = self.uin
        if password and len(str(password)) > 0:
            if isinstance(password, str):
                # JS: Buffer.from(password, "hex") —— 宽松解析，明文密码不抛异常，
                # 长度不足 16 时下方回退为 md5(明文)
                md5pass = _js_hex_decode(password)
            else:
                md5pass = bytes(password)
            if len(md5pass) != 16:
                # JS: String(password) —— bytes 会先按 utf8 转字符串再算 md5
                pwd_str = (
                    password
                    if isinstance(password, str)
                    else bytes(password).decode("utf-8", errors="replace")
                )
                md5pass = common.md5(pwd_str.encode("utf-8"))
            self.password_md5 = md5pass
        if await self.switchQQVer():
            self.logger.info(f"[{uin}]获取到签名Api协议版本：{self.statistics['ver']}")
        apk_info = f"{self.apk['display']}_{self.apk['version']}"
        self.logger.info(f"[{uin}]使用协议：{apk_info}")
        self.uin = uin or self.uin
        await self.updateCmdWhiteList()
        self.login_timer = None
        try:
            if not uin:
                raise Exception()
            token_path = os.path.join(self.dir, str(self.uin) + "_token")
            if os.path.exists(token_path + "_bak"):
                os.rename(token_path + "_bak", token_path)
            if not os.path.exists(token_path) or self.token_retry_num <= self.sig.token_retry_count:
                raise Exception()
            with open(token_path, "rb") as f:
                token = f.read()
            await self.tokenLogin(token)
        except Exception:
            if self.password_md5 and uin:
                if self.apk["display"] == "Watch":
                    self.logger.warn("手表协议不支持密码登入，将使用扫码登入")
                    if len(self.sig.qrsig):
                        await self.qrcodeLogin()
                    else:
                        await self.fetchQrcode()
                    return
                await self.passwordLogin(int(uin), self.password_md5)
            else:
                if self.apk["device_type"] == -1:
                    self.logger.error("当前协议不支持扫码登入，请配置密码重新登入")
                    return
                if len(self.sig.qrsig):
                    await self.qrcodeLogin()
                else:
                    await self.fetchQrcode()

    def setOnlineStatus(self, status=None) -> None:
        """设置在线状态"""
        if status is None:
            status = self.status or OnlineStatus.Online
        return setStatus(self, int(status))

    # ---- 个人资料 ----

    async def setNickname(self, nickname: str) -> bool:
        """设置昵称"""
        return await self._setProfile(0x14E22, str(nickname).encode("utf-8"))

    async def setGender(self, gender: int) -> bool:
        """设置性别
        @param gender 0：未知，1：男，2：女
        """
        return await self._setProfile(0x14E29, bytes([gender]))

    async def setBirthday(self, birthday) -> bool:
        """设置生日
        @param birthday `YYYYMMDD`格式的`string`（会过滤非数字字符）或`number`
        """
        import re

        birth = re.sub(r"[^\d]", "", str(birthday))
        buf = bytearray(4)
        buf[0:2] = int(birth[:4]).to_bytes(2, "big")
        buf[2] = int(birth[4:6]) if len(birth) > 4 else 0
        buf[3] = int(birth[6:8]) if len(birth) > 6 else 0
        return await self._setProfile(0x16593, bytes(buf))

    async def setDescription(self, description: str = "") -> bool:
        """设置个人说明"""
        return await self._setProfile(0x14E33, str(description).encode("utf-8"))

    async def setSignature(self, signature: str = "") -> None:
        """设置个性签名"""
        return await setPersonalSign(self, signature)

    async def getSignature(self):
        """获取个性签名"""
        return await getPersonalSign(self)

    async def setAvatar(self, file) -> None:
        """设置头像"""
        return await setAvatar(self, Image({"type": "image", "file": file}))

    # ---- 表情 / 系统消息 / 分组 ----

    def getRoamingStamp(self, no_cache: bool = False):
        """获取漫游表情"""
        return getStamp(self, no_cache)

    def deleteStamp(self, id) -> None:
        """删除表情(支持批量)"""
        return delStamp(self, id)

    def getSystemMsg(self):
        """获取系统消息"""
        return getSysMsg(self)

    def addClass(self, name: str):
        """添加好友分组"""
        return addClass(self, name)

    def deleteClass(self, id: int):
        """删除好友分组"""
        return delClass(self, id)

    def renameClass(self, id: int, name: str):
        """重命名好友分组"""
        return renameClass(self, id, name)

    def reloadFriendList(self):
        """重载好友列表"""
        return loadFL(self)

    def reloadStrangerList(self):
        """重载陌生人列表"""
        return loadSL(self)

    def reloadGuilds(self):
        """重新加载频道列表"""
        return loadGPL(self)

    def reloadGroupList(self):
        """重载群列表"""
        return loadGL(self)

    def reloadBlackList(self):
        """重载黑名单"""
        return loadBL(self)

    def cleanCache(self) -> None:
        """清空缓存文件"""
        dir_ = os.path.join(self.dir, "image")
        shutil.rmtree(dir_, ignore_errors=True)
        os.makedirs(dir_, exist_ok=True)

    # ---- 消息辅助 ----

    def getVideoUrl(self, fid: int, md5) -> None:
        """获取视频下载地址 use {@link Friend.getVideoUrl}"""
        return self.pickFriend(self.uin).getVideoUrl(fid, md5)

    def getForwardMsg(self, resid, fileName, nt=None):
        """获取转发消息 use {@link Friend.getForwardMsg}"""
        return self.pickFriend(self.uin).getForwardMsg(resid, fileName, nt)

    def makeForwardMsg(self, fake, dm: bool = False, nt=None):
        """制作转发消息 use {@link Friend.makeForwardMsg} or {@link Group.makeForwardMsg}"""
        return (self.pickFriend if dm else self.pickGroup)(self.uin).makeForwardMsg(fake, nt)

    def imageOcr(self, file):
        """Ocr图片转文字"""
        return imageOcr(self, Image({"type": "image", "file": file}))

    # ---- @cqhttp 遗留方法 ----

    def getCookies(self, domain: str = "") -> str:
        """use {@link cookies[domain]}"""
        return self.cookies[domain]

    def getCsrfToken(self) -> int:
        """use {@link bkn}"""
        return self.bkn

    def getFriendList(self):
        """use {@link fl}"""
        return self.fl

    def getGroupList(self):
        """use {@link gl}"""
        return self.gl

    def getGuildList(self) -> List[Dict[str, Any]]:
        """use {@link guilds}"""
        return [
            {"guild_id": guild.guild_id, "guild_name": guild.guild_name}
            for guild in self.guilds.values()
        ]

    def getGuildInfo(self, guild_id):
        """use {@link Guild.info}"""
        guild = self.pickGuild(guild_id)
        if not guild:
            return None
        return {"guild_id": guild.guild_id, "guild_name": guild.guild_name}

    def getChannelInfo(self, guild_id, channel_id):
        guild = self.pickGuild(guild_id)
        if not guild:
            return None
        channel = guild.channels.get(channel_id)
        if not channel:
            return None
        return {
            "guild_id": guild.guild_id,
            "channel_id": channel.channel_id,
            "channel_name": channel.channel_name,
            "channel_type": channel.channel_type,
        }

    async def setEssenceMessage(self, message_id: str) -> None:
        """添加群精华消息 use {@link Group.addEssence}"""
        if len(message_id) <= 24:
            raise ApiRejection(ErrorCode.MessageBuilderError, "只能加精群消息")
        info = parseGroupMessageId(message_id)
        await self.pickGroup(info["group_id"]).addEssence(info["seq"], info["rand"])

    async def removeEssenceMessage(self, message_id: str) -> None:
        """移除群精华消息 use {@link Group.removeEssence}"""
        if len(message_id) <= 24:
            raise ApiRejection(ErrorCode.MessageBuilderError, "消息id无效")
        info = parseGroupMessageId(message_id)
        await self.pickGroup(info["group_id"]).removeEssence(info["seq"], info["rand"])

    def getChannelList(self, guild_id) -> List[Dict[str, Any]]:
        """获取子频道列表 use {@link Guild.channels}"""
        guild = self.guilds.get(guild_id)
        if not guild:
            return []
        return [
            {
                "guild_id": guild_id,
                "channel_id": channel.channel_id,
                "channel_name": channel.channel_name,
                "channel_type": channel.channel_type,
            }
            for channel in guild.channels.values()
        ]

    def getGuildMemberList(self, guild_id):
        """获取频道成员列表 use {@link Guild.getMemberList}"""
        guild = self.guilds.get(guild_id)
        if not guild:
            return []
        return guild.getMemberList()

    def getStrangerList(self):
        """use {@link sl}"""
        return self.sl

    async def getStrangerInfo(self, user_id: int):
        """use {@link User.getSimpleInfo}"""
        return await self.pickUser(user_id).getSimpleInfo()

    async def getGroupInfo(self, group_id: int, no_cache: bool = False):
        """use {@link Group.info} or {@link Group.renew}"""
        group = self.pickGroup(group_id)
        if no_cache:
            return await group.renew()
        return group.info or await group.renew()

    async def getGroupMemberList(self, group_id: int, no_cache: bool = False):
        """use {@link Group.getMemberMap}"""
        return await self.pickGroup(group_id).getMemberMap(no_cache)

    async def getGroupMemberInfo(self, group_id: int, user_id: int, no_cache: bool = False):
        """use {@link Member.info} or {@link Member.renew}"""
        members = self.gml.get(group_id)
        if no_cache or not members or user_id not in members:
            return await self.pickMember(group_id, user_id).renew()
        return members.get(user_id)

    async def sendPrivateMsg(self, user_id: int, message, source=None):
        """use {@link Friend.sendMsg}"""
        return await self.pickFriend(user_id).sendMsg(message, source)

    async def sendGuildMsg(self, guild_id, channel_id, message):
        """use {@link Guild.sendMsg}"""
        return await self.pickGuild(guild_id).sendMsg(channel_id, message)

    async def sendGroupMsg(self, group_id: int, message, source=None):
        """use {@link Group.sendMsg}"""
        return await self.pickGroup(group_id).sendMsg(message, source)

    async def sendGroupSign(self, group_id: int):
        """use {@link Group.sign}"""
        return await self.pickGroup(group_id).sign()

    async def sendDiscussMsg(self, discuss_id: int, message, source=None):
        """use {@link Discuss.sendMsg}"""
        return await self.pickDiscuss(discuss_id).sendMsg(message)

    async def sendTempMsg(self, group_id: int, user_id: int, message):
        """use {@link Member.sendMsg}"""
        return await self.pickMember(group_id, user_id).sendMsg(message)

    async def deleteMsg(self, message_id: str) -> None:
        """use {@link User.recallMsg} or {@link Group.recallMsg}"""
        if len(message_id) > 24:
            info = parseGroupMessageId(message_id)
            await self.pickGroup(info["group_id"]).recallMsg(info["seq"], info["rand"], info["pktnum"])
        else:
            info = parseDmMessageId(message_id)
            await self.pickUser(info["user_id"]).recallMsg(info["seq"], info["rand"], info["time"])

    async def reportReaded(self, message_id: str) -> None:
        """use {@link User.markRead} or {@link Group.markRead}"""
        if len(message_id) > 24:
            info = parseGroupMessageId(message_id)
            await self.pickGroup(info["group_id"]).markRead(info["seq"])
        else:
            info = parseDmMessageId(message_id)
            await self.pickUser(info["user_id"]).markRead(info["time"])

    async def getMsg(self, message_id: str):
        """use {@link User.getChatHistory} or {@link Group.getChatHistory}"""
        history = await self.getChatHistory(message_id, 1)
        return history[-1] if history else None

    async def getChatHistory(self, message_id: str, count: int = 20):
        """use {@link User.getChatHistory} or {@link Group.getChatHistory}"""
        if len(message_id) > 24:
            info = parseGroupMessageId(message_id)
            return await self.pickGroup(info["group_id"]).getChatHistory(info["seq"], count)
        else:
            info = parseDmMessageId(message_id)
            return await self.pickUser(info["user_id"]).getChatHistory(info["time"], count)

    async def setGroupAnonymousBan(self, group_id: int, flag, duration: int = 1800):
        """use {@link Group.muteAnony}"""
        return await self.pickGroup(group_id).muteAnony(flag, duration)

    async def setGroupAnonymous(self, group_id: int, enable: bool = True):
        """use {@link Group.allowAnony}"""
        return await self.pickGroup(group_id).allowAnony(enable)

    async def setGroupWholeBan(self, group_id: int, enable: bool = True):
        """use {@link Group.muteAll}"""
        return await self.pickGroup(group_id).muteAll(enable)

    async def setGroupMemberScreenMsg(self, group_id: int, member_id: int, isScreen: bool):
        """设置当前群成员消息屏蔽状态"""
        return await self.pickGroup(group_id).setScreenMemberMsg(member_id, isScreen)

    async def setGroupName(self, group_id: int, name: str):
        """use {@link Group.setName}"""
        return await self.pickGroup(group_id).setName(name)

    async def sendGroupNotice(self, group_id: int, content: str):
        """use {@link Group.announce}"""
        return await self.pickGroup(group_id).announce(content)

    async def setGroupAdmin(self, group_id: int, user_id: int, enable: bool = True):
        """use {@link Group.setAdmin} or {@link Member.setAdmin}"""
        return await self.pickMember(group_id, user_id).setAdmin(enable)

    async def setGroupSpecialTitle(self, group_id: int, user_id: int, special_title: str, duration: int = -1):
        """use {@link Group.setTitle} or {@link Member.setTitle}"""
        return await self.pickMember(group_id, user_id).setTitle(special_title, duration)

    async def setGroupCard(self, group_id: int, user_id: int, card: str):
        """use {@link Group.setCard} or {@link Member.setCard}"""
        return await self.pickMember(group_id, user_id).setCard(card)

    async def setGroupKick(self, group_id: int, user_id: int, reject_add_request: bool = False, message=None):
        """use {@link Group.kickMember} or {@link Member.kick}"""
        return await self.pickMember(group_id, user_id).kick(message, reject_add_request)

    async def setGroupBan(self, group_id: int, user_id: int, duration: int = 1800):
        """use {@link Group.muteMember} or {@link Member.mute}"""
        return await self.pickMember(group_id, user_id).mute(duration)

    async def setGroupLeave(self, group_id: int):
        """use {@link Group.quit}"""
        return await self.pickGroup(group_id).quit()

    async def sendGroupPoke(self, group_id: int, user_id: int):
        """use {@link Group.pokeMember} or {@link Member.poke}"""
        return await self.pickMember(group_id, user_id).poke()

    async def addFriend(self, group_id: int, user_id: int, comment: str = ""):
        """use {@link Member.addFriend}"""
        return await self.pickMember(group_id, user_id).addFriend(comment)

    async def deleteFriend(self, user_id: int, block: bool = True):
        """use {@link Friend.delete}"""
        return await self.pickFriend(user_id).delete(block)

    async def inviteFriend(self, group_id: int, user_id: int):
        """use {@link Group.invite}"""
        return await self.pickGroup(group_id).invite(user_id)

    async def sendLike(self, user_id: int, times: int = 1):
        """use {@link Friend.thumbUp}"""
        return await self.pickFriend(user_id).thumbUp(times)

    async def setPortrait(self, file) -> None:
        """use {@link setAvatar}"""
        return await self.setAvatar(file)

    async def setGroupPortrait(self, group_id: int, file) -> None:
        """use {@link Group.setAvatar}"""
        return await self.pickGroup(group_id).setAvatar(file)

    def acquireGfs(self, group_id: int):
        """use {@link Group.fs}"""
        return self.pickGroup(group_id).fs

    async def setFriendAddRequest(self, flag, approve: bool = True, remark: str = "", block: bool = False):
        """use {@link User.setFriendReq} or {@link User.addFriendBack}"""
        info = parseFriendRequestFlag(flag)
        user = self.pickUser(info["user_id"])
        if info["single"]:
            return await user.addFriendBack(info["seq"], remark)
        return await user.setFriendReq(info["seq"], approve, remark, block)

    async def setGroupAddRequest(self, flag, approve: bool = True, reason: str = "", block: bool = False):
        """use {@link User.setGroupInvite} or {@link User.setGroupReq}"""
        info = parseGroupRequestFlag(flag)
        user = self.pickUser(info["user_id"])
        if info["invite"]:
            return await user.setGroupInvite(info["group_id"], info["seq"], approve, block)
        return await user.setGroupReq(info["group_id"], info["seq"], approve, reason, block)

    # ---- 事件过滤 ----

    def group(self, *group_ids: int) -> Callable:
        """监听群邀请/消息事件
        @param group_ids 监听群的群号
        @returns 事件处理
        """

        def decorator(listener):
            return self.trap(
                lambda eventName, event: (event or {}).get("group_id") in group_ids,
                listener,
            )

        return decorator

    def user(self, *user_ids: int) -> Callable:
        """监听用户私聊/群聊事件
        @param user_ids 监听的用户账号
        @returns 事件处理
        """

        def decorator(listener):
            return self.trap(
                lambda eventName, event: (event or {}).get("user_id") in user_ids,
                listener,
            )

        return decorator

    def em(self, name: str = "", data: Optional[Any] = None) -> None:
        """emit an event"""
        if data is None:
            data = {}
        if isinstance(data, dict):
            data["self_id"] = self.uin
        else:
            try:
                data.self_id = self.uin
            except AttributeError:
                pass
        while True:
            self.emit(name, data)
            i = name.rfind(".")
            if i == -1:
                break
            name = name[:i]

    def _msgExists(self, from_: int, type: int, seq: int, time: int) -> bool:
        if common.timestamp() + self.sig.time_diff - time >= 60 or time < self.statistics["start_time"]:
            return True
        id_ = f"{from_}-{type}-{seq}"
        s = self._cache.get(time)
        if not s:
            self._cache[time] = {id_}
            return False
        else:
            if id_ in s:
                return True
            else:
                s.add(id_)
            return False

    def _calcMsgCntPerMin(self) -> int:
        cnt = 0
        for time_, s in list(self._cache.items()):
            if common.timestamp() - time_ >= 60:
                self._cache.pop(time_, None)
            else:
                cnt += len(s)
        return cnt

    async def _setProfile(self, k: int, v: bytes) -> bool:
        buf = bytearray(11 + len(v))
        buf[0:4] = (self.uin & 0xFFFFFFFF).to_bytes(4, "big")
        buf[4] = 0
        buf[5:9] = struct.pack(">i", k & 0xFFFFFFFF)
        buf[9:11] = len(v).to_bytes(2, "big")
        buf[11:] = v
        payload = await self.sendOidb("OidbSvc.0x4ff_9", bytes(buf))
        obj = pb.decode(payload)
        return obj.get(3) == 0 or obj.get(3) == 34

    # ---- @deprecated ----

    def sliderLogin(self, ticket: str):
        """@deprecated use {@link submitSlider}"""
        return self.submitSlider(ticket)

    def sendSMSCode(self):
        """@deprecated use {@link sendSmsCode}"""
        return self.sendSmsCode()

    def submitSMSCode(self, code: str):
        """@deprecated use {@link submitSmsCode}"""
        return self.submitSmsCode(code)

    @property
    def online_status(self) -> OnlineStatus:
        """@deprecated use {@link status}"""
        return self.status


def createDataDir(dir_: str) -> None:
    if not os.path.exists(dir_):
        os.makedirs(dir_, mode=0o755, exist_ok=True)
    img_path = os.path.join(dir_, "image")
    if not os.path.exists(img_path):
        os.makedirs(img_path, exist_ok=True)


def createClient(config) -> Client:
    """创建一个客户端 (=new Client)"""
    return Client(config)


def _on_verbose(client: Client, verbose, level, c=None) -> None:
    """internal.verbose 事件的日志监听器（client.js 中的箭头函数）。"""
    list_ = ["fatal", "mark", "error", "warn", "info", "debug", "trace"]
    try:
        getattr(client.logger, list_[int(level)])(verbose)
    except (IndexError, ValueError):
        client.logger.info(verbose)
