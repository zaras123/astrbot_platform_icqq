"""图片元素与文件参数（image.js 的移植）。

依赖替换说明：
- Node pngjs 的 PNG 编解码 → Pillow（from PIL import Image as PILImage）
- Node stream 下载 → aiohttp 直接 await 拿 bytes
- JS 的 fs 同步读写 → open()/os 模块
"""
from __future__ import annotations

import base64
import inspect
import io
import os
import re

from PIL import Image as PILImage

from ..common import IS_WIN, MAX_UPLOAD_SIZE, TMP_DIR, uuid
from ..core.constants import md5
from ..core.http import http_get

TYPE = {
    "jpg": 1000,
    "png": 1001,
    "webp": 1002,
    "bmp": 1005,
    "gif": 2000,
    "face": 4,
}
EXT = {
    3: "png",
    4: "face",
    1000: "jpg",
    1001: "png",
    1002: "webp",
    1003: "jpg",
    1005: "bmp",
    2000: "gif",
    2001: "png",
}


def buildImageFileParam(md5, size, width, height, type):
    """构造图片file"""
    size = size or 0
    width = width or 0
    height = height or 0
    ext = EXT.get(type) or "jpg"
    return f"{md5}{size}-{width}-{height}.{ext}"


def _number(s):
    """JS Number() 的近似等价物；无法解析返回 None（JS 为 NaN，在 `|| 0` 处行为一致）。"""
    if isinstance(s, (int, float)):
        return s
    if s is None:
        return None
    if isinstance(s, (bytes, bytearray)):
        s = bytes(s).decode("utf-8", errors="replace")
    try:
        return int(str(s))
    except (ValueError, TypeError):
        try:
            return float(str(s))
        except (ValueError, TypeError):
            return None


def _parse_int(s):
    """JS parseInt 的近似等价物（截取前缀整数）。"""
    if s is None:
        return None
    m = re.match(r"\s*[+-]?\d+", str(s))
    return int(m.group(0)) if m else None


def parseImageFileParam(file):
    """从图片的file中解析出图片属性参数"""
    sp = file.split("-")
    md5 = sp[0][:32]
    size = _number(sp[0][32:]) or 0
    width = _number(sp[1] if len(sp) > 1 else None) or 0
    height = _parse_int(sp[2] if len(sp) > 2 else None) or 0
    sp = file.split(".")
    ext = sp[1] if len(sp) > 1 else "jpg"
    return {"md5": md5, "size": size, "width": width, "height": height, "ext": ext}


def _probe(buf):
    """probe-image-size 的 Pillow 等价实现：返回 {width, height, type}。"""
    img = PILImage.open(io.BytesIO(buf))
    fmt = (img.format or "").lower()
    type_map = {"jpeg": "jpg", "jpg": "jpg", "png": "png", "gif": "gif", "bmp": "bmp", "webp": "webp"}
    return {"width": img.width, "height": img.height, "type": type_map.get(fmt, fmt)}


async def _read_stream(readable) -> bytes:
    """把可读流（同步文件对象或异步可读流）读成 bytes。"""
    if hasattr(readable, "read"):
        result = readable.read()
        if inspect.isawaitable(result):
            return await result
        return bytes(result)
    chunks = []
    async for chunk in readable:
        chunks.append(chunk)
    return b"".join(chunks)


def _b64decode(s):
    """JS Buffer.from(str, "base64") 对缺失填充宽容，这里补足 '='。"""
    return base64.b64decode(s + "=" * (-len(s) % 4))


class Image:
    def __init__(self, elem, dm=False, cachedir=None):
        """@param elem 图片元素 dict（如 segment.image(file) 的返回）
        @param dm 是否私聊图片
        @param cachedir 网络图片缓存目录
        """
        self.dm = dm
        self.cachedir = cachedir
        # 最终用于发送的对象
        self.proto = {}
        # 图片属性
        self.md5 = os.urandom(16)
        self.size = 0xFFFF
        self.width = 320
        self.height = 240
        self.type = 1000
        file = elem.get("file")
        cache = elem.get("cache")
        timeout = elem.get("timeout")
        headers = elem.get("headers")
        self.asface = elem.get("asface")
        self.origin = elem.get("origin")
        self.summary = elem.get("summary")
        self.cachefile = None
        self.tmpfile = None
        self.setProto()
        if isinstance(file, (bytes, bytearray)):
            self.task = self.fromProbeSync(bytes(file))
        elif hasattr(file, "read"):
            # 可读的图片数据流
            self.task = self.fromReadable(file)
        elif not isinstance(file, str):
            raise Exception(f"bad file param: {file}")
        elif file.startswith("base64://"):
            self.task = self.fromProbeSync(_b64decode(file[9:]))
        elif file.startswith("http://") or file.startswith("https://"):
            self.task = self.fromWeb(file, cache, headers, timeout)
        else:
            self.task = self.fromLocal(file)

    @property
    def fid(self):
        return getattr(self, "_fid", None)

    @fid.setter
    def fid(self, val):
        """从服务端拿到fid后必须设置此值，否则图裂"""
        self._fid = val
        if self.dm:
            self.proto[3] = val
            self.proto[10] = val
        else:
            self.proto[7] = val

    def setProperties(self, dimensions):
        if not dimensions:
            raise Exception("bad image file")
        self.width = dimensions["width"]
        self.height = dimensions["height"]
        self.type = TYPE.get(dimensions["type"]) or 1000

    def parseFileParam(self, file):
        info = parseImageFileParam(file)
        hash = bytes.fromhex(info["md5"])
        if len(hash) != 16:
            raise Exception(f"bad file param: {file}")
        self.md5 = hash
        if info["size"] > 0:
            self.size = info["size"]
        self.width = info["width"]
        self.height = info["height"]
        t = TYPE.get(info["ext"])
        if t:
            self.type = t
        self.setProto()

    async def fromProbeSync(self, buf):
        dimensions = _probe(buf)
        self.setProperties(dimensions)
        self.md5 = md5(buf)
        self.size = len(buf)
        self.readable = io.BytesIO(buf)
        self.setProto()

    async def fromReadable(self, readable, timeout=60):
        try:
            # JS 原版用 pipe(DownloadTransform) 限量 + probe + md5Stream 三路流水写临时文件；
            # Python 直接读入内存，DownloadTransform 的 30MB 限制在此等价实现。
            # timeout 与 JS 一致表示流超时(秒)，HTTP 下载路径已按此超时。
            timeout = timeout if timeout and timeout > 0 else 60
            self.tmpfile = os.path.join(TMP_DIR, uuid())
            buf = await _read_stream(readable)
            if len(buf) > MAX_UPLOAD_SIZE:
                raise Exception("downloading over 30MB is refused")
            dimensions = _probe(buf)
            self.setProperties(dimensions)
            self.md5 = md5(buf)
            with open(self.tmpfile, "wb") as f:
                f.write(buf)
            self.size = os.stat(self.tmpfile).st_size
            self.readable = open(self.tmpfile, "rb")
            self.setProto()
        except Exception as e:
            self.deleteTmpFile()
            raise e

    async def fromWeb(self, url, cache, headers, timeout):
        if self.cachedir:
            self.cachefile = os.path.join(self.cachedir, md5(url.encode()).hex())
            if cache:
                try:
                    with open(self.cachefile, encoding="utf-8") as f:
                        self.parseFileParam(f.read())
                    return
                except Exception:
                    pass
        t = timeout if timeout and timeout > 0 else 60
        buf = await http_get(url, headers=headers, timeout=float(t))
        await self.fromReadable(io.BytesIO(buf), timeout)
        if self.cachefile:
            with open(self.cachefile, "w", encoding="utf-8") as f:
                f.write(buildImageFileParam(self.md5.hex(), self.size, self.width, self.height, self.type))

    async def fromLocal(self, file):
        try:
            # 收到的图片
            self.parseFileParam(file)
        except Exception:
            # 本地图片
            if file.startswith("file://"):
                file = file[7:].replace("%20", " ")
            if IS_WIN and file.startswith("/"):
                file = file[1:]
            stat = os.stat(file)
            if stat.st_size <= 0 or stat.st_size > MAX_UPLOAD_SIZE:
                raise Exception(f"bad file size: {stat.st_size}")
            with open(file, "rb") as f:
                buf = f.read()
            dimensions = _probe(buf)
            self.setProperties(dimensions)
            self.md5 = md5(buf)
            self.size = stat.st_size
            self.readable = open(file, "rb")
            self.setProto()

    def setProto(self):
        if self.dm:
            proto = {
                1: self.md5.hex(),
                2: self.size,
                3: getattr(self, "_fid", None),
                5: self.type,
                7: self.md5,
                8: self.height,
                9: self.width,
                10: getattr(self, "_fid", None),
                13: 1 if self.origin else 0,
                16: 5 if self.type == 4 else 0,
                24: 0,
                25: 0,
                29: {
                    1: 1 if self.asface else 0,
                },
            }
        else:
            proto = {
                2: self.md5.hex() + (".gif" if self.asface else ".jpg"),
                7: getattr(self, "_fid", None),
                8: 0,
                9: 0,
                10: 66,
                12: 1,
                13: self.md5,
                # 17: 3,
                20: self.type,
                22: self.width,
                23: self.height,
                24: 200,
                25: self.size,
                26: 1 if self.origin else 0,
                29: 0,
                30: 0,
                34: {
                    1: 1 if self.asface else 0,
                },
            }
        if self.summary:
            proto[29 if self.dm else 34][8 if self.dm else 9] = self.summary
        self.proto.update(proto)

    def deleteCacheFile(self):
        """服务端图片失效时建议调用此函数"""
        if self.cachefile:
            try:
                os.unlink(self.cachefile)
            except OSError:
                pass

    def deleteTmpFile(self):
        """图片上传完成后建议调用此函数(文件存在系统临时目录中)"""
        if self.tmpfile:
            try:
                os.unlink(self.tmpfile)
            except OSError:
                pass
        readable = getattr(self, "readable", None)
        if readable is not None:
            try:
                readable.close()
            except Exception:
                pass
