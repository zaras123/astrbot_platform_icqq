"""将消息元素转换为protobuf（converter.js 的移植）。"""
from __future__ import annotations

import base64
import json as _json
import re
import zlib
from random import randint

from ..core.buffer import pack_u16, pack_u32
from ..core.pb import encode
from .elements import ChainElemTypes
from .face import FACE_OLD_BUF, facemap
from .image import Image
from .message import parseDmMessageId, parseGroupMessageId, rand2uuid
from .music import makeMusicJson

# JS 字符串按 UTF-16 码元(16位)处理；Python 中把文本拆成码元整数列表来精确复刻分片逻辑
EMOJI_NOT_ENDING = (0xD835, 0xD83C, 0xD83D, 0xD83E, 0x200D)
EMOJI_NOT_STARTING = (0xFE0F, 0x200D, 0x20E3)

PB_RESERVER = encode({
    37: {
        17: 0,
        19: {
            15: 0,
            31: 0,
            41: 0,
        },
    }
})
AT_BUF = bytes([0, 1, 0, 0, 0])
BUF1 = bytes([1])
BUF2 = bytes(2)


def random(a, b):
    """JS 原版局部函数：Math.floor(Math.random() * (b - a) + a)"""
    return randint(a, b - 1)


def _utf16_len(text: str) -> int:
    """JS 字符串 .length（UTF-16 码元数）。"""
    return len(text.encode("utf-16-le")) // 2


def _utf16_units(text: str) -> list:
    """把 str 拆成 UTF-16 码元列表，复刻 JS 的按码元切片。"""
    data = text.encode("utf-16-le")
    return [data[i] | (data[i + 1] << 8) for i in range(0, len(data), 2)]


def _units_to_text(units) -> str:
    data = bytearray()
    for u in units:
        data.append(u & 0xFF)
        data.append((u >> 8) & 0xFF)
    return bytes(data).decode("utf-16-le")


def _parse_int(s):
    """JS parseInt 的近似等价物（截取前缀整数；失败返回 NaN 与 JS 一致）。"""
    m = re.match(r"\s*[+-]?\d+", str(s or ""))
    if not m:
        return float("nan")
    return int(m.group(0))


def _b64decode(s):
    """JS Buffer.from(str, "base64") 对缺失填充宽容，这里补足 '='。"""
    return base64.b64decode(s + "=" * (-len(s) % 4))


def _json_stringify(obj):
    """JS JSON.stringify 的等价物：值为 undefined(None) 的键会被丢弃；
    无多余空格（separators），非 ASCII 原样输出（ensure_ascii=False）。"""

    def _drop(v):
        if isinstance(v, dict):
            return {k: _drop(x) for k, x in v.items() if x is not None}
        if isinstance(v, list):
            return [_drop(x) for x in v]
        return v

    return _json.dumps(_drop(obj), separators=(",", ":"), ensure_ascii=False)


class Converter:
    """将消息元素转换为protobuf"""

    def __init__(self, content, ext=None):
        self.ext = ext or {}
        self.is_chain = True
        self.elems = []
        # 用于最终发送
        self.rich = {2: self.elems, 4: None}
        # 长度(字符)
        self.length = 0
        # 包含的图片(可能需要上传)
        self.imgs = []
        # 预览文字
        self.brief = ""
        # 分片后
        self.fragments = []
        _content = list(content) if isinstance(content, (list, tuple)) else [content]
        for elem in _content:
            if not (isinstance(elem, str) or (isinstance(elem, dict) and elem.get("type") in ChainElemTypes)):
                _content = [elem]
                break
        for elem in _content:
            self._convert(elem)
        if not len(self.elems) and not self.rich[4]:
            raise Exception("empty message")
        self.elems.append(PB_RESERVER)

    def _convert(self, elem):
        if isinstance(elem, str):
            self._text(elem)
        else:
            t = elem.get("type")
            if t is not None and hasattr(self, t):
                getattr(self, t)(elem)

    def _text(self, text, attr6=None):
        text = str(text)
        if not len(text):
            return
        self.elems.append({
            1: {
                1: text,
                3: attr6,
            }
        })
        self.length += _utf16_len(text)
        self.brief += text

    def text(self, elem):
        self._text(elem["text"])

    def at(self, elem):
        qq = elem.get("qq")
        id = elem.get("id")
        text = elem.get("text")
        dummy = elem.get("dummy")
        if qq == 0 and id:
            # 频道中的AT
            self.elems.append({
                1: {
                    1: text or ("@全体成员" if id == "all" else ("@" + id)),
                    12: {
                        3: 2,
                        5: 0 if id == "all" else int(id),
                    },
                }
            })
            return
        if qq == "all":
            q = 0
            flag = 1
            display = "全体成员"
        else:
            q = int(qq)
            flag = 0
            display = text or str(qq)
            if not text:
                member = (self.ext.get("mlist") or {}).get(q)
                if member:
                    display = member.get("card") or member.get("nickname") or display
        display = "@" + display
        if dummy:
            return self._text(display)
        buf = bytearray(6)
        buf[0] = _utf16_len(display) & 0xFF
        buf[1] = flag
        buf[2:6] = pack_u32(q)
        attr6 = AT_BUF + bytes(buf) + BUF2
        self._text(display, attr6)

    def face(self, elem):
        id = elem.get("id")
        text = elem.get("text")
        qlottie = elem.get("qlottie")
        if id is None or isinstance(id, bool):
            raise Exception("wrong face id: NaN")
        id = int(id)
        if id < 0 or id > 0xFFFF:
            raise Exception("wrong face id: " + str(id))
        if qlottie:
            if facemap.get(id):
                text = facemap[id]
            elif not text:
                text = "/" + str(id)
            if not text.startswith("/"):
                text = "/" + text
            self.elems.append([
                {
                    53: {
                        1: 37,
                        2: {
                            1: "1",
                            2: qlottie,
                            3: id,
                            4: 1,
                            5: 1,
                            6: "",
                            7: text,
                            8: "",
                            9: 1,
                        },
                        3: 1,
                    }
                },
                {
                    1: {
                        1: text,
                        12: {
                            1: "[" + text.replace("/", "", 1) + "]请使用最新版手机QQ体验新功能",
                        },
                    }
                },
                {
                    37: {
                        17: 21908,
                        19: {
                            15: 65536,
                            31: 0,
                            41: 0,
                        },
                    }
                },
            ])
            return
        if id <= 0xFF:
            old = pack_u16(0x1441 + id)
            self.elems.append({
                2: {
                    1: id,
                    2: old,
                    11: FACE_OLD_BUF,
                }
            })
        else:
            if facemap.get(id):
                text = facemap[id]
            elif not text:
                text = "/" + str(id)
            self.elems.append({
                53: {
                    1: 33,
                    2: {
                        1: id,
                        2: text,
                        3: text,
                    },
                    3: 1,
                }
            })
        self.brief += "[表情]"

    def sface(self, elem):
        id = elem.get("id")
        text = elem.get("text")
        if not text:
            text = str(id)
        text = "[" + text + "]"
        # JS 原版此处使用字符串键（"53"等），encode() 内部 int(tag) 语义等价
        self.elems.append({
            "53": {
                "1": 37,
                "2": {
                    "1": "1",
                    "2": "1",
                    "3": id,
                    "4": 1,
                    "5": 1,
                    "6": {},
                    "7": text,
                    "9": 1,
                },
                "3": 1,
            }
        })
        self._text(text)

    def bface(self, elem, magic=None):
        file = elem.get("file")
        text = elem.get("text")
        if not text:
            text = "原创表情"
        text = "[" + str(text)[:5] + "]"
        o = {
            1: text,
            2: 6,
            3: 1,
            4: bytes.fromhex(file[:32]),
            5: _parse_int(file[64:]),
            6: 3,
            7: bytes.fromhex(file[32:64]),
            9: 0,
            10: 200,
            11: 200,
            12: magic,
        }
        self.elems.append({6: o})
        self._text(text)

    def dice(self, elem):
        id = elem.get("id")
        id = (id - 1) if (id is not None and id >= 1 and id <= 6) else random(0, 6)
        return self.bface({
            "type": "bface",
            "file": "4823d3adb15df08014ce5d6796b76ee13430396532613639623136393138663911464",
            "text": "骰子",
        }, bytes([0x72, 0x73, 0x63, 0x54, 0x79, 0x70, 0x65, 0x3F, 0x31, 0x3B, 0x76, 0x61, 0x6C, 0x75, 0x65, 0x3D, 0x30 + id]))

    def rps(self, elem):
        id = elem.get("id")
        id = (id - 1) if (id is not None and id >= 1 and id <= 3) else random(0, 3)
        return self.bface({
            "type": "bface",
            "file": "83c8a293ae65ca140f348120a77448ee3764653339666562636634356536646211415",
            "text": "猜拳",
        }, bytes([0x72, 0x73, 0x63, 0x54, 0x79, 0x70, 0x65, 0x3F, 0x31, 0x3B, 0x76, 0x61, 0x6C, 0x75, 0x65, 0x3D, 0x30 + id]))

    def image(self, elem):
        img = Image(elem, self.ext.get("dm"), self.ext.get("cachedir"))
        self.imgs.append(img)
        self.elems.append({4: img.proto} if self.ext.get("dm") else {8: img.proto})
        self.brief += "[图片]"

    def flash(self, elem):
        img = Image(elem, self.ext.get("dm"), self.ext.get("cachedir"))
        self.imgs.append(img)
        self.elems.append({
            53: {
                1: 3,
                2: {2: img.proto} if self.ext.get("dm") else {1: img.proto},
                3: 0,
            }
        })
        self.elems.append({
            1: {
                1: "[闪照]请使用新版手机QQ查看闪照。",
            }
        })
        self.brief += "[闪照]"

    def record(self, elem):
        file = str(elem["file"])
        if not file.startswith("protobuf://"):
            raise Exception("非法的语音元素: " + file)
        buf = _b64decode(file.replace("protobuf://", "", 1))
        self.rich[4] = buf
        self.brief += "[语音]"
        self.is_chain = False

    def video(self, elem):
        file = str(elem["file"])
        if not file.startswith("protobuf://"):
            raise Exception("非法的视频元素: " + file)
        buf = _b64decode(file.replace("protobuf://", "", 1))
        self.elems.append({19: buf})
        self.elems.append({
            1: {
                1: "你的QQ暂不支持查看视频短片，请期待后续版本。",
            }
        })
        self.brief += "[视频]"
        self.is_chain = False

    def location(self, elem):
        address = elem.get("address")
        lat = elem.get("lat")
        lng = elem.get("lng")
        if not address or not lat or not lng:
            raise Exception("location share need 'address', 'lat' and 'lng'")
        data = {
            "config": {"forward": True, "type": "card", "autosize": True},
            "prompt": "[应用]地图",
            "from": 1,
            "app": "com.tencent.map",
            "ver": "1.0.3.5",
            "view": "LocationShare",
            "meta": {
                "Location.Search": {
                    "from": "plusPanel",
                    "id": elem.get("id") or "",
                    "lat": lat,
                    "lng": lng,
                    "address": address,
                    "name": elem.get("name") or "位置分享",
                }
            },
            "desc": "地图",
        }
        self.json({"type": "json", "data": data})

    def node(self, elem):
        raise Exception("这个不能直接发")

    def music(self, elem):
        if any(not elem.get(key) for key in ["title", "singer", "jumpUrl", "musicUrl", "preview"]):
            return self.json({
                "type": "json",
                "data": makeMusicJson(elem),
            })

    def share(self, elem):
        raise Exception("这个不能直接发")

    def json(self, elem):
        if isinstance(elem["data"], str):
            raw = elem["data"]
        else:
            raw = _json_stringify(elem["data"])
        self.elems.append({
            51: {
                1: BUF1 + zlib.compress(raw.encode("utf-8")),
            }
        })
        self.brief += "[json消息]"
        self.is_chain = False

    def xml(self, elem):
        id = elem.get("id")
        self.elems.append({
            12: {
                1: BUF1 + zlib.compress(elem["data"].encode("utf-8")),
                2: id if (id is not None and id > 0) else 60,
            }
        })
        self.brief += "[xml消息]"
        self.is_chain = False

    def poke(self, elem):
        id = elem.get("id")
        if not (id is not None and id >= 0 and id <= 6):
            raise Exception("wrong poke id: " + str(id))
        self.elems.append({
            53: {
                1: 2,
                2: {
                    3: 0,
                    7: 0,
                    10: 0,
                },
                3: id,
            }
        })
        self.brief += "[戳一戳]"
        self.is_chain = False

    def markdown(self, elem):
        content = elem.get("content")
        self.elems.append({
            53: {
                1: 45,
                2: {
                    1: content,
                },
                3: 1,
            }
        })
        self.brief += "[markdown消息]"

    def button(self, elem):
        content = elem.get("content")
        _content = {
            1: {
                1: [
                    {
                        1: [
                            {
                                1: button.get("id"),
                                2: {
                                    1: button["render_data"]["label"],
                                    2: button["render_data"]["visited_label"],
                                    3: button["render_data"]["style"],
                                },
                                3: {
                                    1: button["action"]["type"],
                                    2: {
                                        1: button["action"]["permission"]["type"],
                                        2: button["action"]["permission"]["specify_role_ids"],
                                        3: button["action"]["permission"]["specify_user_ids"],
                                    },
                                    4: button["action"]["unsupport_tips"],
                                    5: button["action"]["data"],
                                    7: 1 if button["action"]["reply"] else 0,
                                    8: 1 if button["action"]["enter"] else 0,
                                },
                            }
                            for button in row["buttons"]
                        ]
                    }
                    for row in content["rows"]
                ],
                2: content["appid"],
            }
        }
        self.elems.append({
            53: {
                1: 46,
                2: _content,
                3: 1,
            }
        })
        self.brief += "[button消息]"

    def mirai(self, elem):
        data = elem.get("data")
        self.elems.append({
            31: {
                2: str(data),
                3: 103904510,
            }
        })
        self.brief += "undefined" if data is None else data

    def file(self, elem):
        raise Exception("暂不支持发送或转发file元素，请调用文件相关API完成该操作")

    def reply(self, elem):
        id = elem.get("id")
        if len(id) > 24:
            self.quote({**parseGroupMessageId(id), "message": elem.get("text") or "[消息]"})
        else:
            self.quote({**parseDmMessageId(id), "message": elem.get("text") or "[消息]"})

    def toFragments(self):
        """转换为分片消息"""
        self.elems.pop()
        frag = []
        for proto in self.elems:
            p1 = proto.get(1)
            if p1 is not None and not p1.get(3):
                self._pushFragment(frag)
                frag = []
                self._divideText(p1[1])
            else:
                frag.append(proto)
        if not len(frag) and len(self.fragments) == 1:
            frag.append({
                1: {
                    1: "",
                }
            })
        self._pushFragment(frag)
        return self.fragments

    def _divideText(self, text):
        units = _utf16_units(text)
        n = 0
        while n < len(units):
            m = n + 80
            chunk = units[n:m]
            n = m
            if len(units) > n:
                # emoji不能从中间分割，否则客户端会乱码
                while chunk and chunk[-1] in EMOJI_NOT_ENDING and n < len(units):
                    chunk.append(units[n])
                    n += 1
                while n < len(units) and units[n] in EMOJI_NOT_STARTING:
                    chunk.append(units[n])
                    n += 1
                    while chunk and chunk[-1] in EMOJI_NOT_ENDING and n < len(units):
                        chunk.append(units[n])
                        n += 1
            self._pushFragment([{
                1: {
                    1: _units_to_text(chunk),
                }
            }])

    def _pushFragment(self, proto):
        if len(proto) > 0:
            proto.append(PB_RESERVER)
            self.fragments.append(encode({2: proto}))

    def anonymize(self, anon):
        """匿名化"""
        self.elems.insert(0, {
            21: {
                1: 2,
                3: anon["name"],
                4: anon["id2"],
                5: anon["expire_time"],
                6: anon["id"],
            }
        })

    def quote(self, source):
        """引用回复"""
        elems = Converter(source.get("message") or "", self.ext).elems
        tmp = self.brief
        if not self.ext.get("dm"):
            self.at({"type": "at", "qq": source["user_id"]})
            self.elems.insert(0, self.elems.pop())
        self.elems.insert(0, {
            45: {
                1: [source["seq"]],
                2: source["user_id"],
                3: source["time"],
                4: 1,
                5: elems,
                6: 0,
                8: {
                    3: rand2uuid(source.get("rand") or 0),
                },
            }
        })
        self.brief = f"[回复{self.brief.replace(tmp, '', 1)}]" + tmp
