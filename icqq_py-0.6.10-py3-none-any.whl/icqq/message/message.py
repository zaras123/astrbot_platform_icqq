"""消息类型（message.js 的移植）。"""
from __future__ import annotations

import base64
import re

from ..common import parseFunString
from ..core.buffer import pack_i32, pack_u32, u32
from ..core.constants import lock
from ..core.pb import decode as pb_decode
from .parser import parse


def rand2uuid(rand):
    return (16777216 << 32) | int(rand)


def uuid2rand(uuid):
    return int(uuid) & 0xFFFFFFFF


def _b64decode(s):
    """JS Buffer.from(str, "base64") 对缺失填充宽容，这里补足 '='。"""
    return base64.b64decode(s + "=" * (-len(s) % 4))


def genDmMessageId(uid, seq, rand, time, flag=0):
    """@cqhttp 生成私聊消息id"""
    buf = bytearray(17)
    buf[0:4] = pack_u32(uid)
    buf[4:8] = pack_i32(seq & 0xFFFFFFFF)
    buf[8:12] = pack_i32(rand & 0xFFFFFFFF)
    buf[12:16] = pack_u32(time)
    buf[16] = flag  # 接收为0 发送为1
    return base64.b64encode(bytes(buf)).decode()


def parseDmMessageId(msgid):
    """@cqhttp 解析私聊消息id"""
    buf = _b64decode(msgid)
    user_id = u32(buf)
    seq = u32(buf, 4)
    rand = u32(buf, 8)
    time = u32(buf, 12)
    flag = buf[16] if len(buf) >= 17 else 0
    return {"user_id": user_id, "seq": seq, "rand": rand, "time": time, "flag": flag}


def genGroupMessageId(gid, uid, seq, rand, time, pktnum=1):
    """@cqhttp 生成群消息id"""
    buf = bytearray(21)
    buf[0:4] = pack_u32(gid)
    buf[4:8] = pack_u32(uid)
    buf[8:12] = pack_i32(seq & 0xFFFFFFFF)
    buf[12:16] = pack_i32(rand & 0xFFFFFFFF)
    buf[16:20] = pack_u32(time)
    buf[20] = pktnum if pktnum > 1 else 1
    return base64.b64encode(bytes(buf)).decode()


def parseGroupMessageId(msgid):
    """@cqhttp 解析群消息id"""
    buf = _b64decode(msgid)
    group_id = u32(buf)
    user_id = u32(buf, 4)
    seq = u32(buf, 8)
    rand = u32(buf, 12)
    time = u32(buf, 16)
    pktnum = buf[20] if len(buf) >= 21 else 1
    return {"group_id": group_id, "user_id": user_id, "seq": seq, "rand": rand, "time": time, "pktnum": pktnum}


def _opt(obj, *keys):
    """JS 可选链 `obj[k1]?.[k2]...` 的等价物：任何一层缺失返回 None。"""
    cur = obj
    for k in keys:
        if cur is None:
            return None
        if isinstance(cur, list):
            cur = cur[k] if 0 <= k < len(cur) else None
        elif isinstance(cur, dict):
            cur = cur.get(k)
        else:
            return None
    return cur


def _tostr(x):
    """JS String() 的等价物：None → "undefined"，Proto → toString()，bytes → utf8。"""
    if x is None:
        return "undefined"
    if isinstance(x, list):
        return ",".join(_tostr(i) for i in x)
    if isinstance(x, (bytes, bytearray)):
        return bytes(x).decode("utf-8", errors="replace")
    return str(x)


def _str_or(x, d=""):
    """JS `x?.toString() || d` 的等价物。"""
    if x is None:
        return d
    s = _tostr(x)
    return s if s else d


def _buf(x):
    """取 Proto/bytes 的原始字节。"""
    if x is None:
        return None
    if isinstance(x, (bytes, bytearray)):
        return bytes(x)
    return x.toBuffer()


# CQ码内部转义表（toCqcode 用）
mCQInside = {
    "&": "&amp;",
    ",": "&#44;",
    "[": "&#91;",
    "]": "&#93;",
}


def escapeCQInside(s):
    if s == "&":
        return "&amp;"
    if s == ",":
        return "&#44;"
    if s == "[":
        return "&#91;"
    if s == "]":
        return "&#93;"
    return ""


def _stringify_primitive(v):
    """querystring.stringify 对单值的处理（JS stringifyPrimitive）。"""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if v != v or v in (float("inf"), float("-inf")):
            return ""
        if v.is_integer():
            return str(int(v))
        return str(v)
    if isinstance(v, int):
        return str(v)
    if isinstance(v, str):
        return v
    return ""


def _encode_cq(s, table):
    """encodeURIComponent 替代：只替换 & , [ ] 四字符。"""
    pattern = re.compile("&|,|\\[|\\]")
    return pattern.sub(lambda m: table.get(m.group(0), ""), s)


def _stringify(obj, sep=",", equal="=", table=None):
    """Node querystring.stringify 的等价实现（encodeURIComponent 为 CQ 转义）。"""
    table = table or mCQInside
    parts = []
    for k, v in obj.items():
        ks = _encode_cq(str(k), table) + equal
        if isinstance(v, list):
            for item in v:
                parts.append(ks + _encode_cq(_stringify_primitive(item), table))
        else:
            parts.append(ks + _encode_cq(_stringify_primitive(v), table))
    return sep.join(parts)


class Message:
    """一条消息"""

    @property
    def nickname(self):
        """发送方昵称，仅供内部转发消息时使用"""
        sender = getattr(self, "sender", None)
        if not sender:
            return ""
        return sender.get("card") or sender.get("nickname") or ""

    @staticmethod
    def deserialize(serialized, uin=None):
        """反序列化一条消息 (私聊消息需要你的uin)"""
        proto = pb_decode(serialized)
        t = proto[1].get(3)  # JS 缺失字段为 undefined，走 default 分支
        if t == 82:
            return GroupMessage(proto)
        elif t == 83:
            return DiscussMessage(proto)
        else:
            return PrivateMessage(proto, uin)

    @staticmethod
    def combine(msgs):
        """组合分片消息(通常仅内部使用)"""
        msgs.sort(key=lambda m: m.index)
        host = msgs[0]
        chain = host.message
        for guest in msgs[1:]:
            if guest.atme:
                host.atme = True
            if guest.atall:
                host.atall = True
            host.raw_message += guest.raw_message
            for elem in guest.message:
                prev = chain[-1] if chain else None
                if elem["type"] == "text" and prev is not None and prev.get("type") == "text":
                    prev["text"] += elem["text"]
                else:
                    chain.append(elem)
        return host

    def __init__(self, proto):
        self.proto = proto
        self.post_type = "message"
        # @cqhttp cqhttp方法用
        self.message_id = ""
        head = proto.get(1) or {}
        frag = proto.get(2) or {}
        body = proto.get(3) or {}
        self.pktnum = frag.get(1)
        self.index = frag.get(2)
        self.div = frag.get(3)
        self.user_id = head.get(1)
        self.time = head.get(6)
        self.seq = head.get(5)
        self.rand = _opt(body, 1, 1, 3) or uuid2rand(head.get(7))
        self.font = _str_or(_opt(body, 1, 1, 9), "unknown")
        self.parsed = parse(_opt(body, 1), head.get(2))
        self.message = self.parsed.message
        self.raw_message = self.parsed.brief
        if self.parsed.quotation:
            q = self.parsed.quotation
            q1 = _opt(q, 1)
            q8 = _opt(q, 8)
            q5 = _opt(q, 5)
            self.source = {
                "user_id": _opt(q, 2),
                "time": _opt(q, 3),
                "seq": q1[0] if isinstance(q1, list) and q1 else q1,
                "rand": uuid2rand(_opt(q8, 3) or 0),
                "message": parse(q5 if isinstance(q5, list) else [q5]).brief,
            }
        lock(self, "proto")
        lock(self, "parsed")
        lock(self, "pktnum")
        lock(self, "index")
        lock(self, "div")

    def serialize(self):
        """将消息序列化保存"""
        return self.proto.toBuffer()

    def toString(self):
        """以适合人类阅读的形式输出"""
        return self.parsed.content

    def toJSON(self, keys=None):
        keys = keys or []
        return {
            k: v
            for k, v in vars(self).items()
            if not callable(v) and k not in keys
        }

    def toCqcode(self):
        """@deprecated 转换为CQ码"""
        cqcode = ""
        if getattr(self, "source", None):
            quote = {**self.source, "flag": 1}
            mid = genDmMessageId(self.user_id, quote["seq"], quote["rand"], quote["time"], quote["flag"])
            cqcode += f"[CQ:reply,id={mid}]"
        for c in self.message or []:
            if c["type"] == "text":
                cqcode += c["text"]
                continue
            s = _stringify(c, ",", "=", mCQInside)
            cq = f"[CQ:{c['type']}{',' if s else ''}{s}]"
            cqcode += cq
        return cqcode


class PrivateMessage(Message):
    """一条私聊消息"""

    @staticmethod
    def deserialize(serialized, uin=None):
        """反序列化一条私聊消息，你需要传入你的`uin`，否则无法知道你是发送者还是接收者"""
        return PrivateMessage(pb_decode(serialized), uin)

    def __init__(self, proto, uin=None):
        super().__init__(proto)
        self.message_type = "private"
        # sub_type 取值：
        #   "friend" 好友
        #   "group" 群临时会话
        #   "other" 其他途径的临时会话
        #   "self" 我的设备
        self.sub_type = "friend"
        # 发送方信息
        self.sender = {
            "user_id": 0,  # 账号
            "nickname": "",  # 昵称
            "group_id": None,  # 群号，当消息来自群聊时有效
            "discuss_id": None,  # 讨论组号，当消息来自讨论组时有效
        }
        head = self.proto.get(1) or {}
        content = self.proto.get(2)
        body = self.proto.get(3) or {}
        self.from_id = self.sender["user_id"] = head.get(1)
        self.to_id = head.get(2)
        self.auto_reply = bool(content is not None and _opt(content, 4))
        if head.get(3) == 529:
            if head.get(4) == 4:
                trans = _opt(body, 2, 1)
                if _opt(trans, 1) != 0:
                    raise Exception("unsupported message (ignore ok)")
                elem = {
                    "type": "file",
                    "name": _tostr(_opt(trans, 5)),
                    "size": _opt(trans, 6),
                    "md5": _buf(_opt(trans, 4)).hex() if _opt(trans, 4) is not None else "",
                    "duration": _opt(trans, 51) or 0,
                    "fid": _tostr(_opt(trans, 3)),
                }
                self.message = [elem]
                self.raw_message = "[离线文件]"
                self.parsed.content = f"{{file:{elem['fid']}}}"
            else:
                self.sub_type = "self" if self.from_id == self.to_id else "other"
                self.message = self.raw_message = self.parsed.content = _str_or(_opt(body, 2, 6, 5, 1, 2))
        elif head.get(3) == 141:
            self.sub_type = "group"
            self.sender["nickname"] = _str_or(_opt(self.parsed.extra, 1))
            if _opt(head, 8, 3):
                self.sender["group_id"] = _opt(head, 8, 4)
            else:
                self.sender["discuss_id"] = _opt(head, 8, 4)
        opposite = self.from_id
        flag = 0
        if self.from_id == uin:
            opposite = self.to_id
            flag = 1
        self.message_id = genDmMessageId(opposite, self.seq, self.rand, self.time, flag)


class GroupMessage(Message):
    """一条群消息"""

    @staticmethod
    def deserialize(serialized):
        """反序列化一条群消息"""
        return GroupMessage(pb_decode(serialized))

    def __init__(self, proto):
        super().__init__(proto)
        self.message_type = "group"
        # 发送方信息
        self.sender = {
            "user_id": 0,  # 账号
            "nickname": "",  # 昵称
            "sub_id": "",  # @todo 未知属性
            "card": "",  # 名片
            "sex": "unknown",  # 性别，@deprecated
            "age": 0,  # 年龄，@deprecated
            "area": "",  # 地区，@deprecated
            "level": 0,  # 等级
            "role": "member",  # 权限
            "title": "",  # 头衔
        }
        group = _opt(self.proto, 1, 9)
        self.group_id = _opt(group, 1) or 0
        self.group_name = _str_or(_opt(group, 8))
        self.block = _opt(group, 2) == 127
        self.sender["user_id"] = _opt(self.proto, 1, 1)
        self.sender["sub_id"] = _opt(self.proto, 1, 11)
        if self.parsed.anon:
            self.sub_type = "anonymous"
            anon = self.parsed.anon
            self.anonymous = {
                "id": _opt(anon, 6),
                "id2": _opt(anon, 4),
                "name": _tostr(_opt(anon, 3)),
                "color": _tostr(_opt(anon, 7)),
                "expire_time": _opt(anon, 5),
                "flag": _tostr(_opt(anon, 3)) + "@" + anon[2].toBase64(),
                "enable": True,
            }
            self.sender["card"] = self.sender["nickname"] = "匿名消息"
        else:
            self.sub_type = "normal"
            self.anonymous = None
            ext = self.parsed.extra
            if not _opt(ext, 2):
                self.sender["nickname"] = _str_or(_opt(ext, 1))
            else:
                self.sender["nickname"] = self.sender["card"] = parseFunString(group[4].toBuffer())
            if _opt(ext, 4):
                self.sender["role"] = "owner" if _opt(ext, 4) == 8 else "admin"
            self.sender["level"] = _opt(ext, 3) or 0
            self.sender["title"] = _str_or(_opt(ext, 7))
        self.atme = self.parsed.atme
        self.atall = self.parsed.atall
        self.message_id = genGroupMessageId(self.group_id, self.user_id, self.seq, self.rand, self.time, self.pktnum)


class DiscussMessage(Message):
    """一条讨论组消息"""

    @staticmethod
    def deserialize(serialized):
        """反序列化一条讨论组消息"""
        return DiscussMessage(pb_decode(serialized))

    def __init__(self, proto):
        super().__init__(proto)
        self.message_type = "discuss"
        discuss = _opt(proto, 1, 13)
        self.discuss_id = _opt(discuss, 1) or 0
        self.discuss_name = _str_or(_opt(discuss, 5))
        self.atme = self.parsed.atme
        card = _str_or(_opt(discuss, 4))
        self.sender = {
            "user_id": _opt(proto, 1, 1),
            "nickname": card,
            "card": card,
        }
        self.rand = _opt(proto, 3, 1, 1, 3)


class ForwardMessage:
    """一条转发消息"""

    @staticmethod
    def deserialize(serialized):
        """反序列化一条转发消息"""
        return ForwardMessage(pb_decode(serialized))

    def __init__(self, proto):
        self.proto = proto
        head = proto.get(1) or {}
        self.time = head.get(6) or 0
        self.seq = head.get(5)
        self.user_id = head.get(1) or 0
        self.nickname = _str_or(_opt(head, 14)) or _str_or(_opt(head, 9, 4))
        self.group_id = _opt(head, 9, 1)
        self.parsed = parse(_opt(proto, 3, 1))
        self.message = self.parsed.message
        self.raw_message = self.parsed.brief
        lock(self, "proto")
        lock(self, "parsed")

    def serialize(self):
        """将转发消息序列化保存"""
        return self.proto.toBuffer()

    def toString(self):
        """以适合人类阅读的形式输出"""
        return self.parsed.content

    def toCqcode(self):
        """@deprecated 转换为CQ码"""
        return genCqcode(self.message)


def genCqcode(content):
    cqcode = ""
    for elem in content:
        if elem["type"] == "text":
            cqcode += elem["text"]
            continue
        tmp = dict(elem)
        del tmp["type"]
        str_ = _stringify(tmp, ",", "=", mCQInside)
        cqcode += "[CQ:" + elem["type"] + ("," if str_ else "") + str_ + "]"
    return cqcode
