"""message 包（message/index.js 的移植，星号导出下列模块）。

注意：与 JS index.js 一致，face 与 cqCode 不被星号导出（仅作为内部模块）。
"""
from __future__ import annotations

from .message import (
    DiscussMessage,
    ForwardMessage,
    GroupMessage,
    Message,
    PrivateMessage,
    genDmMessageId,
    genGroupMessageId,
    parseDmMessageId,
    parseGroupMessageId,
    rand2uuid,
    uuid2rand,
)
from .elements import ChainElemTypes, segment
from .image import Image, buildImageFileParam, parseImageFileParam
from .converter import Converter
from .parser import Parser, getGroupImageUrl, parse
from .music import buildMusic, makeMusicJson, musicFactory
from .share import buildShare
