"""构造链接分享卡片（share.js 的移植）。"""
from __future__ import annotations

from enum import IntEnum


class app(IntEnum):
    """JS 中的 TS 数字枚举 var app（模块私有，未导出）。"""

    qq = 100446242
    mi = 1105414497
    quark = 1105781586


defaultConfig = {
    "appid": int(app.qq),
    # 有音乐4 没音乐0
    # style: 4,
    "appname": "com.tencent.mtt",
    "appsign": "d8391a394d4a179e6fe7bdb8a301258b",
}


def _number(s):
    """JS Number() 的等价物（无法解析返回 NaN，pb 编码时与 JS 一致写 double）。"""
    if isinstance(s, bool):
        return int(s)
    if isinstance(s, (int, float)):
        return s
    try:
        return int(s)
    except (ValueError, TypeError):
        try:
            return float(s)
        except (ValueError, TypeError):
            return float("nan")


def buildShare(target, bu, content, config=None):
    """构造链接分享
    :param target 群号或者好友账号
    :param bu 类型表示：`0`为好友，`1`为群
    :param content 分享链接
    :param config 分享配置
    """
    config = {**defaultConfig, **(config or {})}
    return {
        1: config["appid"],
        2: 1,
        3: 4 if content.get("audio") else 0,
        5: {
            1: 1,
            2: "0.0.0",
            3: config["appname"],
            4: config["appsign"],
        },
        10: 3 if isinstance(bu, str) else bu,
        11: target,
        12: {
            10: content.get("title"),
            11: content.get("summary"),
            12: content.get("content"),
            13: content.get("url"),
            14: content.get("image"),  # ?? 'https://tangram-1251316161.file.myqcloud.com/files/20210721/e50a8e37e08f29bf1ffc7466e1950690.png'
            16: content.get("audio"),
        },
        19: _number(bu) if isinstance(bu, str) else None,
    }
