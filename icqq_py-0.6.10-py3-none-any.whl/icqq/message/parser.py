"""消息解析器（parser.js 的移植）。"""
from __future__ import annotations

import zlib
from urllib.parse import urlparse

from ..core.buffer import u32
from ..core.pb import Proto, decode
from .face import facemap, pokemap
from .image import buildImageFileParam


def parse(rich, uin=None):
    """解析消息"""
    return Parser(rich, uin)


def _opt(obj, *keys):
    """JS 可选链 `obj[k1]?.[k2]...` 的等价物：任何一层缺失返回 None。"""
    cur = obj
    for k in keys:
        if cur is None:
            return None
        if isinstance(cur, list):
            cur = cur[k] if 0 <= k < len(cur) else None
        elif isinstance(cur, dict):
            cur = cur.get(k)
        else:
            return None
    return cur


def _tostr(x):
    """JS String() 的等价物：None → "undefined"，Proto → toString()，bytes → utf8。"""
    if x is None:
        return "undefined"
    if isinstance(x, list):
        return ",".join(_tostr(i) for i in x)
    if isinstance(x, (bytes, bytearray)):
        return bytes(x).decode("utf-8", errors="replace")
    return str(x)


def _str_or(x, d=""):
    """JS `x?.toString() || d` 的等价物。"""
    if x is None:
        return d
    s = _tostr(x)
    return s if s else d


def _buf(x):
    """取 Proto/bytes 的原始字节。"""
    if x is None:
        return None
    if isinstance(x, (bytes, bytearray)):
        return bytes(x)
    return x.toBuffer()


def _num(x):
    """JS Number() 的近似等价物；无法解析返回 None（对应 NaN，配合 `or 0` 使用）。"""
    if x is None:
        return None
    if isinstance(x, bool):
        return int(x)
    if isinstance(x, (int, float)):
        return x
    s = _tostr(x)
    try:
        return int(s)
    except (ValueError, TypeError):
        try:
            return float(s)
        except (ValueError, TypeError):
            return None


def _len(x):
    """JS 的 .length：Proto 取 encoded 字节长度，其余取 len()。"""
    if isinstance(x, Proto):
        return x.length
    return len(x)


class Parser:
    """消息解析器"""

    def __init__(self, rich, uin=None):
        self.uin = uin
        self.message = []
        self.brief = ""
        self.content = ""
        self.atme = False
        self.atall = False
        self.newImg = False
        self.imgprefix = {}
        self.exclusive = False
        # JS 中未初始化、按需赋值的三个属性，这里提前置 None 等价于 undefined
        self.extra = None
        self.anon = None
        self.quotation = None
        if isinstance(rich, list):
            self.parseElems(rich)
        else:
            r4 = _opt(rich, 4)
            if r4 is not None and _len(r4) > 0:
                self.parseExclusiveElem(0, r4)
            r2 = _opt(rich, 2)
            self.parseElems(r2 if isinstance(r2, list) else [r2])

    def getNextText(self):
        """获取下一个节点的文本"""
        try:
            elem = next(self.it)[1][1]
            return _tostr(elem[1])
        except Exception:
            return "[未知]"

    def parseExclusiveElem(self, type, proto):
        """解析: xml, json, ptt, video, flash, file, shake, poke"""
        elem = None
        brief = None
        if type == 12 or type == 51:  # xml / json
            buf = _buf(proto[1])
            if buf[0] > 0:
                data = zlib.decompress(buf[1:]).decode("utf-8", errors="replace")
            else:
                data = buf[1:].decode("utf-8", errors="replace")
            elem = {
                "type": "xml" if type == 12 else "json",
                "data": data,
                "id": proto.get(2),
            }
            brief = elem["type"] + "消息"
            self.content = elem["data"]
        elif type == 3:  # flash
            elem = self.parseNewImgElem(proto, "flash")
            brief = "闪照"
            self.content = f"{{flash:{elem['file'][:32].upper()}}}"
        elif type == 0:  # ptt
            elem = {
                "type": "record",
                "file": "protobuf://" + proto.toBase64(),
                "url": "",
                "md5": proto[4].toHex(),
                "size": proto.get(6) or 0,
                "seconds": proto.get(19) or 0,
            }
            if proto.get(20):
                url = _tostr(proto.get(20))
                elem["url"] = url if url.startswith("http") else "https://grouptalk.c2c.qq.com" + url
            brief = "语音"
            self.content = f"{{ptt:{elem['url']}}}"
        elif type == 19:  # video
            elem = {
                "type": "video",
                "file": "protobuf://" + proto.toBase64(),
                "name": _str_or(_opt(proto, 3)),
                "fid": _tostr(proto.get(1)),
                "md5": proto[2].toBase64(),
                "size": proto.get(6) or 0,
                "seconds": proto.get(5) or 0,
            }
            brief = "视频"
            self.content = f"{{video:{elem['fid']}}}"
        elif type == 5:  # transElem
            trans = decode(_buf(proto[2])[3:])[7][2]
            elem = {
                "type": "file",
                "name": _tostr(_opt(trans, 4)),
                "fid": _tostr(_opt(trans, 2)).replace("/", "", 1),
                "md5": _tostr(_opt(trans, 8)),
                "size": _opt(trans, 3),
                "duration": _opt(trans, 5),
            }
            brief = "群文件"
            self.content = f"{{file:{elem['fid']}}}"
        elif type == 37:  # qlottie
            elem = {
                "type": "face",
                "id": proto[2][3],
                "text": facemap.get(proto[2][3]),
            }
            if not elem["text"]:
                elem["text"] = _tostr(_opt(proto[2], 7)) if _opt(proto[2], 7) else "超级表情"
            if _opt(proto[2], 2):
                elem["qlottie"] = _tostr(proto[2][2])
            brief = elem["text"]
            self.content = (
                f"{{face:{elem['id']},text:{elem['text']},"
                f"qlottie:{elem['qlottie'] if 'qlottie' in elem else 'undefined'}}}"
            )
        elif type == 126:  # poke
            if not proto.get(3):
                return
            pokeid = proto[2][4] if proto.get(3) == 126 else proto.get(3)
            elem = {
                "type": "poke",
                "id": pokeid,
                "text": pokemap.get(pokeid),
            }
            brief = pokemap.get(pokeid)
            self.content = f"{{poke:{elem['id']}}}"
        else:
            return
        self.message = [elem]
        self.brief = "[" + ("undefined" if brief is None else str(brief)) + "]"
        self.exclusive = True

    def parsePartialElem(self, type, proto):
        """解析: text, at, face, bface, sface, image, mirai"""
        elem = None
        brief = ""
        content = ""
        if type == 1:  # text&at
            brief = _tostr(proto.get(1))
            buf = _buf(_opt(proto, 3))
            if buf is not None and buf[1] == 1:
                elem = {
                    "type": "at",
                    "qq": 0,
                    "text": brief,
                }
                if buf[6] == 1:
                    elem["qq"] = "all"
                    self.atall = True
                else:
                    elem["qq"] = u32(buf, 7)
                    if elem["qq"] == self.uin:
                        self.atme = True
                brief = brief or ("@" + str(elem["qq"]))
                content = f"{{at:{elem['qq']}}}"
            elif _opt(proto, 12) and not _opt(proto, 12, 1):
                # 频道中的AT
                elem = {
                    "type": "at",
                    "qq": 0,
                    "text": brief,
                }
                elem["id"] = _tostr(_opt(proto, 12, 5)) if _opt(proto, 12, 5) else "all"
                brief = brief or ("@" + str(elem["qq"]))
                content = f"{{at:{elem['qq']}}}"
            else:
                if not brief:
                    return
                content = brief
                elem = {
                    "type": "text",
                    "text": brief,
                }
        elif type == 2:  # face
            elem = {
                "type": "face",
                "id": proto.get(1),
                "text": facemap.get(proto.get(1)) or "表情",
            }
            brief = f"[{elem['text']}]"
            content = f"{{face:{elem['id']}}}"
        elif type == 33:  # face(id>255)
            elem = {
                "type": "face",
                "id": proto.get(1),
                "text": facemap.get(proto.get(1)),
            }
            if not elem["text"]:
                elem["text"] = _tostr(_opt(proto, 2)) if _opt(proto, 2) else "/" + str(elem["id"])
            brief = f"[{elem['text']}]"
            content = f"{{face:{elem['id']}}}"
        elif type == 6:  # bface
            brief = self.getNextText()
            if "骰子" in brief or "猜拳" in brief:
                elem = {
                    "type": "dice" if "骰子" in brief else "rps",
                    "id": _buf(proto[12])[16] - 0x30 + 1,
                }
                content = f"{{{elem['type']}:{elem['id']}}}"
            else:
                elem = {
                    "type": "bface",
                    "file": proto[4].toHex() + proto[7].toHex() + str(proto.get(5)),
                    "text": brief.replace("[", "").replace("]", ""),
                }
                content = f"{{bface:{elem['text']}}}"
        elif type == 4 or type == 8:
            if self.newImg:
                return
            elem = self.parseImgElem(type, proto, "image")
            brief = ("[动画表情]" if elem.get("asface") else "[图片]") + (elem.get("summary") or "")
            content = f"{{image:{elem['md5'].upper()}}}"
        elif type == 34:  # sface
            brief = self.getNextText()
            elem = {
                "type": "sface",
                "id": proto.get(1),
                "text": brief.replace("[", "").replace("]", ""),
            }
            content = f"{{sface:{elem['id']}}}"
        elif type == 31:  # mirai
            if proto.get(3) == 103904510:
                elem = {
                    "type": "mirai",
                    "data": _tostr(proto.get(2)),
                }
            else:
                return
        elif type == 45:
            elem = {
                "type": "markdown",
                "content": _tostr(_opt(proto, 1)),
            }
        elif type == 46:
            try:
                p11 = proto[1][1]
                rows = p11 if isinstance(p11, list) else [p11]
                content_rows = []
                for row in rows:
                    row1 = row[1]
                    row1 = row1 if isinstance(row1, list) else [row1]
                    buttons = []
                    for val in row1:
                        button = {
                            "id": "",
                            "render_data": {},
                            "action": {
                                "permission": {},
                            },
                        }
                        if val.get(1):
                            button["id"] = _tostr(val.get(1))
                        if val.get(2):
                            button["render_data"]["label"] = _tostr(_opt(val[2], 1))
                            button["render_data"]["visited_label"] = _tostr(_opt(val[2], 2))
                            button["render_data"]["style"] = _num(_opt(val[2], 3)) or 0
                        if val.get(3):
                            button["action"]["type"] = _num(_opt(val[3], 1)) or 0
                            button["action"]["unsupport_tips"] = _tostr(_opt(val[3], 4))
                            button["action"]["data"] = _tostr(_opt(val[3], 5))
                            button["action"]["reply"] = _opt(val[3], 7) == 1
                            button["action"]["enter"] = _opt(val[3], 8) == 1
                            if _opt(val[3], 2):
                                button["action"]["permission"]["type"] = _num(_opt(val[3], 2, 1)) or 0
                                button["action"]["permission"]["specify_role_ids"] = _opt(val[3], 2, 2) or []
                                button["action"]["permission"]["specify_user_ids"] = _opt(val[3], 2, 3) or []
                        buttons.append(button)
                    content_rows.append({"buttons": buttons})
                elem = {
                    "type": "button",
                    "content": {
                        "appid": _num(_opt(proto[1], 2)) or 0,
                        "rows": content_rows,
                    },
                }
            except Exception:
                return
        elif type == 48:
            elem = self.parseNewImgElem(proto, "image")
            if not elem:
                return
            brief = ("[动画表情]" if elem.get("asface") else "[图片]") + (elem.get("summary") or "")
            content = f"{{image:{elem['md5'].upper()}}}"
        else:
            return
        # 删除回复中多余的AT元素
        if (
            len(self.message) == 2
            and elem["type"] == "at"
            and self.message[0].get("type") == "at"
            and self.message[1].get("type") == "text"
        ):
            if self.message[0]["qq"] == elem["qq"] and self.message[1]["text"] == " ":
                del self.message[0:2]
                self.brief = ""
        self.brief += brief
        self.content += content
        if not isinstance(self.message, list):
            self.message = []
        prev = self.message[-1] if self.message else None
        if elem["type"] == "text" and prev is not None and prev.get("type") == "text":
            prev["text"] += elem["text"]
        else:
            self.message.append(elem)

    def parseElems(self, arr):
        self.it = iter(enumerate(arr))
        while True:
            item = next(self.it, None)
            if item is None:
                break
            wrapper = item[1]
            if wrapper is None:
                break
            if not isinstance(wrapper, dict):
                # JS 对非对象 truthy 值：取不到字段key → type=NaN → 默认分支跳过
                continue
            # JS: Object.keys(Reflect.getPrototypeOf(wrapper))[0]，整数键按升序枚举 → 最小tag
            keys = [int(k) for k in wrapper.keys()]
            if not keys:
                # JS: Number(undefined) = NaN，switch 默认分支直接跳过
                continue
            type = min(keys)
            proto = wrapper[type]
            if type == 16:  # extraInfo
                self.extra = proto
            elif type == 21:  # anonGroupMsg
                self.anon = proto
            elif type == 45:  # sourceMsg
                self.quotation = proto
            elif not self.exclusive:
                if type in (1, 2, 4, 6, 8, 31, 34):  # text / face / notOnlineImage / bface / customFace / mirai / sface
                    self.parsePartialElem(type, proto)
                elif type in (5, 12, 19, 51):  # transElem / xml / video / json
                    self.parseExclusiveElem(type, proto)
                elif type == 53:  # commonElem
                    if proto.get(1) == 3:  # flash
                        self.parseExclusiveElem(3, _opt(proto, 2, 1) or _opt(proto, 2, 2))
                    elif proto.get(1) == 33:  # face(id>255)
                        self.parsePartialElem(33, proto[2])
                    elif proto.get(1) == 2:  # poke
                        self.parseExclusiveElem(126, proto)
                    elif proto.get(1) == 37:  # qlottie
                        self.parseExclusiveElem(37, proto)
                    elif proto.get(1) == 20:  # json
                        self.parseExclusiveElem(51, proto[2])
                    elif proto.get(1) == 45:
                        self.parsePartialElem(proto[1], proto[2])
                    elif proto.get(1) == 46:
                        self.parsePartialElem(proto[1], proto[2])
                    elif proto.get(1) == 48:
                        self.parsePartialElem(proto[1], proto[2])

    def parseNewImgElem(self, proto, type):
        # JS 原版 else 分支无 return（返回 undefined），此处保持一致
        node = _opt(proto, 2, 1, 11) or _opt(proto, 2, 1, 12)
        path = _opt(node, 30) if node is not None else None
        if path:
            self.newImg = True
            elem = {
                "type": type,
                "file": _tostr(_opt(proto, 1, 1, 1, 4)),
                "url": f"https://{_tostr(_opt(proto, 1, 2, 3))}{path}{_opt(proto, 1, 2, 2, 1) or '&spec=0'}",
                "fid": _tostr(_opt(proto, 1, 1, 2)),
                "md5": _tostr(_opt(proto, 1, 1, 1, 2)),
                "height": _opt(proto, 1, 1, 1, 7),
                "width": _opt(proto, 1, 1, 1, 6),
                "size": _opt(proto, 1, 1, 1, 1),
                "summary": _tostr(_opt(proto, 2, 1, 2)),
            }
            if type == "image":
                elem["asface"] = _opt(proto, 2, 1, 1) == 1
            elem["file"] = buildImageFileParam(
                elem["md5"], elem["size"], elem["width"], elem["height"], _opt(proto, 1, 1, 1, 5, 2)
            )
            return elem
        else:
            elem = {
                "type": type,
                "file": _tostr(_opt(proto, 1, 1, 1, 4)),
                "url": f"https://{_tostr(_opt(proto, 1, 2, 3))}{_opt(proto, 1, 2, 1)}",
                "fid": _tostr(_opt(proto, 1, 1, 2)),
                "md5": _tostr(_opt(proto, 1, 1, 1, 2)),
                "height": _opt(proto, 1, 1, 1, 7),
                "width": _opt(proto, 1, 1, 1, 6),
                "size": _opt(proto, 1, 1, 1, 1),
                "summary": _tostr(_opt(proto, 2, 1, 2)),
            }
            if type == "image":
                elem["asface"] = _opt(proto, 2, 1, 1) == 1
            elem["file"] = buildImageFileParam(
                elem["md5"], elem["size"], elem["width"], elem["height"], _opt(proto, 1, 1, 1, 5, 2)
            )
            self.imgprefix[elem["md5"]] = elem

    def parseImgElem(self, source_type, proto, type):
        dm = bool(_opt(proto, 1)) if type == "flash" else (source_type != 8)
        md5 = proto[7 if dm else 13].toHex()
        path = _opt(proto, 29 if dm else 34, 30)
        prev = self.imgprefix.get(md5)
        if prev and path:
            parsed = urlparse(prev["url"])
            elem = {
                **prev,
                "type": type,
                "url": f"{parsed.scheme}://{parsed.netloc}{path}&spec=0",
            }
        else:
            elem = {
                "type": type,
                "file": "",
                "url": "",
                "md5": md5,
                "height": proto[8 if dm else 23],
                "width": proto[9 if dm else 22],
                "size": proto[2 if dm else 25],
                "summary": _tostr(_opt(proto, 29 if dm else 34, 8 if dm else 9)),
            }
            elem["file"] = buildImageFileParam(
                elem["md5"], elem["size"], elem["width"], elem["height"], proto[5 if dm else 20]
            )
        if type == "image":
            elem["asface"] = _opt(proto, 29 if dm else 34, 1) == 1
        if not elem["url"]:
            if path:
                elem["url"] = f"https://c2cpicdw.qpic.cn{path}&spec=0"
            elif _opt(proto, 16):
                elem["url"] = f"https://gchat.qpic.cn{_tostr(proto.get(16))}"
            elif _opt(proto, 15):
                elem["url"] = f"https://c2cpicdw.qpic.cn{_tostr(proto.get(15))}"
            else:
                elem["url"] = getGroupImageUrl(md5)
        return elem


def getGroupImageUrl(md5):
    return f"https://gchat.qpic.cn/gchatpic_new/0/0-0-{md5.upper()}/0"
