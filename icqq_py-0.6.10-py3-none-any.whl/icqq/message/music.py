"""音乐分享卡片（music.js 的移植）。"""
from __future__ import annotations

import re
import time
from urllib.parse import quote

from ..core.http import http_get_json


async def getQQSong(id):
    url = (
        "https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&inCharset=utf8&outCharset=utf-8&notice=0&platform=yqq.json&needNewCode=0&data="
        '{"comm":{"ct":24,"cv":0},"songinfo":{"method":"get_song_detail_yqq","param":{"song_type":0,"song_mid":"","song_id":'
        + str(id)
        + '}},"module":"music.pf_song_detail_svr"}}'
    )
    rsp = await http_get_json(url)
    rsp = rsp["songinfo"]["data"]["track_info"]
    mid = rsp["mid"]
    title = rsp["name"]
    album = rsp["album"]["mid"]
    singer = "unknown"
    if rsp.get("singer"):
        s0 = rsp["singer"][0]
        singer = (s0.get("name") if isinstance(s0, dict) else None) or "unknown"
    url = (
        'http://u.y.qq.com/cgi-bin/musicu.fcg?g_tk=2034008533&uin=0&format=json&data={"comm":{"ct":23,"cv":0},"url_mid":{"module":"vkey.GetVkeyServer","method":"CgiGetVkey","param":{"guid":"4311206557","songmid":["'
        + str(mid)
        + '"],"songtype":[0],"uin":"0","loginflag":1,"platform":"23"}}}&_=1599039471576'
    )
    rsp = await http_get_json(url)
    rsp = rsp["url_mid"]["data"]["midurlinfo"][0]
    return {
        "title": title,
        "singer": singer,
        "jumpUrl": f"https://i.y.qq.com/v8/playsong.html?platform=11&appshare=android_qq&appversion=10030010&hosteuin=oKnlNenz7i-s7c**&songmid={mid}&type=0&appsongtype=1&_wv=1&source=qq&ADTAG=qfshare",
        "musicUrl": rsp["purl"],
        "preview": f"http://y.gtimg.cn/music/photo_new/T002R180x180M000{album}.jpg",
    }


async def get163Song(id):
    rsp = await http_get_json(f"http://music.163.com/api/song/detail/?id={id}&ids=[{id}]")
    rsp = rsp["songs"][0]
    return {
        "title": rsp["name"],
        "singer": rsp["artists"][0]["name"],
        "jumpUrl": "https://y.music.163.com/m/song/" + id,
        "musicUrl": "http://music.163.com/song/media/outer/url?id=" + id,
        "preview": rsp["album"]["picUrl"],
    }


async def getMiGuSong(id):
    rsp = await http_get_json(
        f"https://c.musicapp.migu.cn/MIGUM2.0/v1.0/content/resourceinfo.do?copyrightId={id}&resourceType=2"
    )
    rsp = rsp["resource"][0]
    preview = ""
    try:
        a = await http_get_json(
            f"https://music.migu.cn/v3/api/music/audioPlayer/getSongPic?songId={rsp['songId']}",
            headers={"referer": "https://music.migu.cn/v3/music/player/audio"},
        )
        preview = a.get("smallPic") or ""
    except Exception:
        pass
    url = await http_get_json(
        f"https://app.c.nf.migu.cn/MIGUM2.0/v1.0/content/shareInfo.do?contentId={rsp['contentId']}"
        f"&contentName={quote(rsp['songName'])}&resourceType=2&targetUserName={quote(rsp['singer'])}"
    )
    jumpUrl = url.get("url") or "http://c.migu.cn/"
    if rsp.get("newRateFormats"):
        musicUrl = re.sub(r"ftp://[^/]+", "https://freetyst.nf.migu.cn", rsp["newRateFormats"][0]["url"], count=1)
    else:
        musicUrl = re.sub(r"ftp://[^/]+", "https://freetyst.nf.migu.cn", rsp["rateFormats"][0]["url"], count=1)
    return {
        "title": rsp["songName"],
        "singer": rsp["singer"],
        "jumpUrl": jumpUrl,
        "musicUrl": musicUrl,
        "preview": preview or "",
    }


async def getKuGouSong(id):
    url = (
        f"https://wwwapi.kugou.com/yy/index.php?r=play/getdata&callback=&hash={id}&dfid=&mid={id}&platid=4"
        f"&_={int(time.time() * 1000)}&album_id="
    )
    rsp = await http_get_json(url)
    rsp = rsp["data"]
    url += str(rsp["album_id"])
    rsp = await http_get_json(url)
    rsp = rsp["data"]
    return {
        "title": rsp["audio_name"],
        "singer": rsp["author_name"],
        "jumpUrl": f"https://www.kugou.com/song/#hash={id}&album_id={rsp['album_id']}",
        "musicUrl": rsp.get("play_url") or "https://webfs.yun.kugou.com",
        "preview": rsp.get("img"),
    }


async def getKuwoSong(id):
    rsp = await http_get_json(
        f"http://yinyue.kuwo.cn/api/www/music/musicInfo?mid={id}&httpsStatus=1",
        headers={"csrf": id, "cookie": " kw_token=" + id},
    )
    rsp = rsp["data"]
    # let url: any = await axios.get(`http://yinyue.kuwo.cn/url?format=mp3&rid=${id}&response=url&type=convert_url3&from=web&t=${+new Date()}`, { responseType: "json" })
    url = await http_get_json(f"http://www.kuwo.cn/api/v1/www/music/playUrl?mid={id}&type=music&httpsStatus=1")
    return {
        "title": rsp["name"],
        "singer": rsp["artist"],
        "jumpUrl": "http://yinyue.kuwo.cn/play_detail/" + id,
        "musicUrl": url["data"]["url"] or "https://win-web-ra01-sycdn.kuwo.cn",
        "preview": rsp["pic"],
    }


musicFactory = {
    "qq": {
        "appid": 100497308,
        "name": "QQ音乐",
        "icon": "https://p.qpic.cn/qqconnect/0/app_100497308_1626060999/100?max-age=2592000&t=0",
        "package_name": "com.tencent.qqmusic",
        "sign": "cbd27cd7c861227d013a25b2d10f0799",
        "getMusicInfo": getQQSong,
    },
    "163": {
        "appid": 100495085,
        "name": "网易云音乐",
        "icon": "https://i.gtimg.cn/open/app_icon/00/49/50/85/100495085_100_m.png",
        "package_name": "com.netease.cloudmusic",
        "sign": "da6b069da1e2982db3e386233f68d76d",
        "getMusicInfo": get163Song,
    },
    "migu": {
        "appid": 1101053067,
        "name": "咪咕音乐",
        "package_name": "cmccwm.mobilemusic",
        "sign": "6cdc72a439cef99a3418d2a78aa28c73",
        "getMusicInfo": getMiGuSong,
    },
    "kugou": {
        "appid": 205141,
        "name": "酷狗音乐",
        "icon": "https://open.gtimg.cn/open/app_icon/00/20/51/41/205141_100_m.png?t=0",
        "package_name": "com.kugou.android",
        "sign": "fe4a24d80fcf253a00676a808f62c2c6",
        "getMusicInfo": getKuGouSong,
    },
    "kuwo": {
        "appid": 100243533,
        "name": "酷我音乐",
        "icon": "https://p.qpic.cn/qqconnect/0/app_100243533_1636374695/100?max-age=2592000&t=0",
        "package_name": "cn.kuwo.player",
        "sign": "bf9ff4ffb4c558a34ee3fd52c223ebf5",
        "getMusicInfo": getKuwoSong,
    },
}


def _number(s):
    """JS Number() 的等价物（无法解析返回 NaN，pb 编码时与 JS 一致写 double）。"""
    if isinstance(s, bool):
        return int(s)
    if isinstance(s, (int, float)):
        return s
    try:
        return int(s)
    except (ValueError, TypeError):
        try:
            return float(s)
        except (ValueError, TypeError):
            return float("nan")


async def buildMusic(target, bu, platform, id):
    """构造b77音乐分享
    :param target 群id或者好友qq / 频道时传入channel_id与guild_id
    :param bu 类型表示：0 为好友 1 为群（字符串表示频道）
    :param platform 音乐平台
    :param id 音乐id
    """
    info = musicFactory[platform]
    appid = info["appid"]
    package_name = info["package_name"]
    sign = info["sign"]
    getMusicInfo = info["getMusicInfo"]
    style = 4
    try:
        song = await getMusicInfo(id)
        singer = song["singer"]
        title = song["title"]
        jumpUrl = song["jumpUrl"]
        musicUrl = song["musicUrl"]
        preview = song["preview"]
        if not musicUrl:
            style = 0
        return {
            1: appid,
            2: 1,
            3: style,
            5: {
                1: 1,
                2: "0.0.0",
                3: package_name,
                4: sign,
            },
            10: 3 if isinstance(bu, str) else bu,
            11: target,
            12: {
                10: title,
                11: singer,
                12: "[分享]" + title,
                13: jumpUrl,
                14: preview,
                16: musicUrl,
            },
            19: _number(bu) if isinstance(bu, str) else None,
        }
    except Exception as e:
        raise Exception(f"unknown music id: {id}, in platform: {platform}") from e


def makeMusicJson(musicInfo):
    info = musicFactory[musicInfo["platform"]]
    appid = info["appid"]
    name = info["name"]
    icon = info.get("icon")
    inner = {
        "app_type": 1,
        "appid": appid,
        "desc": musicInfo.get("singer"),
        "jumpUrl": musicInfo.get("jumpUrl"),
        "musicUrl": musicInfo.get("musicUrl"),
        "preview": musicInfo.get("preview"),
        "sourceMsgId": "0",
        "source_icon": icon,
        "source_url": "",
        "tag": name,
        "title": musicInfo.get("title"),
    }
    if inner["source_icon"] is None:
        # JS: JSON.stringify 会丢弃值为 undefined 的键
        del inner["source_icon"]
    return {
        "app": "com.tencent.qzone.structmsg",
        "config": {"type": "normal", "autosize": True, "forward": True},
        "desc": "音乐",
        "meta": {
            "music" if musicInfo.get("musicUrl") else "news": inner,
        },
        "prompt": f"[分享]{musicInfo.get('title')} {musicInfo.get('singer')}",
        "ver": "0.0.0.1",
        "view": "music" if musicInfo.get("musicUrl") else "news",
    }
