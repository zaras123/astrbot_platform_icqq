"""用于构造消息元素（elements.js 的移植）。"""
from __future__ import annotations

import json as _json
import re

from .music import makeMusicJson, musicFactory

ChainElemTypes = [
    "text", "at", "face", "sface", "bface", "rps", "dice", "image", "markdown", "button", "mirai",
    "reply", "quote", "node",
]


def text(text):
    """@deprecated 文本，建议直接使用字符串"""
    return {"type": "text", "text": text}


def face(id):
    """经典表情(id=0~324)"""
    return {"type": "face", "id": id}


def sface(id, text=None):
    """小表情(id规则不明)"""
    return {"type": "sface", "id": id, "text": text}


def bface(file, text=None):
    """原创表情(file规则不明)"""
    return {"type": "bface", "file": file, "text": text}


def rps(id=None):
    """猜拳(id=1~3)"""
    return {"type": "rps", "id": id}


def dice(id=None):
    """骰子(id=1~6)"""
    return {"type": "dice", "id": id}


def at(qq, text=None, dummy=None):
    """mention@提及
    :param qq 全体成员:"all", 频道:tiny_id
    """
    if (isinstance(qq, int) and not isinstance(qq, bool)) or qq == "all":
        return {"type": "at", "qq": qq, "text": text, "dummy": dummy}
    # 频道中的AT
    return {"type": "at", "qq": 0, "id": str(qq), "text": text, "dummy": dummy}


def image(file, cache=None, timeout=None, headers=None):
    """图片，支持http://,base64://"""
    return {"type": "image", "file": file, "cache": cache, "timeout": timeout, "headers": headers}


def flash(file, cache=None, timeout=None, headers=None):
    """闪照，支持http://,base64://"""
    return {"type": "flash", "file": file, "cache": cache, "timeout": timeout, "headers": headers}


def record(file, data=None):
    """语音，支持http://,base64://"""
    data = data or {}
    return {"type": "record", "file": file, **data}


def video(file, data=None):
    """视频，支持http://,base64://"""
    data = data or {}
    return {"type": "video", "file": file, **data}


def json(data):
    return {"type": "json", "data": data}


def xml(data, id=None):
    return {"type": "xml", "data": data, "id": id}


def markdown(content):
    return {"type": "markdown", "content": content}


def button(content):
    return {"type": "button", "content": content}


def mirai(data):
    """一种特殊消息(官方客户端无法解析)"""
    return {"type": "mirai", "data": data}


async def music(id, platform="qq"):
    """音乐"""
    musiInfo = await musicFactory[platform]["getMusicInfo"](id)
    musiInfo["jumpUrl"] = f"https://ptlogin2.qq.com@{re.sub(r'https?://', '', musiInfo['jumpUrl'], count=1)}"
    return segment["json"]({**musiInfo, "platform": platform})


def fake(user_id, message, nickname=None, time=None):
    return {"type": "node", "user_id": user_id, "nickname": nickname, "message": message, "time": time}


def share(url, title, image=None, content=None):
    """链接分享"""
    return {"type": "share", "url": url, "title": title, "image": image, "content": content}


def location(lat, lng, address, id=None):
    """位置分享"""
    return {"type": "location", "lat": lat, "lng": lng, "address": address, "id": id}


def poke(id):
    """id 0~6"""
    return {"type": "poke", "id": id}


def fromCqcode(str):
    """@deprecated 将CQ码转换为消息链"""
    elems = []
    prev_index = 0
    pattern = re.compile(r"&#91;|&#93;|&amp;")
    for m in re.finditer(r"\[CQ:[^\]]+\]", str):
        text = pattern.sub(lambda x: unescapeCQ(x.group(0)), str[prev_index:m.start()])
        if text:
            elems.append({"type": "text", "text": text})
        element = m.group(0)
        cq = element.replace("[CQ:", "type=")
        cq = cq[:-1]
        elems.append(qs(cq))
        prev_index = m.end()
    if prev_index < len(str):
        text = pattern.sub(lambda x: unescapeCQ(x.group(0)), str[prev_index:])
        if text:
            elems.append({"type": "text", "text": text})
    return elems


def unescapeCQ(s):
    if s == "&#91;":
        return "["
    if s == "&#93;":
        return "]"
    if s == "&amp;":
        return "&"
    return ""


def unescapeCQInside(s):
    if s == "&#44;":
        return ","
    if s == "&#91;":
        return "["
    if s == "&#93;":
        return "]"
    if s == "&amp;":
        return "&"
    return ""


def qs(s, sep=",", equal="="):
    ret = {}
    pattern = re.compile(r"&#44;|&#91;|&#93;|&amp;")
    for v in s.split(sep):
        i = v.find(equal)
        if i == -1:
            continue
        ret[v[:i]] = pattern.sub(lambda x: unescapeCQInside(x.group(0)), v[i + 1:])
    for k in list(ret.keys()):
        try:
            if k != "text":
                ret[k] = _json.loads(ret[k])
        except Exception:
            pass
    return ret


# 用于构造消息元素。
# JS 中是普通对象 segment.image(...)，Python 用类实现同样的属性调用语法。
class _Segment:
    text = staticmethod(text)
    face = staticmethod(face)
    sface = staticmethod(sface)
    bface = staticmethod(bface)
    rps = staticmethod(rps)
    dice = staticmethod(dice)
    at = staticmethod(at)
    image = staticmethod(image)
    flash = staticmethod(flash)
    record = staticmethod(record)
    video = staticmethod(video)
    json = staticmethod(json)
    xml = staticmethod(xml)
    markdown = staticmethod(markdown)
    button = staticmethod(button)
    mirai = staticmethod(mirai)
    music = staticmethod(music)
    fake = staticmethod(fake)
    share = staticmethod(share)
    location = staticmethod(location)
    poke = staticmethod(poke)
    fromCqcode = staticmethod(fromCqcode)


segment = _Segment()
