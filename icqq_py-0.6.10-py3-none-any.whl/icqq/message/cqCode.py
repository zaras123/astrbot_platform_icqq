"""CQ码解析（cqCode.js 的移植）。"""
from __future__ import annotations

import json
import re

mCQ = {
    "&#91;": "[",
    "&#93;": "]",
    "&amp;": "&",
}
mCQInside = {
    "&": "&amp;",
    ",": "&#44;",
    "[": "&#91;",
    "]": "&#93;",
}
mCQInvert = {mCQInside[key]: key for key in mCQInside.keys()}


def matchBracket(text, index, brackets=["[", "]"]):
    stackSize = 0
    if len(text) <= 2:
        return -3
    if 0 > index or index > len(text) - 1:
        return -4
    if not isinstance(brackets, list) or 2 != len(brackets):
        return -5
    for bracket in brackets:
        if 1 != len(bracket):
            return -5
    start = text[index]
    if start != brackets[0]:
        return -1
    for i in range(index, len(text)):
        if brackets[0] == text[i]:
            stackSize += 1
        if brackets[1] == text[i]:
            stackSize -= 1
        if 0 == stackSize:
            return i
    return -2


def fromCqcode(text=""):
    elems = []
    items = []
    itemsSize = 0
    i = 0
    while i < len(text):
        brackets = ["[", "]"]
        pos = matchBracket(text, i, brackets)
        if pos == -1:
            if itemsSize >= len(items):
                items.append("")
            items[itemsSize] += text[i]
            i += 1
            continue
        if pos == -2:
            raise Exception(f"消息 CQ 码不匹配：{text}")
        if pos == -3 or pos == -4:
            items.append(text)
            i = len(text)
            break
        if pos == -5:
            # 这是不可能的
            raise Exception("错误的括号匹配：" + "".join(brackets))
        if pos > 0:
            items.append(text[i:pos + 1])
            i = pos + 1
            itemsSize = len(items)
        else:
            i += 1
    for c in items:
        pattern = re.compile("|".join(re.escape(k) for k in mCQ.keys()))
        s = pattern.sub(lambda m: mCQ.get(m.group(0), ""), c)
        cq = c.replace("[CQ:", "type=")
        if isinstance(s, str) and "" != s and "[CQ:" not in s:
            elems.append({"type": "text", "text": s})
            continue
        cq = cq[:-1]
        elems.append(qs(cq))
    return elems


def qs(text, sep=",", equal="="):
    ret = {}
    pattern = re.compile("|".join(re.escape(v) for v in mCQInside.values()))
    for c in text.split(sep):
        i = c.find(equal)
        if -1 == i:
            continue
        ret[c[:i]] = pattern.sub(lambda m: mCQInvert.get(m.group(0), ""), c[i + 1:])
    for k in list(ret.keys()):
        try:
            if "text" != k:
                ret[k] = json.loads(ret[k])
        except Exception:
            # do nothing
            pass
    return ret
