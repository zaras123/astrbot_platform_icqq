"""通用工具（common.js 的移植）。"""
from __future__ import annotations

import hashlib
import os
import re
import sys
import tempfile
import uuid as _uuid
from enum import IntEnum
from typing import Union

from .core import pb
from .core.constants import *  # noqa: F401,F403 （common.js re-export 了 core/constants）


def uuid() -> str:
    hex_ = _uuid.uuid4().hex
    return (
        hex_[0:8]
        + "-"
        + hex_[8:12]
        + "-"
        + hex_[12:16]
        + "-"
        + hex_[16:20]
        + "-"
        + hex_[20:32]
    )


async def md5Stream(readable) -> bytes:
    """计算异步流的md5（Python 中以 async 迭代器为流）。"""
    h = hashlib.md5()
    async for chunk in readable:
        h.update(chunk)
    return h.digest()


async def fileHash(filepath: str):
    """计算文件的md5和sha1"""
    with open(filepath, "rb") as f:
        data = f.read()
    return hashlib.md5(data).digest(), hashlib.sha1(data).digest()


def code2uin(code: int) -> int:
    """群号转uin"""
    left = code // 1000000
    if 0 <= left <= 10:
        left += 202
    elif 11 <= left <= 19:
        left += 469
    elif 20 <= left <= 66:
        left += 2080
    elif 67 <= left <= 156:
        left += 1943
    elif 157 <= left <= 209:
        left += 1990
    elif 210 <= left <= 309:
        left += 3890
    elif 310 <= left <= 335:
        left += 3490
    elif 336 <= left <= 386:
        left += 2265
    elif 387 <= left <= 499:
        left += 3490
    return left * 1000000 + (code % 1000000)


def uin2code(uin: int) -> int:
    """uin转群号"""
    left = uin // 1000000
    if 202 <= left <= 212:
        left -= 202
    elif 480 <= left <= 488:
        left -= 469
    elif 2100 <= left <= 2146:
        left -= 2080
    elif 2010 <= left <= 2099:
        left -= 1943
    elif 2147 <= left <= 2199:
        left -= 1990
    elif 2600 <= left <= 2651:
        left -= 2265
    elif 3800 <= left <= 3989:
        left -= 3490
    elif 4100 <= left <= 4199:
        left -= 3890
    return left * 1000000 + (uin % 1000000)


def parseFunString(buf: bytes) -> str:
    """解析彩色群名片"""
    if buf[0] == 0x0A:
        res = ""
        try:
            arr = pb.decode(buf)[1]
            if not isinstance(arr, list):
                arr = [arr]
            for v in arr:
                if v[2]:
                    s = v[2]
                    if isinstance(s, (bytes, bytearray)):
                        s = bytes(s).decode("utf-8", errors="replace")
                    res += str(s)
        except Exception:
            pass
        return res
    else:
        return buf.decode("utf-8", errors="replace")


def escapeXml(s: str) -> str:
    """xml转义"""
    def _rep(m):
        if m.group(0) == "&":
            return "&amp;"
        if m.group(0) == "<":
            return "&lt;"
        if m.group(0) == ">":
            return "&gt;"
        if m.group(0) == '"':
            return "&quot;"
        return ""

    return re.sub(r'[&"><]', _rep, s)


def log(any) -> None:
    """调试输出（JS 用 util.inspect 打印，这里用 print + 截断）。"""
    import json

    if isinstance(any, (bytes, bytearray)):
        any = " ".join(any.hex()[i:i + 2] for i in range(0, len(any.hex()), 2))
    print(any if not isinstance(any, (dict, list)) else json.dumps(any, ensure_ascii=False, indent=2))


class DownloadTransform:
    """用于下载限量（JS stream.Transform 的等价物）。

    用法：把下载的块逐个 push 进实例，超过 MAX_UPLOAD_SIZE 抛错。
    """

    def __init__(self):
        self._size = 0
        self._data = bytearray()

    def write(self, data: bytes) -> None:
        self._size += len(data)
        if self._size <= MAX_UPLOAD_SIZE:
            self._data += data
        else:
            raise RuntimeError("downloading over 30MB is refused")

    def flush(self) -> None:
        pass

    def read(self) -> bytes:
        return bytes(self._data)


PB_CONTENT = pb.encode({1: 1, 2: 0, 3: 0})
IS_WIN = sys.platform == "win32"
# 系统临时目录，用于临时存放下载的图片等内容
TMP_DIR = tempfile.gettempdir()
# 最大上传和下载大小，以图片上传限制为准：30MB
MAX_UPLOAD_SIZE = 31457280


class OnlineStatus(IntEnum):
    """可设置的在线状态"""
    # 离线
    Offline = 0
    # 在线
    Online = 11
    # 离开
    Absent = 31
    # 隐身
    Invisible = 41
    # 忙碌
    Busy = 50
    # Q我吧
    Qme = 60
    # 请勿打扰
    DontDisturb = 70
