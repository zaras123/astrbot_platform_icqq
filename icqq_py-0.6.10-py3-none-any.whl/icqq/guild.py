"""频道实体（guild.js 的移植）。"""
from __future__ import annotations

from enum import IntEnum

from .core import pb
from .core.constants import lock
from .channel import Channel


class GuildRole(IntEnum):
    """频道权限"""
    # 成员
    Member = 1
    # 频道管理员
    GuildAdmin = 2
    # 频道主
    Owner = 4
    # 子频道管理员
    ChannelAdmin = 5


members4buf = pb.encode({1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1})


class Guild:
    """频道

    JS 的静态工厂 `Guild.as(this, guild_id)` 在 Python 中命名为 `Guild.as_`（`as` 是保留字）。
    """

    def __init__(self, c, guild_id: str):
        self.c = c
        self.guild_id = guild_id
        # 频道名
        self.guild_name = ""
        # 子频道字典
        self.channels = {}
        lock(self, "guild_id")

    @staticmethod
    def as_(c, guild_id: str) -> "Guild":
        # JS: static as(this: Client, guild_id): Guild
        guild = c.guilds.get(guild_id)
        if not guild:
            raise Exception(f"尚未加入Guild({guild_id})")
        return guild

    async def sendMsg(self, channel_id: str, message):
        """
        发送消息
        :param channel_id: 子频道id
        :param message: 消息内容
        """
        channel = self.channels.get(channel_id)
        if not channel:
            raise Exception("你尚未加入频道：" + channel_id)
        return await channel.sendMsg(message)

    def _renew(self, guild_name: str, proto) -> None:
        self.guild_name = guild_name
        if not isinstance(proto, list):
            proto = [proto]
        tmp = set()
        for p in proto:
            id_ = str(p[1])
            name = str(p[8])
            notify_type = p[7]
            channel_type = p[9]
            tmp.add(id_)
            if id_ not in self.channels:
                self.channels[id_] = Channel(self, id_)
            channel = self.channels[id_]
            channel._renew(name, notify_type, channel_type)
        for id_ in list(self.channels.keys()):
            if id_ not in tmp:
                del self.channels[id_]

    async def getMemberList(self) -> list:
        """获取频道成员列表"""
        index = 0  # todo 成员数超过500
        body = pb.encode(
            {
                1: int(self.guild_id),
                2: 3,
                3: 0,
                4: members4buf,
                6: index,
                8: 500,
                14: 2,
            }
        )
        rsp = await self.c.sendOidbSvcTrpcTcp("OidbSvcTrpcTcp.0xf5b_1", body)
        list_ = []
        members = rsp[5] if isinstance(rsp[5], list) else [rsp[5]]
        admins = rsp[25] if isinstance(rsp[25], list) else [rsp[25]]
        for p in admins:
            role = p[1]
            if not p[2]:
                continue
            m = p[2] if isinstance(p[2], list) else [p[2]]
            for p2 in m:
                list_.append(
                    {
                        "tiny_id": str(p2[8]),
                        "card": str(p2[2]),
                        "nickname": str(p2[3]),
                        "role": role,
                        "join_time": p2[4],
                    }
                )
        for p in members:
            list_.append(
                {
                    "tiny_id": str(p[8]),
                    "card": str(p[2]),
                    "nickname": str(p[3]),
                    "role": GuildRole.Member,
                    "join_time": p[4],
                }
            )
        return list_
