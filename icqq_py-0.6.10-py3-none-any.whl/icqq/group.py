"""讨论组与群实体（group.js 的移植）。"""
from __future__ import annotations

import asyncio
import os
import weakref
from datetime import datetime

from .core import jce, pb
from .core.buffer import pack_u32
from .core.http import http_post, http_post_form
from .core.pb import decodePb
from .errors import ErrorCode, drop
from .common import PB_CONTENT, code2uin, hide, lock, timestamp
from .internal import Contactable
from .message import GroupMessage, Image, parseGroupMessageId
from .gfs import Gfs

# JS: const fetchmap = new Map();  （uin-gid → 拉取群员列表的任务）
fetchmap: "dict[str, asyncio.Task]" = {}
# JS: const weakmap = new WeakMap();  （info 对象 → Group 实例，值为弱引用）
_weakmap: "dict[int, weakref.ReferenceType[Group]]" = {}

GI_BUF = pb.encode(
    {
        1: 0,
        2: 0,
        5: 0,
        6: 0,
        15: "",
        29: 0,
        36: 0,
        37: 0,
        45: 0,
        46: 0,
        49: 0,
        50: 0,
        54: 0,
        89: "",
    }
)


def _weakmap_get(key):
    if not key:
        return None
    ref = _weakmap.get(id(key))
    return ref() if ref is not None else None


def _weakmap_set(key, value) -> None:
    if not key:
        return
    _weakmap[id(key)] = weakref.ref(value)


def _fire(coro) -> None:
    """JS: promise.catch(NOOP) 的等价物：后台执行协程并吞掉异常。"""
    task = asyncio.create_task(coro)

    def _done(t) -> None:
        if not t.cancelled():
            t.exception()

    task.add_done_callback(_done)


class Discuss(Contactable):
    """讨论组

    JS 的静态工厂 `Discuss.as(this, gid)` 在 Python 中命名为 `Discuss.as_`（`as` 是保留字）。
    """

    @staticmethod
    def as_(c, gid: int) -> "Discuss":
        # JS: static as(this: Client, gid): Discuss
        return Discuss(c, int(gid))

    @property
    def group_id(self) -> int:
        """{@link gid} 的别名"""
        return self.gid

    def __init__(self, c, gid: int):
        super().__init__(c)
        self.gid = gid
        lock(self, "gid")

    async def sendMsg(self, content) -> dict:
        """发送一条消息"""
        converter = await self._preprocess(content)
        body = pb.encode(
            {
                1: {4: {1: self.gid}},
                2: PB_CONTENT,
                3: {1: converter.rich},
                4: int.from_bytes(os.urandom(2), "big"),
                5: int.from_bytes(os.urandom(4), "big"),
                8: 0,
            }
        )
        payload = await self.c.sendUni("MessageSvc.PbSendMsg", body)
        rsp = pb.decode(payload)
        if rsp.get(1) != 0:
            self.c.logger.error(f"failed to send: [Discuss({self.gid})] {rsp.get(2)}({rsp.get(1)})")
            drop(rsp[1], rsp[2])
        self.c.stat.sent_msg_cnt += 1
        self.c.logger.info(f"succeed to send: [Discuss({self.gid})] " + converter.brief)
        return {"message_id": "", "seq": 0, "rand": 0, "time": 0}


class Group(Discuss):
    """群

    JS 的静态工厂 `Group.as(this, gid, strict)` 在 Python 中命名为 `Group.as_`（`as` 是保留字）。
    """

    @staticmethod
    def as_(c, gid: int, strict: bool = False) -> "Group":
        # JS: static as(this: Client, gid, strict): Group
        info = c.gl.get(gid)
        if strict and not info:
            raise Exception("你尚未加入群" + str(gid))
        group = _weakmap_get(info)
        if group:
            return group
        group = Group(c, int(gid), info)
        if info:
            _weakmap_set(info, group)
        return group

    @property
    def info(self) -> dict:
        """群资料"""
        if not self._info or timestamp() - (self._info.get("update_time") or 0) >= 900:
            _fire(self.renew())
        return self._info

    @property
    def name(self):
        """群名"""
        return self.info["group_name"] if self.info else None

    @property
    def is_owner(self) -> bool:
        """我是否是群主"""
        return bool(self.info) and self.info["owner_id"] == self.c.uin

    @property
    def is_admin(self) -> bool:
        """我是否是管理"""
        return self.is_owner or bool(self.info and self.info.get("admin_flag"))

    @property
    def all_muted(self) -> bool:
        """是否全员禁言"""
        return bool(self.info) and self.info["shutup_time_whole"] > timestamp()

    @property
    def mute_left(self) -> int:
        """我的禁言剩余时间"""
        t = (self.info["shutup_time_me"] if self.info else 0) - timestamp()
        return t if t > 0 else 0

    def __init__(self, c, gid: int, _info=None):
        super().__init__(c, gid)
        self._info = _info
        self.fs = Gfs(c, gid)
        lock(self, "fs")
        hide(self, "_info")

    def pickMember(self, uid: int, strict: bool = False):
        """
        获取群员实例
        :param uid: 群员账号
        :param strict: 严格模式，若群员不存在会抛出异常
        """
        return self.c.pickMember(self.gid, uid, strict)

    def getAvatarUrl(self, size: int = 0, history: int = 0) -> str:
        """
        获取群头像url
        :param size: 头像大小，默认`0`
        :param history: 历史头像记录，默认`0`，若要获取历史群头像则填写1,2,3...
        :return: 头像的url地址
        """
        return (
            f"https://p.qlogo.cn/gh/{self.gid}/{self.gid}{'_' + str(history) if history else ''}/"
            + str(size)
        )

    async def renew(self) -> dict:
        """强制刷新群资料"""
        if self._info:
            self._info["update_time"] = timestamp()
        body = pb.encode(
            {
                1: self.c.apk.subid,
                2: {1: self.gid, 2: GI_BUF},
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0x88d_0", body)
        proto = pb.decode(payload)[4][1][3]
        if not proto:
            self.c.gl.delete(self.gid)
            self.c.gml.delete(self.gid)
            drop(ErrorCode.GroupNotJoined)
        info = {
            "group_id": self.gid,
            "group_name": str(proto[89]) if proto[89] else str(proto[15]),
            "member_count": proto[6],
            "max_member_count": proto[5],
            "owner_id": proto[1],
            "admin_flag": bool(proto[50]),
            "last_join_time": proto[49],
            "last_sent_time": proto[54],
            "shutup_time_whole": 0xFFFFFFFF if proto[45] else 0,
            "shutup_time_me": proto[46] if proto[46] > timestamp() else 0,
            "create_time": proto[2],
            "grade": proto[36],
            "max_admin_count": proto[29],
            "active_member_count": proto[37],
            "update_time": timestamp(),
        }
        info = dict(self.c.gl.get(self.gid) or self._info or {}, **info)
        self.c.gl.set(self.gid, info)
        self._info = info
        _weakmap_set(info, self)
        return info

    async def _fetchMembers(self) -> dict:
        next_ = 0
        if not self.gid in self.c.gml:
            self.c.gml.set(self.gid, {})
        try:
            while True:
                GTML = jce.encodeStruct(
                    [
                        self.c.uin,
                        self.gid,
                        next_,
                        code2uin(self.gid),
                        2,
                        0,
                        0,
                        0,
                    ]
                )
                body = jce.encodeWrapper(
                    {"GTML": GTML},
                    "mqq.IMService.FriendListServiceServantObj",
                    "GetTroopMemberListReq",
                )
                payload = await self.c.sendUni("friendlist.GetTroopMemberListReq", body, 10)
                nested = jce.decodeWrapper(payload)
                next_ = nested[4]
                if not self.gid in self.c.gml:
                    self.c.gml.set(self.gid, {})
                for v in nested[3]:
                    info = {
                        "group_id": self.gid,
                        "user_id": v[0],
                        "nickname": v[4] or "",
                        "card": v[8] or "",
                        "sex": "unknown" if v[3] == -1 else "female" if v[3] else "male",
                        "age": v[2] or 0,
                        "join_time": v[15],
                        "last_sent_time": v[16],
                        "level": v[14],
                        "role": "admin" if v[18] % 2 == 1 else "member",
                        "title": v[23],
                        "title_expire_time": v[24] & 0xFFFFFFFF,
                        "shutup_time": v[30] if v[30] > timestamp() else 0,
                        "update_time": 0,
                    }
                    list_ = self.c.gml.get(self.gid)
                    info = dict(list_.get(v[0]) or {}, **info)
                    gl_info = self.c.gl.get(self.gid)
                    if gl_info and gl_info["owner_id"] == v[0]:
                        info["role"] = "owner"
                    list_[v[0]] = info
                if not next_:
                    break
        except Exception:
            self.c.logger.error("加载群员列表超时")
        fetchmap.pop(f"{self.c.uin}-{self.gid}", None)
        mlist = self.c.gml.get(self.gid)
        if not mlist or not self.c.config.get("cache_group_member"):
            self.c.gml.delete(self.gid)
        return mlist or {}

    async def getMemberMap(self, no_cache: bool = False):
        """获取群员列表"""
        k = f"{self.c.uin}-{self.gid}"
        fetching = fetchmap.get(k)
        if fetching:
            return await fetching
        mlist = self.c.gml.get(self.gid)
        if not mlist or no_cache:
            fetching = asyncio.create_task(self._fetchMembers())
            fetchmap[k] = fetching
            return await fetching
        else:
            return mlist

    async def addEssence(self, seq: int, rand: int) -> str:
        """
        添加精华消息
        :param seq: 消息序号
        :param rand: 消息的随机值
        """
        retPacket = await self.c.sendPacket(
            "Oidb", "OidbSvc.0xeac_1", {1: self.gid, 2: seq, 3: rand}
        )
        ret = pb.decode(retPacket)[4]
        if ret[1]:
            self.c.logger.error(f"加精群消息失败： {ret[2]}({ret[1]})")
            drop(ret[1], ret[2])
        else:
            return "设置精华成功"

    async def removeEssence(self, seq: int, rand: int) -> str:
        """
        移除精华消息
        :param seq: 消息序号
        :param rand: 消息的随机值
        """
        retPacket = await self.c.sendPacket(
            "Oidb", "OidbSvc.0xeac_2", {1: self.gid, 2: seq, 3: rand}
        )
        ret = pb.decode(retPacket)[4]
        if ret[1]:
            self.c.logger.error(f"移除群精华消息失败： {ret[2]}({ret[1]})")
            drop(ret[1], ret[2])
        else:
            return "移除群精华消息成功"

    async def sendFile(self, file, pid: str = "/", name=None, callback=None) -> dict:
        """
        发送一个文件
        :param file: `str`表示从该本地文件路径上传，`bytes`表示直接上传这段内容
        :param pid: 上传的目标目录id，默认根目录
        :param name: 上传的文件名，`file`为`bytes`时，若留空则自动以md5命名
        :param callback: 监控上传进度的回调函数，拥有一个"百分比进度"的参数
        :return: 上传的文件属性
        """
        return await self.fs.upload(file, pid, name, callback)

    async def sendMsg(self, content, source=None, anony=False) -> dict:
        """
        发送一条消息
        :param content: 消息内容
        :param source: 引用回复的消息
        :param anony: 是否匿名
        """
        converter = await self._preprocess(content, source)
        if anony:
            if not anony.id:
                anony = await self.getAnonyInfo()
            converter.anonymize(anony)
        rand = int.from_bytes(os.urandom(4), "big")
        body = pb.encode(
            {
                1: {2: {1: self.gid}},
                2: PB_CONTENT,
                3: {1: converter.rich},
                4: int.from_bytes(os.urandom(2), "big"),
                5: rand,
                8: 0,
            }
        )
        e = f"internal.{self.gid}.{rand}"
        message_id = ""

        def _on_msg_id(id_: str) -> None:
            nonlocal message_id
            message_id = id_

        self.c.trapOnce(e, _on_msg_id)
        try:
            payload = await self.c.sendUni("MessageSvc.PbSendMsg", body)
            rsp = pb.decode(payload)
            if rsp.get(1) != 0:
                self.c.logger.error(f"failed to send: [Group: {self.gid}] {rsp.get(2)}({rsp.get(1)})")
                drop(rsp[1], rsp[2])
        finally:
            self.c.offTrap(e)
        # 分片专属屎山
        try:
            if not message_id:
                wait_ms = (2000 if converter.length <= 80 else 500) if self.c.config.get("resend") else 5000
                loop = asyncio.get_running_loop()
                fut = loop.create_future()

                def _cb(id_: str) -> None:
                    if not fut.done():
                        fut.set_result(id_)

                self.c.trapOnce(e, _cb)
                try:
                    message_id = await asyncio.wait_for(asyncio.shield(fut), wait_ms / 1000)
                except asyncio.TimeoutError:
                    self.c.offTrap(e)
                    raise
        except Exception:
            message_id = await self._sendMsgByFrag(converter)
        self.c.stat.sent_msg_cnt += 1
        self.c.logger.info(f"succeed to send: [Group({self.gid})] " + converter.brief)
        parsed = parseGroupMessageId(message_id)
        messageRet = {
            "seq": parsed["seq"],
            "rand": parsed["rand"],
            "time": parsed["time"],
            "message_id": message_id,
        }
        self.c.emit("send", messageRet)
        return messageRet

    async def _sendMsgByFrag(self, converter) -> str:
        if not self.c.config.get("resend") or not converter.is_chain:
            drop(ErrorCode.RiskMessageError)
        fragments = converter.toFragments()
        self.c.logger.warn("群消息可能被风控，将尝试使用分片发送")
        n = 0
        rand = int.from_bytes(os.urandom(4), "big")
        div = int.from_bytes(os.urandom(2), "big")
        for frag in fragments:
            body = pb.encode(
                {
                    1: {2: {1: self.gid}},
                    2: {1: len(fragments), 2: n, 3: div},
                    3: {1: frag},
                    4: int.from_bytes(os.urandom(2), "big"),
                    5: rand,
                    8: 0,
                }
            )
            n += 1
            self.c.writeUni("MessageSvc.PbSendMsg", body)
        e = f"internal.{self.gid}.{rand}"
        try:
            loop = asyncio.get_running_loop()
            fut = loop.create_future()

            def _cb(id_: str) -> None:
                if not fut.done():
                    fut.set_result(id_)

            self.c.trapOnce(e, _cb)
            try:
                return await asyncio.wait_for(asyncio.shield(fut), 5.0)
            except asyncio.TimeoutError:
                self.c.offTrap(e)
                raise
        except Exception:
            drop(ErrorCode.SensitiveWordsError)

    async def setScreenMemberMsg(self, member_id: int, isScreen: bool = False) -> bool:
        """
        设置当前群成员消息屏蔽状态
        :param member_id:
        :param isScreen:
        """
        return await self.pickMember(member_id).setScreenMsg(isScreen)

    async def recallMsg(self, param, rand: int = 0, pktnum: int = 1) -> bool:
        """撤回消息，cqhttp方法用"""
        if isinstance(param, GroupMessage):
            seq, rand, pktnum = param.seq, param.rand, param.pktnum
        elif isinstance(param, str):
            parsed = parseGroupMessageId(param)
            seq, rand, pktnum = parsed["seq"], parsed["rand"], parsed["pktnum"]
        else:
            seq = param
        if pktnum > 1:
            msg = []
            pb_msg = []
            n = pktnum
            i = 0
            while n > 0:
                msg.append(pb.encode({1: seq, 2: rand}))
                pb_msg.append(pb.encode({1: seq, 3: pktnum, 4: i}))
                i += 1
                seq += 1
                n -= 1
            reserver = {1: 1, 2: pb_msg}
        else:
            msg = {1: seq, 2: rand}
            reserver = {1: 0}
        body = pb.encode(
            {
                2: {1: 1, 2: 0, 3: self.gid, 4: msg, 5: reserver},
            }
        )
        payload = await self.c.sendUni("PbMessageSvc.PbMsgWithDraw", body)
        return pb.decode(payload)[2][1] == 0

    async def setName(self, name: str) -> bool:
        """设置群名"""
        return await self._setting({3: str(name)})

    async def muteAll(self, yes: bool = True) -> bool:
        """全员禁言"""
        return await self._setting({17: 0xFFFFFFFF if yes else 0})

    async def announce(self, content: str) -> bool:
        """发送简易群公告"""
        return await self._setting({4: str(content)})

    async def _setting(self, obj: dict) -> bool:
        body = pb.encode({1: self.gid, 2: obj})
        payload = await self.c.sendOidb("OidbSvc.0x89a_0", body)
        return pb.decode(payload).get(3) == 0

    async def allowAnony(self, yes: bool = True) -> bool:
        """允许/禁止匿名"""
        buf = bytearray(5)
        buf[0:4] = pack_u32(self.gid)
        buf[4] = 1 if yes else 0
        payload = await self.c.sendOidb("OidbSvc.0x568_22", bytes(buf))
        return pb.decode(payload).get(3) == 0

    async def setRemark(self, remark: str = "") -> None:
        """设置群备注"""
        body = pb.encode(
            {
                1: {1: self.gid, 2: code2uin(self.gid), 3: str(remark or "")},
            }
        )
        await self.c.sendOidb("OidbSvc.0xf16_1", body)

    async def muteAnony(self, flag: str, duration: int = 1800) -> None:
        """禁言匿名群员，默认1800秒"""
        nick, id_ = flag.split("@")
        Cookie = self.c.cookies["qqweb.qq.com"]
        body = {
            "anony_id": id_,
            "group_code": str(self.gid),
            "seconds": str(duration),
            "anony_nick": nick,
            "bkn": str(self.c.bkn),
        }
        await http_post_form(
            "https://qqweb.qq.com/c/anonymoustalk/blacklist",
            data=body,
            headers={"Cookie": Cookie, "Content-Type": "application/x-www-form-urlencoded"},
            timeout=5.0,
        )

    async def getAnonyInfo(self) -> dict:
        """获取自己的匿名情报"""
        body = pb.encode(
            {
                1: 1,
                10: {1: self.c.uin, 2: self.gid},
            }
        )
        payload = await self.c.sendUni("group_anonymous_generate_nick.group", body)
        obj = pb.decode(payload)[11]
        return {
            "enable": not obj[10][1],
            "name": str(obj[3]),
            "id": obj[5],
            "id2": obj[4],
            "expire_time": obj[6],
            "color": str(obj[15]),
        }

    async def getAtAllRemainder(self) -> int:
        """获取 @全体成员 的剩余次数"""
        body = pb.encode({1: 1, 2: 2, 3: 1, 4: self.c.uin, 5: self.gid})
        payload = await self.c.sendOidb("OidbSvc.0x8a7_0", body)
        return pb.decode(payload)[4][2]

    async def _getLastSeq(self) -> int:
        body = pb.encode(
            {
                1: self.c.apk.subid,
                2: {1: self.gid, 2: {22: 0}},
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0x88d_0", body)
        return pb.decode(payload)[4][1][3][22]

    async def markRead(self, seq: int = 0) -> None:
        """
        标记`seq`之前的消息为已读
        :param seq: 消息序号，默认为`0`，表示标记所有消息
        """
        body = pb.encode({1: {1: self.gid, 2: int(seq or await self._getLastSeq())}})
        await self.c.sendUni("PbMessageSvc.PbMsgReadedReport", body)

    async def getChatHistory(self, seq: int = 0, cnt: int = 20) -> list:
        """
        获取`seq`之前的`cnt`条聊天记录，默认从最后一条发言往前，`cnt`默认20不能超过20
        :param seq: 消息序号，默认为`0`，表示从最后一条发言往前
        :param cnt: 聊天记录条数，默认`20`，超过`20`按`20`处理
        :return: 群聊消息列表，服务器记录不足`cnt`条则返回能获取到的最多消息记录
        """
        if cnt > 20:
            cnt = 20
        if not seq:
            seq = await self._getLastSeq()
        from_seq = seq - cnt + 1
        body = pb.encode({1: self.gid, 2: from_seq, 3: int(seq), 6: 0})
        payload = await self.c.sendUni("MessageSvc.PbGetGroupMsg", body)
        obj = pb.decode(payload)
        messages = []
        if (obj.get(1) or 0) > 0 or not obj.get(6):
            return []
        if not isinstance(obj[6], list):
            obj[6] = [obj[6]]
        for proto in obj[6]:
            try:
                messages.append(GroupMessage(proto))
            except Exception:
                pass
        return messages

    async def getFileUrl(self, fid: str) -> str:
        """
        获取群文件下载地址
        :param fid: 文件id
        """
        return (await self.fs.download(fid))["url"]

    async def setAvatar(self, file) -> None:
        """设置群头像"""
        img = Image({"type": "image", "file": file})
        await img.task
        url = (
            f"http://htdata3.qq.com/cgi-bin/httpconn?htcmd=0x6ff0072&ver=5520"
            f"&ukey={self.c.sig.skey}&range=0&uin={self.c.uin}&seq=1&groupuin={self.gid}"
            f"&filetype=3&imagetype=5&userdata=0&subcmd=1&subver=101&clip=0_0_0_0&filesize="
            + str(img.size)
        )
        await http_post(url, data=img.readable, headers={"Content-Length": str(img.size)}, timeout=20.0)
        img.deleteTmpFile()

    async def invite(self, uid: int) -> bool:
        """
        邀请好友入群
        :param uid: 好友账号
        """
        body = pb.encode({1: self.gid, 2: {1: int(uid)}})
        payload = await self.c.sendOidb("OidbSvc.oidb_0x758", body)
        return len(pb.decode(payload)[4].toBuffer()) > 6

    async def sign(self) -> dict:
        """打卡"""
        body = pb.encode(
            {
                2: {1: str(self.c.uin), 2: str(self.gid), 3: self.c.apk.ver},
            }
        )
        payload = await self.c.sendOidb("OidbSvc.0xeb7_1", body)
        rsp = pb.decode(payload)
        return {"result": (rsp.get(3) or 0) & 0xFFFFFFFF}

    async def quit(self) -> bool:
        """退群，若为群主则解散该群"""
        buf = bytearray(8)
        buf[0:4] = pack_u32(self.c.uin)
        buf[4:8] = pack_u32(self.gid)
        GroupMngReq = jce.encodeStruct([2, self.c.uin, bytes(buf)])
        body = jce.encodeWrapper(
            {"GroupMngReq": GroupMngReq}, "KQQ.ProfileService.ProfileServantObj", "GroupMngReq"
        )
        payload = await self.c.sendUni("ProfileService.GroupMngReq", body)
        return jce.decodeWrapper(payload)[1] == 0

    async def setAdmin(self, uid: int, yes: bool = True) -> bool:
        """
        设置管理员，use {@link Member.setAdmin}
        :param uid: 群员账号
        :param yes: 是否设为管理员
        """
        return await self.pickMember(uid).setAdmin(yes)

    async def setTitle(self, uid: int, title: str = "", duration: int = -1) -> bool:
        """
        设置头衔，use {@link Member.setTitle}
        :param uid: 群员账号
        :param title: 头衔名
        :param duration: 持续时间，默认`-1`，表示永久
        """
        return await self.pickMember(uid).setTitle(title, duration)

    async def setCard(self, uid: int, card: str = "") -> bool:
        """
        设置名片，use {@link Member.setCard}
        :param uid: 群员账号
        :param card: 名片
        """
        return await self.pickMember(uid).setCard(card)

    async def kickMember(self, uid: int, msg=None, block: bool = False) -> bool:
        """
        踢出此群，use {@link Member.kick}
        :param uid: 群员账号
        :param msg: @todo 未知参数
        :param block: 是否屏蔽群员
        """
        return await self.pickMember(uid).kick(msg, block)

    async def muteMember(self, uid: int, duration: int = 600) -> None:
        """
        禁言群员，use {@link Member.mute}
        :param uid: 群员账号
        :param duration: 禁言时长（秒），默认`600`
        """
        await self.pickMember(uid).mute(duration)

    async def pokeMember(self, uid: int) -> bool:
        """
        戳一戳
        :param uid: 群员账号
        """
        return await self.pickMember(uid).poke()

    async def getMuteMemberList(self) -> list:
        """获取群内被禁言人"""
        body = {
            "1": 2201,
            "3": 0,
            "4": {
                "1": self.group_id,
                "2": 0,
                "3": 6,
                "5": {"1": 0, "12": 0},
            },
        }

        def toTime(ts: int) -> str:
            date = datetime.fromtimestamp(ts)
            Y = str(date.year) + "-"
            M = (f"0{date.month}" if date.month < 10 else str(date.month)) + "-"
            D = (f"0{date.day}" if date.day < 10 else str(date.day)) + " "
            h = str(date.hour) + ":"
            m = date.minute
            return Y + M + D + h + str(m)

        resBody = await self.c.sendUni("OidbSvc.0x899_0", pb.encode(body))
        res = decodePb(resBody)[4][4]
        if not isinstance(res, list):
            res = [res]
        return [
            {"uin": item[1] if item else None, "unMuteTime": toTime(item[12]) if item else None}
            for item in res
            if item
        ]
